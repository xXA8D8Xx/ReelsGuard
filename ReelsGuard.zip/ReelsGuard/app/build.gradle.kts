plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.reelsguard"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.reelsguard"
        minSdk = 26
        targetSdk = 34
        versionCode = 8
        versionName = "1.6"
    }

    // 매 빌드마다 같은 키로 서명해야 새 버전을 기존 앱 위에 덮어 설치할 수 있다.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}
