package com.example.reelsguard

/** 앱 전체에서 같이 쓰는 색. 어두운 남색 바탕, 깃털 같은 아이보리, 금빛 포인트 하나만 쓴다. */
object Palette {
    const val BG = "#0D1015"        // 바탕 (인스타그램 어두운 배경과 같은 색)
    const val SURFACE = "#171B24"   // 카드·알림
    const val LINE = "#2A303B"      // 가는 선
    const val TEXT = "#F3EFE6"      // 본문(깃털색)
    const val MUTED = "#8B93A1"     // 보조 글씨
    const val DIM = "#5C6472"       // 비활성
    const val GOLD = "#E6C98A"      // 포인트(눈·광륜)
    const val BAR = "#3A4252"       // 그래프 막대
}
