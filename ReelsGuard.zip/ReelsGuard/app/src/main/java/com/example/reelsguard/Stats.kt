package com.example.reelsguard

import android.content.Context
import java.time.LocalDate

/** 날짜별 사용 통계. 앱 화면(통계 슬라이드)과 접근성 서비스가 같이 쓴다. */
object Stats {
    const val IG_MS = "ig_ms"            // 인스타그램을 쓴 시간(추정, ms)
    const val REELS_MS = "reels_ms"      // 그중 릴스 뷰어에 머문 시간(ms)
    const val SWIPES = "swipes"          // 허용된 릴스 스와이프 횟수
    const val FEED_PX = "feed_px"        // 홈 피드에서 새로 내려가 본 거리(px)
    const val EXPLORE_PX = "explore_px"  // 탐색 탭에서 새로 내려가 본 거리(px)
    const val BLOCKS = "blocks"          // 차단·경고가 작동한 횟수
    const val OVER = "over"              // 한도를 다 써서 막힌 횟수(있으면 그날은 연속 기록 실패)
    const val PAUSES = "pauses"          // 숨 고르기 화면이 나온 횟수
    fun reasonKey(i: Int) = "emr_$i"     // 긴급 해제 이유별 횟수
    const val EMERGENCY = "emergency"    // 긴급 해제를 쓴 횟수(있으면 그날은 연속 기록 실패)

    private const val FILE = "reelsguard_stats"
    private const val KEEP_DAYS = 400L

    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    private fun key(day: LocalDate, k: String) = "${day}_$k"

    fun get(c: Context, day: LocalDate, k: String): Long = sp(c).getLong(key(day, k), 0L)

    fun today(c: Context, k: String): Long = get(c, Day.today(), k)

    fun add(c: Context, k: String, amount: Long) {
        if (amount <= 0L) return
        val key = key(Day.today(), k)
        val p = sp(c)
        p.edit().putLong(key, p.getLong(key, 0L) + amount).apply()
    }

    fun sum(c: Context, days: List<LocalDate>, k: String): Long {
        var total = 0L
        for (d in days) total += get(c, d, k)
        return total
    }

    /** 오래된 기록 정리. */
    fun prune(c: Context) {
        val p = sp(c)
        val cutoff = Day.today().minusDays(KEEP_DAYS)
        val ed = p.edit()
        for (k in p.all.keys) {
            val d = try {
                LocalDate.parse(k.substring(0, 10))
            } catch (e: Exception) {
                null
            }
            if (d != null && d.isBefore(cutoff)) ed.remove(k)
        }
        ed.apply()
    }

    // ---------- 연속 기록 ----------

    /** 그날 한도를 넘기려 하지 않았고 긴급 해제도 쓰지 않았는가. 기록이 없는 날(안 쓴 날)도 지킨 날. */
    fun kept(c: Context, day: LocalDate): Boolean =
        get(c, day, OVER) == 0L && get(c, day, EMERGENCY) == 0L

    class Streak(val current: Int, val best: Int, val last7: List<Int>)  // last7: 1 지킴, 0 못 지킴, -1 기록 전

    /** 오늘까지 이어진 연속 일수, 최고 기록, 최근 7일 상태. 오늘은 실패하기 전까지 지킨 것으로 센다. */
    fun streak(c: Context, since: LocalDate): Streak {
        val today = Day.today()
        var cur = 0
        var d = today
        while (!d.isBefore(since) && kept(c, d)) { cur++; d = d.minusDays(1) }
        var best = 0
        var run = 0
        var x = since
        while (!x.isAfter(today)) {
            if (kept(c, x)) { run++; if (run > best) best = run } else run = 0
            x = x.plusDays(1)
        }
        val l7 = ArrayList<Int>()
        for (i in 6 downTo 0) {
            val dd = today.minusDays(i.toLong())
            l7.add(if (dd.isBefore(since)) -1 else if (kept(c, dd)) 1 else 0)
        }
        return Streak(cur, best, l7)
    }
}
