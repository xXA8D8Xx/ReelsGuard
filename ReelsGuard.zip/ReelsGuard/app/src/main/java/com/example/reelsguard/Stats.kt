package com.example.reelsguard

import android.content.Context
import java.time.LocalDate

/** 날짜별 사용 통계. 앱 화면(통계 슬라이드)과 접근성 서비스가 같이 쓴다. */
object Stats {
    const val IG_MS = "ig_ms"            // 인스타그램을 쓴 시간(추정, ms)
    const val REELS_MS = "reels_ms"      // 그중 릴스 뷰어에 머문 시간(ms)
    const val SWIPES = "swipes"          // 허용된 릴스 스와이프 횟수
    const val FEED_PX = "feed_px"        // 홈 피드에서 새로 내려가 본 거리(px)
    const val EXPLORE_PX = "explore_px"  // 탐색 탭에서 새로 내려가 본 거리(px)
    const val BLOCKS = "blocks"          // 차단·경고가 작동한 횟수

    private const val FILE = "reelsguard_stats"
    private const val KEEP_DAYS = 45L

    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    private fun key(day: LocalDate, k: String) = "${day}_$k"

    fun get(c: Context, day: LocalDate, k: String): Long = sp(c).getLong(key(day, k), 0L)

    fun today(c: Context, k: String): Long = get(c, LocalDate.now(), k)

    fun add(c: Context, k: String, amount: Long) {
        if (amount <= 0L) return
        val key = key(LocalDate.now(), k)
        val p = sp(c)
        p.edit().putLong(key, p.getLong(key, 0L) + amount).apply()
    }

    fun sum(c: Context, days: List<LocalDate>, k: String): Long {
        var total = 0L
        for (d in days) total += get(c, d, k)
        return total
    }

    /** 오래된 기록 정리. */
    fun prune(c: Context) {
        val p = sp(c)
        val cutoff = LocalDate.now().minusDays(KEEP_DAYS)
        val ed = p.edit()
        for (k in p.all.keys) {
            val d = try {
                LocalDate.parse(k.substring(0, 10))
            } catch (e: Exception) {
                null
            }
            if (d != null && d.isBefore(cutoff)) ed.remove(k)
        }
        ed.apply()
    }
}
