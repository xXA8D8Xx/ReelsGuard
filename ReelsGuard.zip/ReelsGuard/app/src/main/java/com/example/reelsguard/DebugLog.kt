package com.example.reelsguard

import android.content.Context
import java.io.File
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/**
 * 점검 화면에 보여 줄 가벼운 기록.
 * - 로그는 최근 80줄만 메모리의 고리 버퍼에 두고(줄당 140자까지), 디스크에는 인스타그램을 닫을 때만 한 번 쓴다.
 * - 이벤트마다 하는 일은 숫자 몇 개를 갱신하는 것뿐이다.
 */
object DebugLog {
    private const val MAX = 80
    private const val MAX_CHARS = 140
    private const val FILE = "debug.log"

    private val times = LongArray(MAX)
    private val msgs = arrayOfNulls<String>(MAX)
    private var head = 0
    private var size = 0
    private var dirty = false
    private var loaded = false

    @Synchronized
    fun add(msg: String) {
        times[head] = System.currentTimeMillis()
        msgs[head] = if (msg.length > MAX_CHARS) msg.substring(0, MAX_CHARS) else msg
        head = (head + 1) % MAX
        if (size < MAX) size++
        dirty = true
    }

    /** 오래된 것부터 (시각, 내용). */
    @Synchronized
    fun entries(): List<Pair<Long, String>> {
        val out = ArrayList<Pair<Long, String>>(size)
        val start = (head - size + MAX) % MAX
        for (i in 0 until size) {
            val k = (start + i) % MAX
            out.add(times[k] to (msgs[k] ?: ""))
        }
        return out
    }

    private val fmt = DateTimeFormatter.ofPattern("HH:mm:ss")

    fun text(c: Context, lastN: Int = MAX): String {
        ensureLoaded(c)
        val all = entries()
        val part = if (all.size > lastN) all.subList(all.size - lastN, all.size) else all
        val zone = ZoneId.systemDefault()
        val sb = StringBuilder()
        for ((t, m) in part) {
            sb.append(fmt.format(Instant.ofEpochMilli(t).atZone(zone))).append("  ").append(m).append('\n')
        }
        return sb.toString()
    }

    /** 앱 프로세스가 새로 떴을 때만 디스크의 이전 기록을 한 번 읽어 온다. */
    @Synchronized
    private fun ensureLoaded(c: Context) {
        if (loaded) return
        loaded = true
        if (size > 0) return
        try {
            val f = File(c.filesDir, FILE)
            if (!f.exists() || f.length() > 64 * 1024) return
            for (line in f.readLines()) {
                val tab = line.indexOf('\t')
                if (tab <= 0) continue
                val t = line.substring(0, tab).toLongOrNull() ?: continue
                times[head] = t
                msgs[head] = line.substring(tab + 1)
                head = (head + 1) % MAX
                if (size < MAX) size++
            }
        } catch (e: Exception) {
            // 읽지 못하면 빈 기록으로 시작
        }
    }

    /** 바뀐 것이 있을 때만 쓴다(최대 약 12KB). */
    fun save(c: Context) {
        val snapshot: List<Pair<Long, String>>
        synchronized(this) {
            if (!dirty) return
            dirty = false
            snapshot = entries()
        }
        try {
            val sb = StringBuilder()
            for ((t, m) in snapshot) sb.append(t).append('\t').append(m.replace('\n', ' ')).append('\n')
            File(c.filesDir, FILE).writeText(sb.toString())
        } catch (e: Exception) {
            // 저장 실패는 무시
        }
    }
}

/** 서비스가 살아 있는지·무엇을 봤는지 알려 주는 가벼운 상태판(앱 화면과 서비스가 같은 프로세스를 쓴다). */
object Health {
    @Volatile var connected = false
    @Volatile var connectedAt = 0L
    @Volatile var lastIgEvent = 0L
    @Volatile var igEvents = 0L

    /** 화면 요소 이름표 — seenAt 과 같은 순서. */
    val ELEMENTS = arrayOf("릴스 탭", "홈 탭", "탐색 탭", "DM 탭", "프로필 탭", "릴스 뷰어")
    val seenAt = LongArray(ELEMENTS.size)
}
