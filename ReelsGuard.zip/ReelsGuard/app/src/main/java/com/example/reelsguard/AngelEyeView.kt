package com.example.reelsguard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.provider.Settings
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * 천사의 눈: 광륜 아래 금빛 눈, 양옆으로 펼쳐진 깃털 세 장씩.
 *
 * - 천천히 움직인다: 시선이 좌우로 느리게 오가고, 몇 초에 한 번 느리게 깜빡이며,
 *   광륜이 숨 쉬듯 밝아졌다 어두워지고, 깃털이 아주 살짝 흔들린다.
 *   (설정에서 끄거나, 기기의 '애니메이션 끄기'를 켜면 멈춘다.)
 * - setFold(0~3) 로 깃털 접힘 정도를 정한다. 아래쪽 깃털부터 한 쌍씩 접힌다.
 */
class AngelEyeView(context: Context) : View(context) {

    private val gold = Color.parseColor(Palette.GOLD)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val oval = RectF()

    private val moving: Boolean = Prefs.eyeMotionOn(context) && animationsEnabled(context)
    private val t0 = SystemClock.uptimeMillis()
    private var windowShown = true

    // 잠들기: 1 이면 눈을 감고 모든 움직임을 멈춘다(그리는 것도 멈춰 기기 부담을 줄인다)
    private var sleepTarget = 0f
    private var sleepShown = 0f
    private var lastFrame = 0L

    private var foldTarget = 0f
    private var foldShown = 0f

    // 깃털: 시작(dx,dy), 제어점(dx,dy), 끝(dx,dy), 두께, 투명도 — 모두 눈 반폭(a) 기준 비율
    private val fan = arrayOf(
        floatArrayOf(1.20f, -0.12f, 2.00f, -0.80f, 2.85f, -1.10f, 0.20f, 0.95f),
        floatArrayOf(1.28f, 0.00f, 2.20f, -0.20f, 3.05f, -0.14f, 0.19f, 0.78f),
        floatArrayOf(1.20f, 0.12f, 1.95f, 0.55f, 2.65f, 0.92f, 0.18f, 0.58f)
    )

    init {
        line.style = Paint.Style.STROKE
        line.strokeCap = Paint.Cap.ROUND
        line.strokeJoin = Paint.Join.ROUND
        line.color = gold
        fill.style = Paint.Style.FILL
        fill.color = gold
    }

    /** 깃털 접힘 정도 0(모두 펼침)~3(모두 접음). 움직임이 켜져 있으면 부드럽게 바뀐다. */
    fun setFold(level: Float) {
        foldTarget = level.coerceIn(0f, 3f)
        if (!moving || sleepTarget > 0f) foldShown = foldTarget
        invalidate()
    }

    /** 눈을 감고 멈추거나(true) 다시 뜬다(false). instant 면 애니메이션 없이 바로. */
    fun setSleeping(sleep: Boolean, instant: Boolean = false) {
        sleepTarget = if (sleep) 1f else 0f
        if (instant || !moving) sleepShown = sleepTarget
        lastFrame = 0L
        invalidate()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        windowShown = visibility == VISIBLE
        if (windowShown) invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val d = resources.displayMetrics.density
        val a = min(w * 0.15f, h * 0.30f)   // 눈의 반폭
        val b = a * 0.55f                    // 눈의 반높이
        val cx = w / 2f
        val cy = h * 0.58f
        val sw = max(1.2f * d, a * 0.11f)    // 기본 선 굵기

        // ----- 시간에 따른 움직임 -----
        val t = (SystemClock.uptimeMillis() - t0).toFloat()
        val twoPi = (2.0 * PI).toFloat()
        var gazeX = 0f
        var gazeY = 0f
        var lid = 1f
        var haloAlpha = 255
        var haloLift = 0f

        // 잠들기/깨어나기: 눈꺼풀이 0.35초에 걸쳐 내려오거나 올라간다
        val nowMs = SystemClock.uptimeMillis()
        if (sleepShown != sleepTarget) {
            val dt = if (lastFrame == 0L) 16L else (nowMs - lastFrame).coerceIn(1L, 100L)
            val step = dt / 350f
            sleepShown = if (sleepTarget > sleepShown) min(sleepTarget, sleepShown + step)
            else max(sleepTarget, sleepShown - step)
        }
        lastFrame = nowMs
        val awake = 1f - sleepShown
        if (moving) {
            gazeX = sin(t * twoPi / 7200f) * b * 0.30f * awake
            gazeY = sin(t * twoPi / 11000f + 1f) * b * 0.10f * awake
            val ph = ((t.toLong() + 3500L) % 6500L).toFloat()          // 6.5초마다 한 번
            val blink = if (ph < 700f) sin(ph / 700f * PI.toFloat()) else 0f
            lid = 1f - 0.92f * blink
            haloAlpha = ((0.70f + 0.30f * (0.5f + 0.5f * sin(t * twoPi / 4200f))) * 255f).toInt()
            haloLift = sin(t * twoPi / 5200f) * a * 0.05f * awake

            // 접힘 정도가 목표를 향해 천천히 따라간다
            val diff = foldTarget - foldShown
            foldShown = if (abs(diff) > 0.004f) foldShown + diff * 0.10f else foldTarget
        }

        lid *= 1f - 0.92f * sleepShown   // 잠들면 눈꺼풀이 거의 닫힌다

        // ----- 깃털(양쪽 3장씩) -----
        for (side in intArrayOf(1, -1)) {
            for (i in fan.indices) {
                val f = fan[i]
                val sx = cx + side * a * f[0]
                val sy = cy + a * f[1]
                var qx = cx + side * a * f[2]
                var qy = cy + a * f[3]
                var ex = cx + side * a * f[4]
                var ey = cy + a * f[5]

                if (moving) {
                    val sway = sin(t * twoPi / 4800f + i * 0.8f) * a * 0.05f * awake
                    qy += sway
                    ey += sway * 1.4f
                }

                // 아래쪽 깃털(i=2)부터 접힌다: k=0 이 가장 먼저
                val k = (fan.size - 1 - i).toFloat()
                val fa = (foldShown - k).coerceIn(0f, 1f)
                var th = a * f[6]
                var alpha = f[7]
                if (fa > 0f) {
                    val s = 1f - 0.72f * fa          // 길이가 줄고
                    val droop = a * 0.55f * fa       // 아래로 처지며
                    qx = sx + (qx - sx) * s
                    qy = sy + (qy - sy) * s + droop * 0.5f
                    ex = sx + (ex - sx) * s
                    ey = sy + (ey - sy) * s + droop
                    th *= 1f - 0.30f * fa
                    alpha *= 1f - 0.60f * fa         // 흐려진다
                }

                path.reset()
                path.moveTo(sx, sy)
                path.quadTo(qx, qy - th, ex, ey)
                path.quadTo(qx, qy + th, sx, sy)
                path.close()
                fill.color = gold
                fill.alpha = (alpha * 255f).toInt()
                canvas.drawPath(path, fill)
            }
        }

        // ----- 광륜 -----
        val hy = cy - b - a * 0.62f + haloLift
        oval.set(cx - a * 0.58f, hy - a * 0.17f, cx + a * 0.58f, hy + a * 0.17f)
        line.color = gold
        line.alpha = haloAlpha
        line.strokeWidth = sw * 0.85f
        canvas.drawOval(oval, line)

        // ----- 눈(깜빡이면 눈꺼풀이 내려온다) -----
        line.alpha = 255
        path.reset()
        path.moveTo(cx - a, cy)
        path.quadTo(cx, cy - 2f * b * lid, cx + a, cy)
        path.quadTo(cx, cy + 2f * b * lid, cx - a, cy)
        path.close()
        line.strokeWidth = sw * 1.15f
        canvas.drawPath(path, line)

        // ----- 눈동자(시선을 따라 움직임) -----
        val r = b * 0.80f
        line.strokeWidth = sw * 0.9f
        oval.set(cx + gazeX - r, cy + gazeY - r * lid, cx + gazeX + r, cy + gazeY + r * lid)
        canvas.drawOval(oval, line)
        val rp = b * 0.33f
        fill.color = gold
        fill.alpha = 255
        oval.set(cx + gazeX - rp, cy + gazeY - rp * lid, cx + gazeX + rp, cy + gazeY + rp * lid)
        canvas.drawOval(oval, fill)

        // 천천히 움직이는 동안만 다시 그린다(초당 약 18번). 잠든 눈은 멈춘다.
        if (moving && windowShown) {
            if (sleepShown != sleepTarget) postInvalidateDelayed(16L)
            else if (sleepTarget == 0f) postInvalidateDelayed(55L)
        }
    }

    private fun animationsEnabled(c: Context): Boolean = try {
        Settings.Global.getFloat(c.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) > 0f
    } catch (e: Exception) {
        true
    }
}
