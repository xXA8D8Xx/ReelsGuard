package com.example.reelsguard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.provider.Settings
import android.view.View
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * 앱 아이콘과 같은 세라핌: 양쪽 날개 세 개(위·가운데·아래) × 깃털 세 장 = 한쪽 9장, 모두 18장.
 * 화면에 붙으면 아래로 접혀 있던 날개가 눈이 떠지면서 차례로 펼쳐지고,
 * 다 펼쳐지면 빛의 고리가 한 번 퍼진 뒤 천천히 숨 쉬듯 움직인다.
 * 애니메이션을 끄면(설정 또는 기기 설정) 처음부터 활짝 펼쳐진 모습으로 멈춰 있다.
 */
class SeraphView(context: Context, private val startDelayMs: Long = 0L) : View(context) {

    private class Feather(
        val bx: Float,
        val by: Float,
        val fx: Float,
        val fy: Float,
        val half: Float,
        val alpha: Float,
        val wing: Int,
        val idx: Int
    ) {
        val angle: Float = atan2(fy - by, fx - bx)   // 완전히 펼쳤을 때의 방향
        val length: Float = hypot(fx - bx, fy - by)  // 완전히 펼쳤을 때의 길이
    }

    private val feathers = ArrayList<Feather>()

    private val gold = Color.parseColor(Palette.GOLD)
    private val ivory = Color.parseColor(Palette.TEXT)
    private val bg = Color.parseColor(Palette.BG)
    private val edge = Color.parseColor(Palette.SURFACE)

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val oval = RectF()

    private val moving: Boolean = Prefs.eyeMotionOn(context) && animationsEnabled(context)
    private var t0 = 0L
    private var windowShown = true

    init {
        // 아이콘과 같은 좌표(108 기준). 기준점·끝점·두께·투명도
        val wings = arrayOf(
            floatArrayOf(57f, 46f, 4.6f, 1.00f, 79f, 17f, 85f, 25f, 87f, 34f),   // 위
            floatArrayOf(58f, 54f, 4.6f, 0.80f, 96f, 44f, 99f, 53f, 96f, 62f),   // 가운데
            floatArrayOf(57f, 62f, 4.2f, 0.60f, 85f, 75f, 81f, 84f, 73f, 89f)    // 아래
        )
        for (w in wings.indices) {
            val d = wings[w]
            for (i in 0 until 3) {
                feathers.add(Feather(d[0], d[1], d[4 + 2 * i], d[5 + 2 * i], d[2], d[3], w, i))
            }
        }
        fill.style = Paint.Style.FILL
        stroke.style = Paint.Style.STROKE
        stroke.strokeJoin = Paint.Join.ROUND
        stroke.strokeCap = Paint.Cap.ROUND
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        t0 = SystemClock.uptimeMillis()
        invalidate()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        windowShown = visibility == VISIBLE
        if (windowShown) invalidate()
    }

    private fun easeOutBack(x: Float): Float {
        val c1 = 1.25f
        val c3 = c1 + 1f
        val u = x - 1f
        return 1f + c3 * u * u * u + c1 * u * u
    }

    private fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val s = min(w / 96f, h / 80f)
        val ox = w / 2f - 54f * s
        val oy = h * 0.52f - 54f * s

        val now = SystemClock.uptimeMillis()
        if (t0 == 0L) t0 = now
        val elapsed = if (moving) (now - t0 - startDelayMs).toFloat() else OPEN_MS * 3f
        val p = (elapsed / OPEN_MS).coerceIn(0f, 1f)
        val open = p >= 1f
        val twoPi = (2.0 * PI).toFloat()
        val idleT = max(0f, elapsed - OPEN_MS)

        // ----- 깃털 18장(양쪽 9장씩): 위 → 가운데 → 아래 순으로 펼친다 -----
        for (side in intArrayOf(1, -1)) {
            for (f in feathers) {
                val delay = f.wing * 0.10f + f.idx * 0.05f
                val q = ((p - delay) / (1f - 0.30f)).coerceIn(0f, 1f)
                val e = easeOutBack(q)

                val foldAngle = Math.toRadians(100.0 + (f.idx - 1) * 7.0).toFloat()
                var ang = lerp(foldAngle, f.angle, e)
                val len = lerp(f.length * 0.62f, f.length, e)
                if (moving && open) ang += sin(idleT * twoPi / 4800f + f.wing * 0.8f) * 0.035f

                val tx = f.bx + cos(ang) * len
                val ty = f.by + sin(ang) * len
                val x0 = if (side == 1) f.bx else 108f - f.bx
                val x1 = if (side == 1) tx else 108f - tx

                val a = f.alpha * (0.35f + 0.65f * min(1f, q * 1.5f))
                drawFeather(
                    canvas,
                    ox + x0 * s, oy + f.by * s,
                    ox + x1 * s, oy + ty * s,
                    f.half * s, a, s
                )
            }
        }

        // ----- 가운데: 광륜 + 눈(날개와 함께 떠진다) -----
        val cx = ox + 54f * s
        val cy = oy + 54f * s
        val lid = if (open) {
            if (moving) blinkLid(idleT) else 1f
        } else {
            0.06f + 0.94f * min(1f, p * 1.2f)
        }
        val gazeX = if (moving && open) sin(idleT * twoPi / 7200f) * 7f * 0.30f * s else 0f

        stroke.color = gold
        stroke.alpha = (255f * (0.35f + 0.65f * min(1f, p * 1.5f))).toInt()
        stroke.strokeWidth = 1.7f * s
        oval.set(cx - 10f * s, oy + 33f * s - 3f * s, cx + 10f * s, oy + 33f * s + 3f * s)
        canvas.drawOval(oval, stroke)

        val a = 14f * s
        val b = 7f * s * lid
        path.reset()
        path.moveTo(cx - a, cy)
        path.quadTo(cx, cy - 2f * b, cx + a, cy)
        path.quadTo(cx, cy + 2f * b, cx - a, cy)
        path.close()
        fill.color = bg
        fill.alpha = 255
        canvas.drawPath(path, fill)
        stroke.alpha = 255
        stroke.strokeWidth = 2.3f * s
        canvas.drawPath(path, stroke)

        stroke.strokeWidth = 1.8f * s
        oval.set(cx + gazeX - 5.6f * s, cy - 5.6f * s * lid, cx + gazeX + 5.6f * s, cy + 5.6f * s * lid)
        canvas.drawOval(oval, stroke)
        fill.color = gold
        fill.alpha = 255
        oval.set(cx + gazeX - 2.4f * s, cy - 2.4f * s * lid, cx + gazeX + 2.4f * s, cy + 2.4f * s * lid)
        canvas.drawOval(oval, fill)

        // ----- 다 펼쳐진 직후 빛의 고리가 한 번 퍼진다 -----
        if (moving) {
            val rp = (elapsed - OPEN_MS * 0.85f) / 1000f
            if (rp in 0f..1f) {
                stroke.color = gold
                stroke.alpha = ((1f - rp) * 0.55f * 255f).toInt()
                stroke.strokeWidth = 1.2f * s * (1f - rp) + 0.4f
                canvas.drawCircle(cx, cy, (16f + 36f * rp) * s, stroke)
            }
        }

        // 움직이는 동안만 다시 그린다(펼치는 동안은 부드럽게, 그 뒤에는 느리게)
        if (moving && windowShown) postInvalidateDelayed(if (elapsed < OPEN_MS + 1200f) 16L else 40L)
    }

    /** 다 펼친 뒤 6.5초마다 한 번 느리게 깜빡인다. */
    private fun blinkLid(idleT: Float): Float {
        val ph = ((idleT.toLong() + 3500L) % 6500L).toFloat()
        val blink = if (ph < 700f) sin(ph / 700f * PI.toFloat()) else 0f
        return 1f - 0.92f * blink
    }

    /** 끝이 뾰족한 잎 모양 깃털 하나. */
    private fun drawFeather(
        canvas: Canvas,
        bx: Float, by: Float, tx: Float, ty: Float,
        half: Float, alpha: Float, s: Float
    ) {
        val dx = tx - bx
        val dy = ty - by
        val l = hypot(dx, dy)
        if (l < 1f) return
        val nx = -dy / l
        val ny = dx / l

        path.reset()
        path.moveTo(bx, by)
        path.cubicTo(
            bx + dx * 0.30f + nx * half, by + dy * 0.30f + ny * half,
            bx + dx * 0.72f + nx * half * 0.9f, by + dy * 0.72f + ny * half * 0.9f,
            tx, ty
        )
        path.cubicTo(
            bx + dx * 0.72f - nx * half * 0.9f, by + dy * 0.72f - ny * half * 0.9f,
            bx + dx * 0.30f - nx * half, by + dy * 0.30f - ny * half,
            bx, by
        )
        path.close()

        val al = (alpha * 255f).toInt().coerceIn(0, 255)
        fill.color = ivory
        fill.alpha = al
        canvas.drawPath(path, fill)
        stroke.color = edge
        stroke.alpha = al
        stroke.strokeWidth = 0.9f * s
        canvas.drawPath(path, stroke)
    }

    private fun animationsEnabled(c: Context): Boolean = try {
        Settings.Global.getFloat(c.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) > 0f
    } catch (e: Exception) {
        true
    }

    companion object {
        /** 날개가 다 펼쳐지기까지 걸리는 시간. */
        private const val OPEN_MS = 1700f
    }
}
