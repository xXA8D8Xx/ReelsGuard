package com.example.reelsguard

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.util.Random
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/**
 * 코드로 직접 합성하는 '영롱한' 종소리. 음원 파일이 필요 없다.
 *
 * - 경고음: 명언(seed)마다 음 높이·순서·간격이 달라지는 3~4음 아르페지오 + 여운음.
 * - 종료음: 더 길고 풍성한 상승 아르페지오 + 마지막 화음 + 낮은 패드 + 긴 울림.
 * 볼륨은 기기의 '알림 볼륨'을 따른다.
 */
object Chime {
    private const val SR = 22050

    // 도 레 미 솔 라 펜타토닉(5옥타브 → 6옥타브 위쪽까지)
    private val SCALE = doubleArrayOf(
        523.25, 587.33, 659.25, 783.99, 880.00,
        1046.50, 1174.66, 1318.51, 1567.98, 1760.00
    )

    // 종(벨) 소리 배음 구성
    private val PARTIAL_MULT = doubleArrayOf(1.0, 2.0, 3.0, 4.2)
    private val PARTIAL_AMP = doubleArrayOf(1.0, 0.38, 0.17, 0.08)
    private val PARTIAL_DECAY = doubleArrayOf(1.0, 1.4, 2.0, 3.0)

    // (지연 초, 세기)
    private val ECHOES = arrayOf(doubleArrayOf(0.19, 0.34), doubleArrayOf(0.37, 0.20), doubleArrayOf(0.58, 0.10))

    private class Note(val start: Double, val freq: Double, val amp: Double)

    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private var current: AudioTrack? = null

    fun playWarning(c: Context, seed: Int) {
        if (!Prefs.soundOn(c)) return
        worker.execute {
            try {
                play(render(seed, false))
            } catch (e: Exception) {
                Log.w("Chime", "경고음 재생 실패: ${e.message}")
            }
        }
    }

    fun playFarewell(c: Context, seed: Int) {
        if (!Prefs.soundOn(c)) return
        worker.execute {
            try {
                play(render(seed, true))
            } catch (e: Exception) {
                Log.w("Chime", "종료음 재생 실패: ${e.message}")
            }
        }
    }

    /** 열기 전 숨 고르기: 깊고 낮은 종이 두 번, 천천히 울린다. */
    fun playPause(c: Context) {
        if (!Prefs.soundOn(c)) return
        worker.execute {
            try {
                play(renderToll())
            } catch (e: Exception) {
                Log.w("Chime", "숨 고르기 소리 재생 실패: ${e.message}")
            }
        }
    }

    // ---------- 재생 ----------

    private fun play(pcm: ShortArray) {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SR)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()
        val track = AudioTrack.Builder()
            .setAudioAttributes(attrs)
            .setAudioFormat(format)
            .setBufferSizeInBytes(pcm.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track.write(pcm, 0, pcm.size)

        synchronized(this) {
            val old = current
            if (old != null) releaseQuietly(old)
            current = track
        }
        track.play()

        val ms = pcm.size * 1000L / SR + 400L
        main.postDelayed({
            synchronized(this) {
                if (current === track) current = null
            }
            releaseQuietly(track)
        }, ms)
    }

    private fun releaseQuietly(t: AudioTrack) {
        try {
            t.stop()
        } catch (e: Exception) {
            // 이미 멈춤
        }
        try {
            t.release()
        } catch (e: Exception) {
            // 이미 해제됨
        }
    }

    // ---------- 합성 ----------

    private fun render(seed: Int, grand: Boolean): ShortArray {
        val rnd = Random(seed.toLong() * 6364136223846793005L + 1442695040888963407L)
        val notes = ArrayList<Note>()
        val decay: Double
        val tail: Double

        if (!grand) {
            val contours = arrayOf(
                intArrayOf(0, 2, 4),
                intArrayOf(0, 1, 3),
                intArrayOf(0, 3, 2, 4),
                intArrayOf(0, 2, 1, 4),
                intArrayOf(0, 1, 2, 4)
            )
            val contour = contours[rnd.nextInt(contours.size)]
            val base = rnd.nextInt(4)
            val gap = 0.085 + rnd.nextDouble() * 0.06
            for (i in contour.indices) {
                notes.add(Note(i * gap, SCALE[base + contour[i]], 1.0 - i * 0.06))
            }
            // 마지막에 한 옥타브 위 여운음
            notes.add(Note(contour.size * gap + 0.02, SCALE[base + contour[contour.size - 1]] * 2.0, 0.35))
            decay = 3.2
            tail = 1.4
        } else {
            val base = rnd.nextInt(2)
            val gap = 0.115 + rnd.nextDouble() * 0.03
            val run = 7
            for (i in 0 until run) {
                notes.add(Note(i * gap, SCALE[base + i], 0.75 + i * 0.04))
            }
            val end = run * gap + 0.05
            // 마지막 화음
            for (s in intArrayOf(2, 4, 7)) {
                notes.add(Note(end, SCALE[base + s], 0.8))
            }
            decay = 1.7
            tail = 3.0
        }

        var lastStart = 0.0
        for (n in notes) if (n.start > lastStart) lastStart = n.start

        val echoTail = 0.65
        val total = ((lastStart + tail + echoTail) * SR).toInt()
        val dry = FloatArray(total)

        for (n in notes) addNote(dry, n, decay)
        if (grand) addPad(dry, 261.63, 3.4)

        // 에코(울림)
        val wet = FloatArray(total)
        for (i in 0 until total) {
            var v = dry[i]
            for (e in ECHOES) {
                val j = i - (e[0] * SR).toInt()
                if (j >= 0) v += dry[j] * e[1].toFloat()
            }
            wet[i] = v
        }

        // 정규화 + 끝부분 페이드아웃(딸깍 소리 방지)
        var peak = 0f
        for (v in wet) {
            val a = if (v < 0f) -v else v
            if (a > peak) peak = a
        }
        val scale = if (peak > 0f) 0.85f / peak else 1f
        val fade = (0.15 * SR).toInt()
        val out = ShortArray(total)
        for (i in 0 until total) {
            var g = scale
            val left = total - i
            if (left < fade) g *= left.toFloat() / fade
            val s = (wet[i] * g * 32767f).toInt().coerceIn(-32768, 32767)
            out[i] = s.toShort()
        }
        return out
    }

    private val TOLL_MULT = doubleArrayOf(0.5, 1.0, 2.0, 2.4, 3.0, 4.1)
    private val TOLL_AMP = doubleArrayOf(0.35, 1.0, 0.65, 0.30, 0.16, 0.08)
    private val TOLL_DECAY = doubleArrayOf(0.55, 0.60, 0.85, 1.05, 1.5, 2.2)

    private fun renderToll(): ShortArray {
        val total = (7.2 * SR).toInt()
        val buf = FloatArray(total)
        addToll(buf, 0.0, 146.83, 1.0)      // 레(D3)
        addToll(buf, 2.0, 110.00, 0.85)     // 라(A2): 더 낮게 한 번 더
        val wet = FloatArray(total)
        for (i in 0 until total) {
            var v = buf[i]
            val j1 = i - (0.31 * SR).toInt()
            val j2 = i - (0.62 * SR).toInt()
            if (j1 >= 0) v += buf[j1] * 0.28f
            if (j2 >= 0) v += buf[j2] * 0.14f
            wet[i] = v
        }
        var peak = 0f
        for (v in wet) { val a = if (v < 0f) -v else v; if (a > peak) peak = a }
        val scale = if (peak > 0f) 0.85f / peak else 1f
        val fade = (0.4 * SR).toInt()
        val out = ShortArray(total)
        for (i in 0 until total) {
            var g = scale
            val left = total - i
            if (left < fade) g *= left.toFloat() / fade
            out[i] = (wet[i] * g * 32767f).toInt().coerceIn(-32768, 32767).toShort()
        }
        return out
    }

    private fun addToll(buf: FloatArray, start: Double, freq: Double, amp: Double) {
        val s0 = (start * SR).toInt()
        val twoPi = 2.0 * PI
        val len = min(buf.size - s0, (SR * 5.2).toInt())
        for (i in 0 until len) {
            val t = i / SR.toDouble()
            val attack = 1.0 - exp(-t * 90.0)         // 쾅 하고 치기보다 둥글게 시작
            var v = 0.0
            for (p in TOLL_MULT.indices) {
                val fr = freq * TOLL_MULT[p]
                v += TOLL_AMP[p] * exp(-t * TOLL_DECAY[p]) * sin(twoPi * fr * t)
            }
            buf[s0 + i] += (amp * attack * v * 0.35).toFloat()
        }
    }

    private fun addNote(buf: FloatArray, n: Note, decay: Double) {
        val s0 = (n.start * SR).toInt()
        if (s0 >= buf.size) return
        val len = min(buf.size - s0, (SR * 4.0).toInt())
        val twoPi = 2.0 * PI
        for (i in 0 until len) {
            val t = i / SR.toDouble()
            if (t * decay > 7.0) break
            val attack = 1.0 - exp(-t * 600.0)
            var v = 0.0
            for (p in PARTIAL_MULT.indices) {
                val fr = n.freq * PARTIAL_MULT[p]
                if (fr > SR / 2.1) continue
                val env = exp(-t * decay * PARTIAL_DECAY[p])
                // 살짝 어긋난 짝 음을 섞어 반짝이는 울림을 만든다
                v += PARTIAL_AMP[p] * env * (sin(twoPi * fr * t) + 0.5 * sin(twoPi * fr * 1.004 * t))
            }
            buf[s0 + i] += (n.amp * attack * v * 0.3).toFloat()
        }
    }

    private fun addPad(buf: FloatArray, freq: Double, seconds: Double) {
        val len = min(buf.size, (seconds * SR).toInt())
        val twoPi = 2.0 * PI
        for (i in 0 until len) {
            val t = i / SR.toDouble()
            val env = (1.0 - exp(-t * 6.0)) * exp(-t * 0.9)
            buf[i] += (0.28 * env * (sin(twoPi * freq * t) + 0.4 * sin(twoPi * freq * 2.0 * t))).toFloat()
        }
    }
}
