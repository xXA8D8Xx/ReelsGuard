package com.example.reelsguard

import android.content.Context
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.time.LocalDate
import java.util.Base64
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

/**
 * 백업·복원. 작고 단순하게:
 * - 설정·명언·숨 고르기 문구·연속 기록 시작일 + 날짜별 통계를 줄 단위 글자로 적고 gzip 으로 압축한다
 *   (400일치 통계가 가득 차 있어도 수 KB). 파일로 저장하거나 글자(Base64)로 복사해 어디든 붙여 둘 수 있다.
 * - 복원은 '합치기'다. 통계는 날짜·항목마다 더 큰 값을 남기고, 오늘의 확정·긴급 해제·열기 기록은 건드리지 않으며,
 *   확정 중이거나 야간에는 아예 복원하지 않는다(백업으로 한도를 몰래 푸는 것을 막는다).
 *
 * 글자 형식(gzip 하기 전):
 *   RG1
 *   P<TAB>키<TAB>종류(i/l/b/s)<TAB>값
 *   S<TAB>YYYY-MM-DD<TAB>항목=값,항목=값,...
 */
object Backup {
    private const val MAGIC = "RG1"
    private const val MAX_PLAIN = 2 * 1024 * 1024
    private const val MAX_STRING = 20_000
    private val NAME = Regex("[a-z0-9_]{1,16}")
    private const val KEY_SINCE = "streak_since"

    class Summary(val settings: Int, val days: Int)

    // ---------- 내보내기 ----------

    fun build(c: Context): String {
        val sb = StringBuilder(4096)
        sb.append(MAGIC).append('\n')

        val all = Prefs.rawPrefs(c).all
        for (key in Prefs.BACKUP_KEYS.sorted()) {
            val v = all[key] ?: continue
            val type = when (v) {
                is Int -> "i"
                is Long -> "l"
                is Boolean -> "b"
                is String -> "s"
                else -> continue
            }
            sb.append("P\t").append(key).append('\t').append(type).append('\t').append(esc(v.toString())).append('\n')
        }
        sb.append("P\t").append(KEY_SINCE).append("\ts\t").append(Prefs.streakSince(c)).append('\n')

        // 날짜별로 묶는다: "2026-10-10_ig_ms" → 날짜 / 항목
        val byDay = java.util.TreeMap<String, StringBuilder>()
        for ((k, v) in Stats.rawPrefs(c).all) {
            if (v !is Long || v <= 0L || k.length < 12 || k[10] != '_') continue
            val day = k.substring(0, 10)
            val name = k.substring(11)
            if (!NAME.matches(name)) continue
            val b = byDay.getOrPut(day) { StringBuilder() }
            if (b.isNotEmpty()) b.append(',')
            b.append(name).append('=').append(v)
        }
        for ((day, b) in byDay) sb.append("S\t").append(day).append('\t').append(b).append('\n')
        return sb.toString()
    }

    fun export(c: Context): ByteArray {
        val bos = ByteArrayOutputStream()
        GZIPOutputStream(bos).use { it.write(build(c).toByteArray(Charsets.UTF_8)) }
        return bos.toByteArray()
    }

    fun exportText(c: Context): String = Base64.getEncoder().encodeToString(export(c))

    // ---------- 읽기 ----------

    /** gzip 바이트 → 글자. 형식이 아니면 null. */
    fun decode(bytes: ByteArray): String? {
        return try {
            val out = ByteArrayOutputStream()
            GZIPInputStream(ByteArrayInputStream(bytes)).use { gz ->
                val buf = ByteArray(8192)
                while (true) {
                    val n = gz.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    if (out.size() > MAX_PLAIN) return null
                }
            }
            val s = out.toString("UTF-8")
            if (s.startsWith("$MAGIC\n")) s else null
        } catch (e: Exception) {
            null
        }
    }

    /** 복사해 둔 글자(Base64) → 글자. 공백·줄바꿈은 무시한다. */
    fun decodeText(text: String): String? {
        return try {
            val clean = text.filter { !it.isWhitespace() }
            if (clean.isEmpty() || clean.length > 4 * MAX_PLAIN) return null
            decode(Base64.getDecoder().decode(clean))
        } catch (e: Exception) {
            null
        }
    }

    fun summarize(plain: String): Summary? {
        if (!plain.startsWith("$MAGIC\n")) return null
        var p = 0
        var s = 0
        for (line in plain.lineSequence()) {
            if (line.startsWith("P\t")) p++ else if (line.startsWith("S\t")) s++
        }
        return Summary(p, s)
    }

    /** 복원이 막혀 있으면 이유를, 아니면 null. */
    fun blockedReason(c: Context): String? = when {
        Prefs.isLockedToday(c) -> "오늘 한도를 확정해서 복원할 수 없어요. 새벽 4시 이후에 해 주세요."
        Prefs.isNight(c) -> "야간 차단 중이라 복원할 수 없어요."
        else -> null
    }

    /** 합쳐 넣는다. 성공하면 null, 실패하면 이유. */
    fun apply(c: Context, plain: String): String? {
        blockedReason(c)?.let { return it }
        if (!plain.startsWith("$MAGIC\n")) return "백업 형식이 아니에요"

        val ints = ArrayList<Triple<String, String, String>>()
        var since: LocalDate? = null
        val stats = ArrayList<Triple<String, String, Long>>()
        val today = Day.today()
        val oldest = today.minusDays(Stats.KEEP_DAYS)

        for (line in plain.lineSequence().drop(1)) {
            if (line.isEmpty()) continue
            val f = line.split('\t')
            when (f[0]) {
                "P" -> {
                    if (f.size < 4) continue
                    val key = f[1]
                    val type = f[2]
                    val value = unesc(f[3])
                    if (value.length > MAX_STRING) continue
                    if (key == KEY_SINCE) {
                        since = try { LocalDate.parse(value) } catch (e: Exception) { null }
                    } else if (key in Prefs.BACKUP_KEYS && type in listOf("i", "l", "b", "s")) {
                        ints.add(Triple(key, type, value))
                    }
                }
                "S" -> {
                    if (f.size < 3) continue
                    val day = try { LocalDate.parse(f[1]) } catch (e: Exception) { continue }
                    if (day.isBefore(oldest) || day.isAfter(today.plusDays(1))) continue
                    for (pair in f[2].split(',')) {
                        val eq = pair.indexOf('=')
                        if (eq <= 0) continue
                        val name = pair.substring(0, eq)
                        val v = pair.substring(eq + 1).toLongOrNull() ?: continue
                        if (!NAME.matches(name) || v <= 0L || v > 1_000_000_000_000L) continue
                        stats.add(Triple(day.toString(), name, v))
                    }
                }
            }
        }

        Prefs.restoreValues(c, ints)
        if (since != null) Prefs.mergeStreakSince(c, since)
        Stats.mergeMax(c, stats)
        return null
    }

    // ---------- 글자 이스케이프 ----------

    private fun esc(s: String): String {
        val sb = StringBuilder(s.length + 8)
        for (ch in s) {
            when (ch) {
                '\\' -> sb.append("\\\\")
                '\t' -> sb.append("\\t")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    private fun unesc(s: String): String {
        if (s.indexOf('\\') < 0) return s
        val sb = StringBuilder(s.length)
        var i = 0
        while (i < s.length) {
            val ch = s[i]
            if (ch == '\\' && i + 1 < s.length) {
                when (s[i + 1]) {
                    't' -> sb.append('\t')
                    'n' -> sb.append('\n')
                    'r' -> sb.append('\r')
                    else -> sb.append(s[i + 1])
                }
                i += 2
            } else {
                sb.append(ch)
                i++
            }
        }
        return sb.toString()
    }
}
