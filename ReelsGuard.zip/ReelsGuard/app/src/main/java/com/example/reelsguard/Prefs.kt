package com.example.reelsguard

import android.content.Context
import org.json.JSONArray
import java.time.LocalDate

/** 설정·상태 저장소. 앱 화면과 접근성 서비스가 같은 값을 읽고 쓴다. */
object Prefs {
    private const val FILE = "reelsguard"
    private const val KEY_LIMIT = "limit"
    private const val KEY_LOCK_DATE = "lock_date"
    private const val KEY_USED = "used"
    private const val KEY_USED_DATE = "used_date"
    private const val KEY_QUOTES = "quotes"

    const val MAX_LIMIT = 99

    val DEFAULT_QUOTES = listOf(
        "시간은 금이다",
        "내가 바뀌지 않으면 바뀌는 것은 아무것도 없다",
        "사랑하라",
        "아름다움을 찾아라"
    )

    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    private fun today(): String = LocalDate.now().toString()

    // ---------- 하루 스크롤 횟수 ----------

    /** 현재 적용 중인 하루 허용 횟수(확정한 적이 없으면 0 = 완전 차단). */
    fun limit(c: Context): Int = sp(c).getInt(KEY_LIMIT, 0)

    /** 오늘 이미 횟수를 확정했는지(확정하면 자정까지 수정 불가). */
    fun isLockedToday(c: Context): Boolean = sp(c).getString(KEY_LOCK_DATE, "") == today()

    /** 횟수를 확정한다. 오늘 이미 확정했다면 false 를 돌려주고 아무것도 바꾸지 않는다. */
    fun confirmLimit(c: Context, n: Int): Boolean {
        if (isLockedToday(c)) return false
        sp(c).edit()
            .putInt(KEY_LIMIT, n.coerceIn(0, MAX_LIMIT))
            .putString(KEY_LOCK_DATE, today())
            .apply()
        return true
    }

    /** 오늘 사용한 스크롤 횟수(날짜가 바뀌면 자동으로 0). */
    fun used(c: Context): Int {
        val p = sp(c)
        return if (p.getString(KEY_USED_DATE, "") == today()) p.getInt(KEY_USED, 0) else 0
    }

    fun remaining(c: Context): Int = (limit(c) - used(c)).coerceAtLeast(0)

    fun addUsed(c: Context) {
        sp(c).edit()
            .putString(KEY_USED_DATE, today())
            .putInt(KEY_USED, used(c) + 1)
            .apply()
    }

    // ---------- 명언 ----------

    fun quotes(c: Context): List<String> {
        val raw = sp(c).getString(KEY_QUOTES, null) ?: return DEFAULT_QUOTES
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: Exception) {
            DEFAULT_QUOTES
        }
    }

    private fun saveQuotes(c: Context, list: List<String>) {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        sp(c).edit().putString(KEY_QUOTES, arr.toString()).apply()
    }

    fun addQuote(c: Context, text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty()) return false
        val cur = quotes(c)
        if (cur.contains(t)) return false
        saveQuotes(c, cur + t)
        return true
    }

    fun removeQuote(c: Context, index: Int) {
        val cur = quotes(c).toMutableList()
        if (index in cur.indices) {
            cur.removeAt(index)
            saveQuotes(c, cur)
        }
    }

    /** 경고창에 띄울 명언 하나. 목록이 비어 있으면 기본 명언을 쓴다. */
    fun randomQuote(c: Context): String = quotes(c).ifEmpty { DEFAULT_QUOTES }.random()
}
