package com.example.reelsguard

import android.content.Context
import org.json.JSONArray
import java.time.LocalDate
import java.time.LocalTime

/** 설정 저장소. 앱 화면과 접근성 서비스가 같은 값을 읽고 쓴다. */
object Prefs {
    private const val FILE = "reelsguard"
    private const val KEY_LIMIT = "limit"              // 하루 릴스 스와이프 허용 횟수
    private const val KEY_FEED = "limit_feed"          // 하루 홈 피드 허용 화면 수
    private const val KEY_EXPLORE = "limit_explore"    // 하루 탐색 탭 허용 화면 수
    private const val KEY_LOCK_DATE = "lock_date"
    private const val KEY_QUOTES = "quotes"
    private const val KEY_SOUND = "sound"
    private const val KEY_NOTICE = "notice"
    private const val KEY_EYE_MOTION = "eye_motion"
    private const val KEY_NIGHT_ON = "night_on"
    private const val KEY_NIGHT_START = "night_start"
    private const val KEY_NIGHT_END = "night_end"

    private const val KEY_EM_DATE = "em_date"
    private const val KEY_EM_COUNT = "em_count"
    private const val KEY_EM_UNTIL = "em_until"
    private const val KEY_SINCE = "streak_since"
    private const val KEY_PAUSE_ON = "pause_on"
    private const val KEY_PAUSE_PHRASES = "pause_phrases"
    private const val KEY_OPENS = "opens"
    private const val KEY_REELS_TAB_LOCK = "reels_tab_lock"

    /** 긴급 해제 이유(통계에 이 순서로 쌓인다). */
    val EMERGENCY_REASONS = listOf("팔로우", "피드 확인", "검색", "DM", "심심함", "기타")

    /** 한 시간에 이만큼은 그냥 열 수 있고, 그 다음부터 숨 고르기가 나온다. */
    const val FREE_OPENS_PER_HOUR = 2

    const val EMERGENCY_PER_DAY = 2
    const val EMERGENCY_MS = 5 * 60 * 1000L

    const val MAX_LIMIT = 99
    const val DEFAULT_FEED = 15
    const val DEFAULT_EXPLORE = 8
    const val DEFAULT_NIGHT_START = 23
    const val DEFAULT_NIGHT_END = 7

    val DEFAULT_QUOTES = listOf(
        "시간은 금이다",
        "내가 바뀌지 않으면 바뀌는 것은 아무것도 없다",
        "사랑하라",
        "아름다움을 찾아라"
    )

    val DEFAULT_PAUSE_PHRASES = listOf(
        "왜 또다시 찾아왔나요?",
        "더 나은 곳에 시간을 쓰셔도 좋습니다.",
        "창문 밖은 아름답습니다",
        "손이 먼저 움직인 건 아닐까요?",
        "지금 정말 필요한가요?",
        "숨을 깊게 한 번 쉬어 보세요",
        "방금 닫았는데, 또 열었어요"
    )

    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    private fun today(): String = Day.today().toString()

    // ---------- 하루 한도 ----------

    /** 하루 릴스 스와이프 허용 횟수(확정한 적이 없으면 0 = 완전 차단). */
    fun limit(c: Context): Int = sp(c).getInt(KEY_LIMIT, 0)

    /** 하루 홈 피드 허용 화면 수. */
    fun feedLimit(c: Context): Int = sp(c).getInt(KEY_FEED, DEFAULT_FEED)

    /** 하루 탐색 탭 허용 화면 수. */
    fun exploreLimit(c: Context): Int = sp(c).getInt(KEY_EXPLORE, DEFAULT_EXPLORE)

    /** 오늘 이미 한도를 확정했는지(확정하면 새벽 4시까지 수정 불가). */
    fun isLockedToday(c: Context): Boolean = sp(c).getString(KEY_LOCK_DATE, "") == today()

    /** 한도를 확정한다. 오늘 이미 확정했다면 false 를 돌려주고 아무것도 바꾸지 않는다. */
    fun confirmLimits(
        c: Context,
        reels: Int,
        feed: Int,
        explore: Int,
        nightStart: Int,
        nightEnd: Int,
        reelsTabLock: Boolean = reelsTabLock(c)
    ): Boolean {
        // 이미 확정했거나 야간 차단 중이면 바꿀 수 없다(밤에 몰래 풀어 버리는 것을 막는다)
        if (isLockedToday(c) || isNight(c)) return false
        sp(c).edit()
            .putInt(KEY_LIMIT, reels.coerceIn(0, MAX_LIMIT))
            .putInt(KEY_FEED, feed.coerceIn(0, MAX_LIMIT))
            .putInt(KEY_EXPLORE, explore.coerceIn(0, MAX_LIMIT))
            .putInt(KEY_NIGHT_START, nightStart.coerceIn(0, 23))
            .putInt(KEY_NIGHT_END, nightEnd.coerceIn(0, 23))
            .putBoolean(KEY_REELS_TAB_LOCK, reelsTabLock)
            .putString(KEY_LOCK_DATE, today())
            .apply()
        return true
    }

    // ---------- 릴스 탭 잠금 ----------

    /** true(기본): 릴스 탭은 늘 잠김. false: 스와이프 한도를 다 쓴 뒤에 잠긴다. */
    fun reelsTabLock(c: Context): Boolean = sp(c).getBoolean(KEY_REELS_TAB_LOCK, true)

    // ---------- 열기 전 숨 고르기 ----------

    fun pauseOn(c: Context): Boolean = sp(c).getBoolean(KEY_PAUSE_ON, true)

    fun setPauseOn(c: Context, on: Boolean) {
        sp(c).edit().putBoolean(KEY_PAUSE_ON, on).apply()
    }

    /** 인스타그램을 연 것을 기록하고, 지난 한 시간 동안 (이번 것까지) 몇 번 열었는지 돌려준다. */
    fun recordOpen(c: Context, now: Long = System.currentTimeMillis()): Int {
        val hour = 60 * 60 * 1000L
        val kept = ArrayList<Long>()
        val raw = sp(c).getString(KEY_OPENS, "") ?: ""
        for (p in raw.split(",")) {
            val v = p.toLongOrNull() ?: continue
            if (now - v in 0 until hour) kept.add(v)
        }
        kept.add(now)
        sp(c).edit().putString(KEY_OPENS, kept.joinToString(",")).apply()
        return kept.size
    }

    // ---------- 긴급 해제 ----------
    // 하루 2번, 5분 동안 홈 피드·탐색 탭의 제한만 없앤다(릴스와 야간 차단은 그대로).

    fun emergencyUsed(c: Context): Int =
        if (sp(c).getString(KEY_EM_DATE, "") == today()) sp(c).getInt(KEY_EM_COUNT, 0) else 0

    fun emergencyLeft(c: Context): Int = (EMERGENCY_PER_DAY - emergencyUsed(c)).coerceAtLeast(0)

    /** 긴급 해제가 끝나는 시각(ms). 없으면 0. */
    fun emergencyUntil(c: Context): Long = sp(c).getLong(KEY_EM_UNTIL, 0L)

    fun emergencyRemainingMs(c: Context): Long =
        (emergencyUntil(c) - System.currentTimeMillis()).coerceIn(0L, EMERGENCY_MS)

    fun emergencyActive(c: Context): Boolean = emergencyRemainingMs(c) > 0L

    /** 긴급 해제를 시작한다. 횟수가 없거나 이미 켜져 있으면 false. */
    fun startEmergency(c: Context, reason: Int = EMERGENCY_REASONS.lastIndex): Boolean {
        if (emergencyActive(c) || emergencyLeft(c) <= 0) return false
        sp(c).edit()
            .putString(KEY_EM_DATE, today())
            .putInt(KEY_EM_COUNT, emergencyUsed(c) + 1)
            .putLong(KEY_EM_UNTIL, System.currentTimeMillis() + EMERGENCY_MS)
            .apply()
        Stats.add(c, Stats.EMERGENCY, 1L)
        Stats.add(c, Stats.reasonKey(reason.coerceIn(0, EMERGENCY_REASONS.lastIndex)), 1L)
        return true
    }

    // ---------- 연속 기록 ----------

    /** 기록을 세기 시작한 날(처음 쓴 날). 이전 날짜는 연속 기록에 넣지 않는다. */
    fun streakSince(c: Context): java.time.LocalDate {
        val raw = sp(c).getString(KEY_SINCE, null)
        if (raw != null) {
            try { return java.time.LocalDate.parse(raw) } catch (e: Exception) { }
        }
        val d = Day.today()
        sp(c).edit().putString(KEY_SINCE, d.toString()).apply()
        return d
    }

    // ---------- 야간 차단 ----------

    fun nightOn(c: Context): Boolean = sp(c).getBoolean(KEY_NIGHT_ON, true)

    /** 야간 차단을 켜고 끈다. 확정·잠금과 상관없이 언제든 바로 적용된다. */
    fun setNightOn(c: Context, on: Boolean) {
        sp(c).edit().putBoolean(KEY_NIGHT_ON, on).apply()
    }

    fun nightStart(c: Context): Int = sp(c).getInt(KEY_NIGHT_START, DEFAULT_NIGHT_START)

    fun nightEnd(c: Context): Int = sp(c).getInt(KEY_NIGHT_END, DEFAULT_NIGHT_END)

    /** 지금이 야간 차단 시간대인지. 시작과 종료가 같으면 차단하지 않는다. */
    fun isNight(c: Context): Boolean {
        if (!nightOn(c)) return false
        return inWindow(LocalTime.now().hour, nightStart(c), nightEnd(c))
    }

    /** hour 가 [start, end) 안에 있는지. 23→7 처럼 자정을 넘는 구간도 처리한다. */
    fun inWindow(hour: Int, start: Int, end: Int): Boolean {
        if (start == end) return false
        return if (start < end) hour in start until end else (hour >= start || hour < end)
    }

    /** 오늘 사용한 릴스 스와이프 횟수. */
    fun used(c: Context): Int = Stats.today(c, Stats.SWIPES).toInt()

    fun remaining(c: Context): Int = (limit(c) - used(c)).coerceAtLeast(0)

    // ---------- 소리 · 알림 ----------

    fun soundOn(c: Context): Boolean = sp(c).getBoolean(KEY_SOUND, true)

    fun setSoundOn(c: Context, on: Boolean) {
        sp(c).edit().putBoolean(KEY_SOUND, on).apply()
    }

    /** 눈이 천천히 움직이게 할지(끄면 정지). */
    fun eyeMotionOn(c: Context): Boolean = sp(c).getBoolean(KEY_EYE_MOTION, true)

    fun setEyeMotionOn(c: Context, on: Boolean) {
        sp(c).edit().putBoolean(KEY_EYE_MOTION, on).apply()
    }

    /** 페이지/스와이프 진행 알림을 띄울지. */
    fun noticeOn(c: Context): Boolean = sp(c).getBoolean(KEY_NOTICE, true)

    fun setNoticeOn(c: Context, on: Boolean) {
        sp(c).edit().putBoolean(KEY_NOTICE, on).apply()
    }

    // ---------- 명언 ----------

    fun quotes(c: Context): List<String> {
        val raw = sp(c).getString(KEY_QUOTES, null) ?: return DEFAULT_QUOTES
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: Exception) {
            DEFAULT_QUOTES
        }
    }

    private fun saveQuotes(c: Context, list: List<String>) {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        sp(c).edit().putString(KEY_QUOTES, arr.toString()).apply()
    }

    fun addQuote(c: Context, text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty()) return false
        val cur = quotes(c)
        if (cur.contains(t)) return false
        saveQuotes(c, cur + t)
        return true
    }

    fun removeQuote(c: Context, index: Int) {
        val cur = quotes(c).toMutableList()
        if (index in cur.indices) {
            cur.removeAt(index)
            saveQuotes(c, cur)
        }
    }

    // ---------- 숨 고르기 문구 ----------

    fun pausePhrases(c: Context): List<String> {
        val raw = sp(c).getString(KEY_PAUSE_PHRASES, null) ?: return DEFAULT_PAUSE_PHRASES
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: Exception) {
            DEFAULT_PAUSE_PHRASES
        }
    }

    private fun savePausePhrases(c: Context, list: List<String>) {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        sp(c).edit().putString(KEY_PAUSE_PHRASES, arr.toString()).apply()
    }

    fun addPausePhrase(c: Context, text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty()) return false
        val cur = pausePhrases(c)
        if (cur.contains(t)) return false
        savePausePhrases(c, cur + t)
        return true
    }

    fun removePausePhrase(c: Context, index: Int) {
        val cur = pausePhrases(c).toMutableList()
        if (index in cur.indices) {
            cur.removeAt(index)
            savePausePhrases(c, cur)
        }
    }

    /** 숨 고르기 화면에 띄울 문구 하나(바로 앞에 쓴 것은 피한다). 목록이 비면 기본 문구. */
    fun randomPausePhrase(c: Context, avoid: String? = null): String {
        val all = pausePhrases(c).ifEmpty { DEFAULT_PAUSE_PHRASES }
        val pool = if (all.size > 1) all.filter { it != avoid } else all
        return pool.random()
    }

    /** 경고창에 띄울 명언 하나. 목록이 비어 있으면 기본 명언을 쓴다. */
    fun randomQuote(c: Context): String = quotes(c).ifEmpty { DEFAULT_QUOTES }.random()
}
