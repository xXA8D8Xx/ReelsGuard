package com.example.reelsguard

import android.content.Context
import org.json.JSONArray
import java.time.LocalDate
import java.time.LocalTime

/** 설정 저장소. 앱 화면과 접근성 서비스가 같은 값을 읽고 쓴다. */
object Prefs {
    private const val FILE = "reelsguard"
    private const val KEY_LIMIT = "limit"              // 하루 릴스 스와이프 허용 횟수
    private const val KEY_FEED = "limit_feed"          // 하루 홈 피드 허용 화면 수
    private const val KEY_EXPLORE = "limit_explore"    // 하루 탐색 탭 허용 화면 수
    private const val KEY_LOCK_DATE = "lock_date"
    private const val KEY_QUOTES = "quotes"
    private const val KEY_SOUND = "sound"
    private const val KEY_NOTICE = "notice"
    private const val KEY_EYE_MOTION = "eye_motion"
    private const val KEY_NIGHT_ON = "night_on"
    private const val KEY_NIGHT_START = "night_start"
    private const val KEY_NIGHT_END = "night_end"

    const val MAX_LIMIT = 99
    const val DEFAULT_FEED = 15
    const val DEFAULT_EXPLORE = 8
    const val DEFAULT_NIGHT_START = 23
    const val DEFAULT_NIGHT_END = 7

    val DEFAULT_QUOTES = listOf(
        "시간은 금이다",
        "내가 바뀌지 않으면 바뀌는 것은 아무것도 없다",
        "사랑하라",
        "아름다움을 찾아라"
    )

    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    private fun today(): String = Day.today().toString()

    // ---------- 하루 한도 ----------

    /** 하루 릴스 스와이프 허용 횟수(확정한 적이 없으면 0 = 완전 차단). */
    fun limit(c: Context): Int = sp(c).getInt(KEY_LIMIT, 0)

    /** 하루 홈 피드 허용 화면 수. */
    fun feedLimit(c: Context): Int = sp(c).getInt(KEY_FEED, DEFAULT_FEED)

    /** 하루 탐색 탭 허용 화면 수. */
    fun exploreLimit(c: Context): Int = sp(c).getInt(KEY_EXPLORE, DEFAULT_EXPLORE)

    /** 오늘 이미 한도를 확정했는지(확정하면 새벽 4시까지 수정 불가). */
    fun isLockedToday(c: Context): Boolean = sp(c).getString(KEY_LOCK_DATE, "") == today()

    /** 한도를 확정한다. 오늘 이미 확정했다면 false 를 돌려주고 아무것도 바꾸지 않는다. */
    fun confirmLimits(
        c: Context,
        reels: Int,
        feed: Int,
        explore: Int,
        nightStart: Int,
        nightEnd: Int
    ): Boolean {
        // 이미 확정했거나 야간 차단 중이면 바꿀 수 없다(밤에 몰래 풀어 버리는 것을 막는다)
        if (isLockedToday(c) || isNight(c)) return false
        sp(c).edit()
            .putInt(KEY_LIMIT, reels.coerceIn(0, MAX_LIMIT))
            .putInt(KEY_FEED, feed.coerceIn(0, MAX_LIMIT))
            .putInt(KEY_EXPLORE, explore.coerceIn(0, MAX_LIMIT))
            .putInt(KEY_NIGHT_START, nightStart.coerceIn(0, 23))
            .putInt(KEY_NIGHT_END, nightEnd.coerceIn(0, 23))
            .putString(KEY_LOCK_DATE, today())
            .apply()
        return true
    }

    // ---------- 야간 차단 ----------

    fun nightOn(c: Context): Boolean = sp(c).getBoolean(KEY_NIGHT_ON, true)

    /** 야간 차단을 켜고 끈다. 확정·잠금과 상관없이 언제든 바로 적용된다. */
    fun setNightOn(c: Context, on: Boolean) {
        sp(c).edit().putBoolean(KEY_NIGHT_ON, on).apply()
    }

    fun nightStart(c: Context): Int = sp(c).getInt(KEY_NIGHT_START, DEFAULT_NIGHT_START)

    fun nightEnd(c: Context): Int = sp(c).getInt(KEY_NIGHT_END, DEFAULT_NIGHT_END)

    /** 지금이 야간 차단 시간대인지. 시작과 종료가 같으면 차단하지 않는다. */
    fun isNight(c: Context): Boolean {
        if (!nightOn(c)) return false
        return inWindow(LocalTime.now().hour, nightStart(c), nightEnd(c))
    }

    /** hour 가 [start, end) 안에 있는지. 23→7 처럼 자정을 넘는 구간도 처리한다. */
    fun inWindow(hour: Int, start: Int, end: Int): Boolean {
        if (start == end) return false
        return if (start < end) hour in start until end else (hour >= start || hour < end)
    }

    /** 오늘 사용한 릴스 스와이프 횟수. */
    fun used(c: Context): Int = Stats.today(c, Stats.SWIPES).toInt()

    fun remaining(c: Context): Int = (limit(c) - used(c)).coerceAtLeast(0)

    // ---------- 소리 · 알림 ----------

    fun soundOn(c: Context): Boolean = sp(c).getBoolean(KEY_SOUND, true)

    fun setSoundOn(c: Context, on: Boolean) {
        sp(c).edit().putBoolean(KEY_SOUND, on).apply()
    }

    /** 눈이 천천히 움직이게 할지(끄면 정지). */
    fun eyeMotionOn(c: Context): Boolean = sp(c).getBoolean(KEY_EYE_MOTION, true)

    fun setEyeMotionOn(c: Context, on: Boolean) {
        sp(c).edit().putBoolean(KEY_EYE_MOTION, on).apply()
    }

    /** 페이지/스와이프 진행 알림을 띄울지. */
    fun noticeOn(c: Context): Boolean = sp(c).getBoolean(KEY_NOTICE, true)

    fun setNoticeOn(c: Context, on: Boolean) {
        sp(c).edit().putBoolean(KEY_NOTICE, on).apply()
    }

    // ---------- 명언 ----------

    fun quotes(c: Context): List<String> {
        val raw = sp(c).getString(KEY_QUOTES, null) ?: return DEFAULT_QUOTES
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: Exception) {
            DEFAULT_QUOTES
        }
    }

    private fun saveQuotes(c: Context, list: List<String>) {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        sp(c).edit().putString(KEY_QUOTES, arr.toString()).apply()
    }

    fun addQuote(c: Context, text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty()) return false
        val cur = quotes(c)
        if (cur.contains(t)) return false
        saveQuotes(c, cur + t)
        return true
    }

    fun removeQuote(c: Context, index: Int) {
        val cur = quotes(c).toMutableList()
        if (index in cur.indices) {
            cur.removeAt(index)
            saveQuotes(c, cur)
        }
    }

    /** 경고창에 띄울 명언 하나. 목록이 비어 있으면 기본 명언을 쓴다. */
    fun randomQuote(c: Context): String = quotes(c).ifEmpty { DEFAULT_QUOTES }.random()
}
