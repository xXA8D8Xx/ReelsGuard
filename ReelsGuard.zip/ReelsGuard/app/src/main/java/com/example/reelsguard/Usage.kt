package com.example.reelsguard

import android.content.Context
import kotlin.math.max

/**
 * 오늘 얼마나 썼는지를 눈의 '깃털 접힘 정도'(0~3)로 바꿔 준다.
 * 한도의 40%까지는 활짝 펼쳐져 있고, 그 뒤로 사용량이 늘수록 아래쪽 깃털부터 한 장씩 접힌다.
 * 한도를 다 쓰면 세 장 모두 접힌다.
 */
object Usage {
    private const val START = 0.4f

    /** 사용 비율(0~1) → 접힘 정도(0~3). 정수 하나가 깃털 한 장(양쪽 한 쌍)이다. */
    fun fold(ratio: Float): Float = ((ratio - START) / (1f - START) * 3f).coerceIn(0f, 3f)

    /** 릴스: 야간이거나 한도가 0이면 처음부터 모두 접힌 상태. */
    fun reelsFold(c: Context): Float {
        if (Prefs.isNight(c)) return 3f
        val limit = Prefs.limit(c)
        if (limit <= 0) return 3f
        return fold(Prefs.used(c).toFloat() / limit)
    }

    /** 홈 피드·탐색: 새로 내려가 본 거리(px) 기준. extraPx 는 아직 저장 전인 값. */
    fun feedFold(c: Context, home: Boolean, extraPx: Long = 0L): Float {
        val limit = if (home) Prefs.feedLimit(c) else Prefs.exploreLimit(c)
        if (limit <= 0) return 3f
        val px = Stats.today(c, if (home) Stats.FEED_PX else Stats.EXPLORE_PX) + extraPx
        val h = max(1, c.resources.displayMetrics.heightPixels).toLong()
        return fold(px.toFloat() / (limit.toLong() * h).toFloat())
    }

    /** 오늘 가장 많이 쓴 항목 기준(앱 머리글·종료 인사에 쓴다). */
    fun overallFold(c: Context): Float =
        max(reelsFold(c), max(feedFold(c, true), feedFold(c, false)))
}
