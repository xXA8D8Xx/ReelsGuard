package com.example.reelsguard

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var lockInfo: TextView
    private lateinit var confirm: Button
    private lateinit var soundSwitch: Switch
    private lateinit var noticeSwitch: Switch
    private lateinit var stepReels: Stepper
    private lateinit var stepFeed: Stepper
    private lateinit var stepExplore: Stepper
    private lateinit var statsBox: LinearLayout
    private lateinit var quoteList: LinearLayout
    private lateinit var quoteInput: EditText
    private lateinit var pager: SnapPager
    private val tabLabels = ArrayList<TextView>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#0D1015"))

        // ----- 머리글 -----
        val header = LinearLayout(this)
        header.orientation = LinearLayout.VERTICAL
        header.setPadding(dp(20), dp(24), dp(20), dp(6))
        header.addView(text("ReelsGuard", 26f, bold = true))
        status = text("", 14f, color = "#9AA0A6")
        header.addView(status)
        root.addView(header)

        // ----- 슬라이드 이름표 -----
        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.setPadding(dp(12), 0, dp(12), dp(4))
        val names = listOf("설정", "통계", "명언")
        for (i in names.indices) {
            val t = text(names[i], 16f, bold = true)
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(10), 0, dp(10))
            t.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            t.setOnClickListener { pager.goTo(i) }
            tabLabels.add(t)
            tabs.addView(t)
        }
        root.addView(tabs)

        // ----- 가로로 넘기는 슬라이드 -----
        stepReels = Stepper("릴스 스와이프 (회)", Prefs.MAX_LIMIT)
        stepFeed = Stepper("홈 피드 (페이지)", Prefs.MAX_LIMIT)
        stepExplore = Stepper("탐색 탭 (페이지)", Prefs.MAX_LIMIT)

        pager = SnapPager(this)
        val pages = LinearLayout(this)
        pages.orientation = LinearLayout.HORIZONTAL
        val w = resources.displayMetrics.widthPixels
        for (page in listOf(buildSettingsPage(), buildStatsPage(), buildQuotesPage())) {
            pages.addView(page, LinearLayout.LayoutParams(w, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        pager.addView(pages)
        pager.onPageChanged = { p ->
            highlightTab(p)
            if (p == 1) renderStats()
        }
        root.addView(pager, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
        highlightTab(0)
    }

    override fun onResume() {
        super.onResume()
        loadSettings()
        renderStats()
        renderQuotes()
    }

    // =====================================================================
    // 슬라이드 1: 설정
    // =====================================================================

    private fun buildSettingsPage(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(8), dp(20), dp(28))

        val open = Button(this)
        open.text = "접근성 설정 열기"
        open.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        col.addView(open)
        val hint = text(
            "접근성 → 설치된 앱 → ReelsGuard 를 켜 주세요.\n" +
                "(안드로이드 13+ 는 앱 정보 → ⋮ → '제한된 설정 허용' 을 먼저 눌러야 합니다.)",
            12f, color = "#9AA0A6"
        )
        hint.setPadding(0, dp(6), 0, dp(20))
        col.addView(hint)

        col.addView(section("하루 한도"))
        col.addView(stepReels.view)
        col.addView(stepFeed.view)
        col.addView(stepExplore.view)
        val pageHint = text(
            "1페이지 = 새 게시물을 화면 한 장 분량 내려가 본 것입니다.\n" +
                "홈 피드가 잠겨도 맨 위의 스토리는 볼 수 있어요.\n" +
                "릴스는 한도를 다 쓴 뒤 다음으로 넘기려 하면 릴스 창에서 바로 나갑니다.",
            12f, color = "#9AA0A6"
        )
        pageHint.setPadding(0, dp(4), 0, 0)
        col.addView(pageHint)

        confirm = Button(this)
        confirm.text = "이 한도로 확정"
        confirm.setOnClickListener { askConfirm() }
        val cp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        cp.topMargin = dp(12)
        col.addView(confirm, cp)

        lockInfo = text("", 12f, color = "#9AA0A6")
        lockInfo.setPadding(0, dp(6), 0, dp(20))
        col.addView(lockInfo)

        col.addView(section("소리"))
        soundSwitch = Switch(this)
        soundSwitch.text = "경고·종료 종소리 (알림 볼륨)"
        soundSwitch.setTextColor(Color.WHITE)
        soundSwitch.setOnCheckedChangeListener { _, checked -> Prefs.setSoundOn(this, checked) }
        col.addView(soundSwitch)

        noticeSwitch = Switch(this)
        noticeSwitch.text = "페이지·스와이프 진행 알림"
        noticeSwitch.setTextColor(Color.WHITE)
        noticeSwitch.setPadding(0, dp(10), 0, 0)
        noticeSwitch.setOnCheckedChangeListener { _, checked -> Prefs.setNoticeOn(this, checked) }
        col.addView(noticeSwitch)

        val sv = ScrollView(this)
        sv.addView(col)
        return sv
    }

    private fun loadSettings() {
        stepReels.value = Prefs.limit(this)
        stepFeed.value = Prefs.feedLimit(this)
        stepExplore.value = Prefs.exploreLimit(this)
        renderSettings()
    }

    private fun renderSettings() {
        status.text = if (isServiceEnabled()) "서비스: 켜짐 ✅" else "서비스: 꺼짐 ❌"

        val locked = Prefs.isLockedToday(this)
        for (s in listOf(stepReels, stepFeed, stepExplore)) {
            s.render()
            s.setControlsEnabled(!locked)
        }
        val h = resources.displayMetrics.heightPixels.toFloat()
        stepReels.infoText.text = "오늘 ${Prefs.used(this)} / ${Prefs.limit(this)}회 사용 (DM 릴스 첫 1개는 제외)"
        stepFeed.infoText.text =
            "오늘 ${one(Stats.today(this, Stats.FEED_PX) / h)} / ${Prefs.feedLimit(this)}페이지 내려봄"
        stepExplore.infoText.text =
            "오늘 ${one(Stats.today(this, Stats.EXPLORE_PX) / h)} / ${Prefs.exploreLimit(this)}페이지 내려봄"

        confirm.isEnabled = !locked
        lockInfo.text = if (locked) {
            "🔒 오늘은 한도가 고정되었습니다. 자정이 지나면 수정할 수 있어요."
        } else {
            "확정하면 자정까지 수정할 수 없습니다. 확정 전에는 현재 저장된 값이 적용됩니다."
        }
        soundSwitch.isChecked = Prefs.soundOn(this)
        noticeSwitch.isChecked = Prefs.noticeOn(this)
    }

    private fun askConfirm() {
        if (Prefs.isLockedToday(this)) return
        val r = stepReels.value
        val f = stepFeed.value
        val e = stepExplore.value
        AlertDialog.Builder(this)
            .setTitle("한도 확정")
            .setMessage(
                "릴스 스와이프 ${r}회\n홈 피드 ${f}페이지\n탐색 탭 ${e}페이지\n\n" +
                    "이 값으로 확정할까요? 확정하면 오늘은 변경할 수 없고, 자정이 지나야 다시 바꿀 수 있습니다."
            )
            .setPositiveButton("확정") { _, _ ->
                if (Prefs.confirmLimits(this, r, f, e)) {
                    Toast.makeText(this, "오늘 한도가 확정되었습니다", Toast.LENGTH_SHORT).show()
                }
                renderSettings()
            }
            .setNegativeButton("취소", null)
            .show()
    }

    // =====================================================================
    // 슬라이드 2: 통계
    // =====================================================================

    private fun buildStatsPage(): View {
        statsBox = LinearLayout(this)
        statsBox.orientation = LinearLayout.VERTICAL
        statsBox.setPadding(dp(20), dp(8), dp(20), dp(28))
        val sv = ScrollView(this)
        sv.addView(statsBox)
        return sv
    }

    private fun renderStats() {
        statsBox.removeAllViews()
        val today = LocalDate.now()
        val days = ArrayList<LocalDate>()
        for (i in 6 downTo 0) days.add(today.minusDays(i.toLong()))
        val prevDays = ArrayList<LocalDate>()
        for (i in 13 downTo 7) prevDays.add(today.minusDays(i.toLong()))

        val total = Stats.sum(this, days, Stats.IG_MS)
        val prevTotal = Stats.sum(this, prevDays, Stats.IG_MS)

        statsBox.addView(section("최근 7일 인스타그램 사용"))
        statsBox.addView(text(fmtMs(total), 32f, bold = true))
        var sub = "하루 평균 ${fmtMs(total / 7)}"
        if (prevTotal > 0L) {
            val pct = ((total - prevTotal) * 100.0 / prevTotal).toInt()
            sub += "  ·  지난주보다 " + (if (pct > 0) "+$pct%" else "$pct%")
        }
        val subView = text(sub, 13f, color = "#9AA0A6")
        subView.setPadding(0, dp(2), 0, dp(14))
        statsBox.addView(subView)

        // 막대 그래프(하루별 사용 분)
        val chart = BarChartView(this)
        val values = ArrayList<Float>()
        val labels = ArrayList<String>()
        for (d in days) {
            values.add(Stats.get(this, d, Stats.IG_MS) / 60000f)
            labels.add(if (d == today) "오늘" else d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.KOREAN))
        }
        chart.values = values
        chart.labels = labels
        chart.highlight = days.size - 1
        statsBox.addView(chart, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(190)))

        // 표
        val h = resources.displayMetrics.heightPixels.toFloat()
        val head = row("항목", "오늘", "7일 합계", header = true)
        head.setPadding(0, dp(20), 0, dp(4))
        statsBox.addView(head)
        statsBox.addView(
            row(
                "인스타그램 사용",
                fmtMs(Stats.today(this, Stats.IG_MS)),
                fmtMs(total)
            )
        )
        statsBox.addView(
            row(
                "릴스 시청",
                fmtMs(Stats.today(this, Stats.REELS_MS)),
                fmtMs(Stats.sum(this, days, Stats.REELS_MS))
            )
        )
        statsBox.addView(
            row(
                "릴스 스와이프",
                "${Stats.today(this, Stats.SWIPES)}회",
                "${Stats.sum(this, days, Stats.SWIPES)}회"
            )
        )
        statsBox.addView(
            row(
                "홈 피드",
                "${one(Stats.today(this, Stats.FEED_PX) / h)}페이지",
                "${one(Stats.sum(this, days, Stats.FEED_PX) / h)}페이지"
            )
        )
        statsBox.addView(
            row(
                "탐색 탭",
                "${one(Stats.today(this, Stats.EXPLORE_PX) / h)}페이지",
                "${one(Stats.sum(this, days, Stats.EXPLORE_PX) / h)}페이지"
            )
        )
        statsBox.addView(
            row(
                "차단·경고",
                "${Stats.today(this, Stats.BLOCKS)}회",
                "${Stats.sum(this, days, Stats.BLOCKS)}회"
            )
        )
        val note = text("사용 시간은 화면 반응을 기준으로 한 추정치입니다.", 11f, color = "#6B7075")
        note.setPadding(0, dp(14), 0, 0)
        statsBox.addView(note)
    }

    private fun row(a: String, b: String, c: String, header: Boolean = false): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.setPadding(0, dp(7), 0, dp(7))
        val color = if (header) "#9AA0A6" else "#FFFFFF"
        val size = if (header) 12f else 14f
        val ta = text(a, size, color = color)
        ta.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.6f)
        val tb = text(b, size, color = color)
        tb.gravity = Gravity.END
        tb.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val tc = text(c, size, color = color)
        tc.gravity = Gravity.END
        tc.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.2f)
        r.addView(ta)
        r.addView(tb)
        r.addView(tc)
        return r
    }

    // =====================================================================
    // 슬라이드 3: 명언
    // =====================================================================

    private fun buildQuotesPage(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(8), dp(20), dp(28))

        col.addView(section("경고창 명언"))
        val addRow = LinearLayout(this)
        addRow.orientation = LinearLayout.HORIZONTAL
        addRow.gravity = Gravity.CENTER_VERTICAL
        quoteInput = EditText(this)
        quoteInput.hint = "새 명언 입력"
        quoteInput.setSingleLine(true)
        quoteInput.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(80))
        quoteInput.setTextColor(Color.WHITE)
        quoteInput.setHintTextColor(Color.parseColor("#6B7075"))
        quoteInput.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val addBtn = Button(this)
        addBtn.text = "추가"
        addBtn.setOnClickListener { addQuote() }
        addRow.addView(quoteInput)
        addRow.addView(addBtn)
        col.addView(addRow)

        val hint = text("명언마다 종소리가 조금씩 다르게 울립니다.", 12f, color = "#9AA0A6")
        hint.setPadding(0, dp(6), 0, dp(10))
        col.addView(hint)

        quoteList = LinearLayout(this)
        quoteList.orientation = LinearLayout.VERTICAL
        col.addView(quoteList)

        val sv = ScrollView(this)
        sv.addView(col)
        return sv
    }

    private fun addQuote() {
        if (Prefs.addQuote(this, quoteInput.text.toString())) {
            quoteInput.setText("")
            renderQuotes()
        } else {
            Toast.makeText(this, "비어 있거나 이미 있는 명언입니다", Toast.LENGTH_SHORT).show()
        }
    }

    private fun renderQuotes() {
        quoteList.removeAllViews()
        val list = Prefs.quotes(this)
        if (list.isEmpty()) {
            quoteList.addView(text("명언이 없으면 기본 명언이 표시됩니다.", 13f, color = "#9AA0A6"))
            return
        }
        for (i in list.indices) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(0, dp(4), 0, dp(4))
            val t = text("• ${list[i]}", 15f)
            t.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            r.addView(t)
            val del = Button(this)
            del.text = "삭제"
            val idx = i
            del.setOnClickListener {
                Prefs.removeQuote(this, idx)
                renderQuotes()
            }
            r.addView(del)
            quoteList.addView(r)
        }
    }

    // =====================================================================
    // 도우미
    // =====================================================================

    private fun highlightTab(page: Int) {
        for (i in tabLabels.indices) {
            tabLabels[i].setTextColor(Color.parseColor(if (i == page) "#FF6B8A" else "#6B7075"))
        }
    }

    private fun text(s: String, sizeSp: Float, bold: Boolean = false, color: String = "#FFFFFF"): TextView {
        val t = TextView(this)
        t.text = s
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        t.setTextColor(Color.parseColor(color))
        if (bold) t.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        return t
    }

    private fun section(s: String): View {
        val t = text(s, 18f, bold = true, color = "#FF6B8A")
        t.setPadding(0, dp(4), 0, dp(8))
        return t
    }

    private fun one(v: Float): String = String.format(Locale.US, "%.1f", v)

    private fun fmtMs(ms: Long): String {
        if (ms <= 0L) return "0분"
        val m = ms / 60000L
        if (m <= 0L) return "1분 미만"
        return if (m >= 60L) "${m / 60}시간 ${m % 60}분" else "${m}분"
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains("$packageName/${ReelsBlockerService::class.java.name}")
    }

    /** 값 하나를 −/+ 로 조절하는 줄. */
    private inner class Stepper(label: String, private val maxV: Int) {
        var value = 0
        val infoText: TextView = text("", 12f, color = "#9AA0A6")
        private val valueText: TextView = text("0", 26f, bold = true)
        private val minus = Button(this@MainActivity)
        private val plus = Button(this@MainActivity)
        val view = LinearLayout(this@MainActivity)

        init {
            valueText.gravity = Gravity.CENTER
            valueText.minWidth = dp(64)
            minus.text = "−"
            minus.setOnClickListener { change(-1) }
            plus.text = "+"
            plus.setOnClickListener { change(1) }

            val line = LinearLayout(this@MainActivity)
            line.orientation = LinearLayout.HORIZONTAL
            line.gravity = Gravity.CENTER_VERTICAL
            val name = text(label, 16f, bold = true)
            name.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            line.addView(name)
            line.addView(minus)
            line.addView(valueText)
            line.addView(plus)

            view.orientation = LinearLayout.VERTICAL
            view.setPadding(0, dp(8), 0, dp(8))
            view.addView(line)
            view.addView(infoText)
        }

        private fun change(d: Int) {
            value = (value + d).coerceIn(0, maxV)
            render()
        }

        fun render() {
            valueText.text = value.toString()
        }

        fun setControlsEnabled(e: Boolean) {
            minus.isEnabled = e
            plus.isEnabled = e
        }
    }

    /** 손가락으로 옆으로 넘기면 한 페이지씩 딱 맞춰 멈추는 슬라이드. */
    private class SnapPager(context: Context) : HorizontalScrollView(context) {
        var onPageChanged: ((Int) -> Unit)? = null
        private var flung = false
        private var lastPage = -1

        init {
            isHorizontalScrollBarEnabled = false
            overScrollMode = OVER_SCROLL_NEVER
        }

        fun goTo(page: Int) {
            smoothScrollTo(page * width, 0)
        }

        override fun fling(velocityX: Int) {
            val w = width
            if (w <= 0) {
                super.fling(velocityX)
                return
            }
            flung = true
            val cur = scrollX.toFloat() / w
            val target = if (velocityX > 0) ceil(cur) else floor(cur)
            smoothScrollTo((target * w).toInt(), 0)
        }

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) flung = false
            val handled = super.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                if (!flung && width > 0) {
                    val page = (scrollX + width / 2) / width
                    smoothScrollTo(page * width, 0)
                }
            }
            return handled
        }

        override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
            super.onScrollChanged(l, t, oldl, oldt)
            if (width > 0) {
                val page = (l + width / 2) / width
                if (page != lastPage) {
                    lastPage = page
                    onPageChanged?.invoke(page)
                }
            }
        }
    }

    /** 최근 7일 막대 그래프. */
    private class BarChartView(context: Context) : View(context) {
        var values: List<Float> = emptyList()
        var labels: List<String> = emptyList()
        var highlight = -1

        private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()

        init {
            val d = resources.displayMetrics.density
            valuePaint.color = Color.WHITE
            valuePaint.textSize = 11f * d
            valuePaint.textAlign = Paint.Align.CENTER
            labelPaint.color = Color.parseColor("#9AA0A6")
            labelPaint.textSize = 12f * d
            labelPaint.textAlign = Paint.Align.CENTER
            basePaint.color = Color.parseColor("#2A2F38")
        }

        private fun fmt(min: Float): String {
            val m = min.toInt()
            return if (m >= 60) "${m / 60}h${m % 60}m" else "${m}m"
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (values.isEmpty()) return
            val d = resources.displayMetrics.density
            val w = width.toFloat()
            val h = height.toFloat()
            val top = 22f * d
            val bottom = h - 24f * d
            var maxV = 1f
            for (v in values) maxV = max(maxV, v)
            val slot = w / values.size
            val barW = slot * 0.5f
            val radius = 6f * d

            canvas.drawRect(0f, bottom, w, bottom + 1f * d, basePaint)
            for (i in values.indices) {
                val bh = max(values[i] / maxV * (bottom - top), 2f * d)
                val left = i * slot + (slot - barW) / 2f
                barPaint.color = Color.parseColor(if (i == highlight) "#FF4D6D" else "#6C5CE7")
                rect.set(left, bottom - bh, left + barW, bottom)
                canvas.drawRoundRect(rect, radius, radius, barPaint)
                canvas.drawText(fmt(values[i]), left + barW / 2f, bottom - bh - 5f * d, valuePaint)
                val label = if (i < labels.size) labels[i] else ""
                canvas.drawText(label, i * slot + slot / 2f, h - 6f * d, labelPaint)
            }
        }
    }
}
