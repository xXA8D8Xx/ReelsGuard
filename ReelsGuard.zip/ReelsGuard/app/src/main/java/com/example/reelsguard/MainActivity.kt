package com.example.reelsguard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
        }

        val title = TextView(this).apply {
            text = "ReelsGuard"
            textSize = 28f
            gravity = Gravity.CENTER
        }
        val desc = TextView(this).apply {
            text = "인스타그램 릴스 탭을 막고,\nDM으로 받은 릴스는 1개만 볼 수 있게 합니다.\n\n" +
                "아래 버튼 → 설치된 앱 → ReelsGuard → 사용 으로 켜 주세요."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, pad, 0, pad)
        }
        status = TextView(this).apply {
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, pad)
        }
        val button = Button(this).apply {
            text = "접근성 설정 열기"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        layout.addView(title)
        layout.addView(desc)
        layout.addView(status)
        layout.addView(button)
        setContentView(layout)
    }

    override fun onResume() {
        super.onResume()
        status.text = if (isServiceEnabled()) "상태: 켜짐 ✅" else "상태: 꺼짐 ❌"
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains("$packageName/${ReelsBlockerService::class.java.name}")
    }
}
