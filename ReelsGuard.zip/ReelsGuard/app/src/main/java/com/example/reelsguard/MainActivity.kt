package com.example.reelsguard

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var lockInfo: TextView
    private lateinit var confirm: Button
    private lateinit var soundSwitch: Switch
    private lateinit var noticeSwitch: Switch
    private lateinit var eyeSwitch: Switch
    private lateinit var nightSwitch: Switch
    private var suppressNight = false
    private lateinit var stepNightStart: Stepper
    private lateinit var stepNightEnd: Stepper
    private lateinit var headerEye: AngelEyeView
    private lateinit var stepReels: Stepper
    private lateinit var stepFeed: Stepper
    private lateinit var stepExplore: Stepper
    private lateinit var statsBox: LinearLayout
    private lateinit var quoteList: LinearLayout
    private lateinit var quoteInput: EditText
    private lateinit var pager: SnapPager
    private val tabLabels = ArrayList<TextView>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor(Palette.BG))

        // ----- 머리글 -----
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(14), dp(20), dp(20), dp(4))
        headerEye = AngelEyeView(this)
        headerEye.layoutParams = LinearLayout.LayoutParams(dp(92), dp(54))
        header.addView(headerEye)
        val titleCol = LinearLayout(this)
        titleCol.orientation = LinearLayout.VERTICAL
        val title = text("ReelsGuard", 24f, bold = true)
        title.letterSpacing = 0.04f
        titleCol.addView(title)
        status = text("", 13f, color = Palette.MUTED)
        titleCol.addView(status)
        header.addView(titleCol)
        root.addView(header)

        // ----- 슬라이드 이름표 -----
        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.setPadding(dp(12), 0, dp(12), dp(4))
        val names = listOf("설정", "통계", "명언")
        for (i in names.indices) {
            val t = text(names[i], 16f, bold = true)
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(10), 0, dp(10))
            t.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            t.setOnClickListener { pager.goTo(i) }
            tabLabels.add(t)
            tabs.addView(t)
        }
        root.addView(tabs)

        // ----- 가로로 넘기는 슬라이드 -----
        stepReels = Stepper("릴스 스와이프 (회)", Prefs.MAX_LIMIT)
        stepFeed = Stepper("홈 피드 (페이지)", Prefs.MAX_LIMIT)
        stepExplore = Stepper("탐색 탭 (페이지)", Prefs.MAX_LIMIT)
        stepNightStart = Stepper("시작 시각", 23, wrap = true, suffix = "시", showInfo = false)
        stepNightEnd = Stepper("종료 시각", 23, wrap = true, suffix = "시", showInfo = false)

        pager = SnapPager(this)
        val pages = LinearLayout(this)
        pages.orientation = LinearLayout.HORIZONTAL
        val w = resources.displayMetrics.widthPixels
        for (page in listOf(buildSettingsPage(), buildStatsPage(), buildQuotesPage())) {
            pages.addView(page, LinearLayout.LayoutParams(w, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        pager.addView(pages)
        pager.onPageChanged = { p ->
            highlightTab(p)
            if (p == 1) renderStats()
        }
        root.addView(pager, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
        highlightTab(0)
    }

    override fun onResume() {
        super.onResume()
        loadSettings()
        renderStats()
        renderQuotes()
    }

    // =====================================================================
    // 슬라이드 1: 설정
    // =====================================================================

    private fun buildSettingsPage(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(8), dp(20), dp(28))

        val open = Button(this)
        styleButton(open)
        open.text = "접근성 설정 열기"
        open.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        col.addView(open)
        val hint = text(
            "접근성 → 설치된 앱 → ReelsGuard 를 켜 주세요.\n" +
                "(안드로이드 13+ 는 앱 정보 → ⋮ → '제한된 설정 허용' 을 먼저 눌러야 합니다.)",
            12f, color = Palette.MUTED
        )
        hint.setPadding(0, dp(6), 0, dp(20))
        col.addView(hint)

        col.addView(section("하루 한도"))
        col.addView(stepReels.view)
        col.addView(stepFeed.view)
        col.addView(stepExplore.view)
        val pageHint = text(
            "1페이지 = 새 게시물을 화면 한 장 분량 내려가 본 것입니다.\n" +
                "홈 피드가 잠겨도 맨 위의 스토리는 볼 수 있어요.\n" +
                "릴스는 한도를 다 쓴 뒤 다음으로 넘기려 하면 릴스 창에서 바로 나갑니다.",
            12f, color = Palette.MUTED
        )
        pageHint.setPadding(0, dp(4), 0, dp(20))
        col.addView(pageHint)

        col.addView(section("야간 차단"))
        nightSwitch = Switch(this)
        nightSwitch.text = "밤에는 릴스 완전 차단"
        nightSwitch.setTextColor(Color.parseColor(Palette.TEXT))
        tintSwitch(nightSwitch)
        nightSwitch.setOnCheckedChangeListener { _, checked ->
            if (!suppressNight) {
                if (checked) {
                    Prefs.setNightOn(this, true)
                    renderSettings()
                } else {
                    confirmNightOff()
                }
            }
        }
        col.addView(nightSwitch)
        col.addView(stepNightStart.view)
        col.addView(stepNightEnd.view)
        val nightHint = text(
            "이 시간에는 한도와 상관없이 릴스가 열리자마자 닫힙니다.\n" +
                "스위치로 언제든 바로 끌 수 있어요. 시각은 야간이 아닐 때 바꾸고 '확정'을 눌러 주세요.",
            12f, color = Palette.MUTED
        )
        nightHint.setPadding(0, dp(4), 0, 0)
        col.addView(nightHint)

        confirm = Button(this)
        styleButton(confirm, primary = true)
        confirm.text = "이 한도로 확정"
        confirm.setOnClickListener { askConfirm() }
        val cp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        cp.topMargin = dp(12)
        col.addView(confirm, cp)

        lockInfo = text("", 12f, color = Palette.MUTED)
        lockInfo.setPadding(0, dp(6), 0, dp(20))
        col.addView(lockInfo)

        col.addView(section("소리"))
        soundSwitch = Switch(this)
        soundSwitch.text = "경고·종료 종소리 (알림 볼륨)"
        soundSwitch.setTextColor(Color.parseColor(Palette.TEXT))
        tintSwitch(soundSwitch)
        soundSwitch.setOnCheckedChangeListener { _, checked -> Prefs.setSoundOn(this, checked) }
        col.addView(soundSwitch)

        noticeSwitch = Switch(this)
        noticeSwitch.text = "페이지·스와이프 진행 알림"
        noticeSwitch.setTextColor(Color.parseColor(Palette.TEXT))
        noticeSwitch.setPadding(0, dp(10), 0, 0)
        tintSwitch(noticeSwitch)
        noticeSwitch.setOnCheckedChangeListener { _, checked -> Prefs.setNoticeOn(this, checked) }
        col.addView(noticeSwitch)

        eyeSwitch = Switch(this)
        eyeSwitch.text = "눈 움직임 (끄면 멈춰요)"
        eyeSwitch.setTextColor(Color.parseColor(Palette.TEXT))
        eyeSwitch.setPadding(0, dp(10), 0, 0)
        tintSwitch(eyeSwitch)
        eyeSwitch.setOnCheckedChangeListener { _, checked -> Prefs.setEyeMotionOn(this, checked) }
        col.addView(eyeSwitch)

        val sv = ScrollView(this)
        sv.addView(col)
        return sv
    }

    private fun loadSettings() {
        stepReels.value = Prefs.limit(this)
        stepFeed.value = Prefs.feedLimit(this)
        stepExplore.value = Prefs.exploreLimit(this)
        setNightSwitch(Prefs.nightOn(this))
        stepNightStart.value = Prefs.nightStart(this)
        stepNightEnd.value = Prefs.nightEnd(this)
        renderSettings()
    }

    private fun renderSettings() {
        status.text = if (isServiceEnabled()) "서비스: 켜짐 ✅" else "서비스: 꺼짐 ❌"

        val locked = Prefs.isLockedToday(this)
        val night = Prefs.isNight(this)
        val editable = !locked && !night
        for (s in listOf(stepReels, stepFeed, stepExplore, stepNightStart, stepNightEnd)) {
            s.render()
            s.setControlsEnabled(editable)
        }
        nightSwitch.isEnabled = true
        headerEye.setFold(Usage.overallFold(this))
        val h = resources.displayMetrics.heightPixels.toFloat()
        stepReels.infoText.text = "오늘 ${Prefs.used(this)} / ${Prefs.limit(this)}회 사용 (DM 릴스 첫 1개는 제외)"
        stepFeed.infoText.text =
            "오늘 ${one(Stats.today(this, Stats.FEED_PX) / h)} / ${Prefs.feedLimit(this)}페이지 내려봄"
        stepExplore.infoText.text =
            "오늘 ${one(Stats.today(this, Stats.EXPLORE_PX) / h)} / ${Prefs.exploreLimit(this)}페이지 내려봄"

        setBtn(confirm, editable)
        lockInfo.text = if (night) {
            "🌙 지금은 야간 차단 시간이라 한도와 시각을 바꿀 수 없어요. ${Prefs.nightEnd(this)}시 이후에 수정하거나, 야간 차단을 끄면 바로 수정할 수 있어요."
        } else if (locked) {
            "🔒 오늘은 한도가 고정되었습니다. 새벽 4시가 지나면 수정할 수 있어요."
        } else {
            "확정하면 새벽 4시까지 수정할 수 없습니다. 확정 전에는 현재 저장된 값이 적용됩니다."
        }
        soundSwitch.isChecked = Prefs.soundOn(this)
        noticeSwitch.isChecked = Prefs.noticeOn(this)
        eyeSwitch.isChecked = Prefs.eyeMotionOn(this)
    }

    private fun askConfirm() {
        if (Prefs.isLockedToday(this) || Prefs.isNight(this)) return
        val r = stepReels.value
        val f = stepFeed.value
        val e = stepExplore.value
        val nOn = Prefs.nightOn(this)
        val nS = stepNightStart.value
        val nE = stepNightEnd.value
        val nightLine = if (nOn) "야간 차단 ${nS}시 ~ ${nE}시" else "야간 차단 꺼짐"
        AlertDialog.Builder(this, R.style.Theme_ReelsGuard_Dialog)
            .setTitle("한도 확정")
            .setMessage(
                "릴스 스와이프 ${r}회\n홈 피드 ${f}페이지\n탐색 탭 ${e}페이지\n${nightLine}\n\n" +
                    "이 값으로 확정할까요? 확정하면 오늘은 변경할 수 없고, 새벽 4시가 지나야 다시 바꿀 수 있습니다."
            )
            .setPositiveButton("확정") { _, _ ->
                if (Prefs.confirmLimits(this, r, f, e, nS, nE)) {
                    Toast.makeText(this, "오늘 한도가 확정되었습니다", Toast.LENGTH_SHORT).show()
                }
                renderSettings()
            }
            .setNegativeButton("취소", null)
            .show()
    }

    // =====================================================================
    // 슬라이드 2: 통계
    // =====================================================================

    private fun buildStatsPage(): View {
        statsBox = LinearLayout(this)
        statsBox.orientation = LinearLayout.VERTICAL
        statsBox.setPadding(dp(20), dp(8), dp(20), dp(28))
        val sv = ScrollView(this)
        sv.addView(statsBox)
        return sv
    }

    private fun renderStats() {
        statsBox.removeAllViews()
        val today = Day.today()
        val days = ArrayList<LocalDate>()
        for (i in 6 downTo 0) days.add(today.minusDays(i.toLong()))
        val prevDays = ArrayList<LocalDate>()
        for (i in 13 downTo 7) prevDays.add(today.minusDays(i.toLong()))

        val total = Stats.sum(this, days, Stats.IG_MS)
        val prevTotal = Stats.sum(this, prevDays, Stats.IG_MS)

        statsBox.addView(section("최근 7일 인스타그램 사용"))
        statsBox.addView(text(fmtMs(total), 32f, bold = true))
        var sub = "하루 평균 ${fmtMs(total / 7)}"
        if (prevTotal > 0L) {
            val pct = ((total - prevTotal) * 100.0 / prevTotal).toInt()
            sub += "  ·  지난주보다 " + (if (pct > 0) "+$pct%" else "$pct%")
        }
        val subView = text(sub, 13f, color = Palette.MUTED)
        subView.setPadding(0, dp(2), 0, dp(14))
        statsBox.addView(subView)

        // 막대 그래프(하루별 사용 분)
        val chart = BarChartView(this)
        val values = ArrayList<Float>()
        val labels = ArrayList<String>()
        for (d in days) {
            values.add(Stats.get(this, d, Stats.IG_MS) / 60000f)
            labels.add(if (d == today) "오늘" else d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.KOREAN))
        }
        chart.values = values
        chart.labels = labels
        chart.highlight = days.size - 1
        statsBox.addView(chart, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(190)))

        // 표
        val h = resources.displayMetrics.heightPixels.toFloat()
        val head = row("항목", "오늘", "7일 합계", header = true)
        head.setPadding(0, dp(20), 0, dp(4))
        statsBox.addView(head)
        statsBox.addView(
            row(
                "인스타그램 사용",
                fmtMs(Stats.today(this, Stats.IG_MS)),
                fmtMs(total)
            )
        )
        statsBox.addView(
            row(
                "릴스 시청",
                fmtMs(Stats.today(this, Stats.REELS_MS)),
                fmtMs(Stats.sum(this, days, Stats.REELS_MS))
            )
        )
        statsBox.addView(
            row(
                "릴스 스와이프",
                "${Stats.today(this, Stats.SWIPES)}회",
                "${Stats.sum(this, days, Stats.SWIPES)}회"
            )
        )
        statsBox.addView(
            row(
                "홈 피드",
                "${one(Stats.today(this, Stats.FEED_PX) / h)}페이지",
                "${one(Stats.sum(this, days, Stats.FEED_PX) / h)}페이지"
            )
        )
        statsBox.addView(
            row(
                "탐색 탭",
                "${one(Stats.today(this, Stats.EXPLORE_PX) / h)}페이지",
                "${one(Stats.sum(this, days, Stats.EXPLORE_PX) / h)}페이지"
            )
        )
        statsBox.addView(
            row(
                "차단·경고",
                "${Stats.today(this, Stats.BLOCKS)}회",
                "${Stats.sum(this, days, Stats.BLOCKS)}회"
            )
        )
        val note = text("사용 시간은 화면 반응을 기준으로 한 추정치입니다.", 11f, color = Palette.DIM)
        note.setPadding(0, dp(14), 0, 0)
        statsBox.addView(note)
    }

    private fun row(a: String, b: String, c: String, header: Boolean = false): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.setPadding(0, dp(7), 0, dp(7))
        val color = if (header) Palette.MUTED else Palette.TEXT
        val size = if (header) 12f else 14f
        val ta = text(a, size, color = color)
        ta.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.6f)
        val tb = text(b, size, color = color)
        tb.gravity = Gravity.END
        tb.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val tc = text(c, size, color = color)
        tc.gravity = Gravity.END
        tc.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.2f)
        r.addView(ta)
        r.addView(tb)
        r.addView(tc)
        return r
    }

    // =====================================================================
    // 슬라이드 3: 명언
    // =====================================================================

    private fun buildQuotesPage(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(8), dp(20), dp(28))

        col.addView(section("경고창 명언"))
        val addRow = LinearLayout(this)
        addRow.orientation = LinearLayout.HORIZONTAL
        addRow.gravity = Gravity.CENTER_VERTICAL
        quoteInput = EditText(this)
        quoteInput.hint = "새 명언 입력"
        quoteInput.setSingleLine(true)
        quoteInput.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(80))
        quoteInput.setTextColor(Color.parseColor(Palette.TEXT))
        quoteInput.setHintTextColor(Color.parseColor(Palette.DIM))
        quoteInput.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val addBtn = Button(this)
        styleButton(addBtn)
        addBtn.text = "추가"
        addBtn.setOnClickListener { addQuote() }
        addRow.addView(quoteInput)
        addRow.addView(addBtn)
        col.addView(addRow)

        val hint = text("명언마다 종소리가 조금씩 다르게 울립니다.", 12f, color = Palette.MUTED)
        hint.setPadding(0, dp(6), 0, dp(10))
        col.addView(hint)

        quoteList = LinearLayout(this)
        quoteList.orientation = LinearLayout.VERTICAL
        col.addView(quoteList)

        val sv = ScrollView(this)
        sv.addView(col)
        return sv
    }

    private fun addQuote() {
        if (Prefs.addQuote(this, quoteInput.text.toString())) {
            quoteInput.setText("")
            renderQuotes()
        } else {
            Toast.makeText(this, "비어 있거나 이미 있는 명언입니다", Toast.LENGTH_SHORT).show()
        }
    }

    private fun renderQuotes() {
        quoteList.removeAllViews()
        val list = Prefs.quotes(this)
        if (list.isEmpty()) {
            quoteList.addView(text("명언이 없으면 기본 명언이 표시됩니다.", 13f, color = Palette.MUTED))
            return
        }
        for (i in list.indices) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(0, dp(4), 0, dp(4))
            val t = text("• ${list[i]}", 15f)
            t.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            r.addView(t)
            val del = Button(this)
            styleButton(del)
            del.text = "삭제"
            val idx = i
            del.setOnClickListener {
                Prefs.removeQuote(this, idx)
                renderQuotes()
            }
            r.addView(del)
            quoteList.addView(r)
        }
    }

    // =====================================================================
    // 도우미
    // =====================================================================

    private fun setNightSwitch(on: Boolean) {
        suppressNight = true
        nightSwitch.isChecked = on
        suppressNight = false
    }

    /** 야간 차단을 끌 때는 한 번만 확인한다. 취소하면 스위치를 되돌린다. */
    private fun confirmNightOff() {
        AlertDialog.Builder(this, R.style.Theme_ReelsGuard_Dialog)
            .setTitle("야간 차단 끄기")
            .setMessage("밤에도 릴스를 열 수 있게 됩니다. 정말 끌까요?")
            .setPositiveButton("끄기") { _, _ ->
                Prefs.setNightOn(this, false)
                renderSettings()
            }
            .setNegativeButton("취소") { _, _ -> setNightSwitch(true) }
            .setOnCancelListener { setNightSwitch(true) }
            .show()
    }

    /** 금빛 테두리의 깔끔한 버튼. primary 는 금색으로 채운다. */
    private fun styleButton(b: Button, primary: Boolean = false) {
        val bg = GradientDrawable()
        bg.cornerRadius = dp(12).toFloat()
        if (primary) {
            bg.setColor(Color.parseColor(Palette.GOLD))
        } else {
            bg.setColor(Color.TRANSPARENT)
            bg.setStroke(dp(1), Color.parseColor(Palette.GOLD))
        }
        b.background = bg
        b.setTextColor(Color.parseColor(if (primary) Palette.BG else Palette.GOLD))
        b.isAllCaps = false
        b.stateListAnimator = null
        b.minHeight = dp(44)
        b.setPadding(dp(16), 0, dp(16), 0)
    }

    private fun setBtn(b: Button, enabled: Boolean) {
        b.isEnabled = enabled
        b.alpha = if (enabled) 1f else 0.35f
    }

    private fun tintSwitch(s: Switch) {
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        s.thumbTintList = ColorStateList(
            states,
            intArrayOf(Color.parseColor(Palette.GOLD), Color.parseColor(Palette.MUTED))
        )
        s.trackTintList = ColorStateList(
            states,
            intArrayOf(Color.parseColor("#66E6C98A"), Color.parseColor(Palette.LINE))
        )
    }

    private fun highlightTab(page: Int) {
        for (i in tabLabels.indices) {
            tabLabels[i].setTextColor(Color.parseColor(if (i == page) Palette.GOLD else Palette.DIM))
        }
    }

    private fun text(s: String, sizeSp: Float, bold: Boolean = false, color: String = Palette.TEXT): TextView {
        val t = TextView(this)
        t.text = s
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        t.setTextColor(Color.parseColor(color))
        if (bold) t.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        return t
    }

    private fun section(s: String): View {
        val t = text(s, 16f, bold = true, color = Palette.GOLD)
        t.letterSpacing = 0.06f
        t.setPadding(0, dp(4), 0, dp(8))
        return t
    }

    private fun one(v: Float): String = String.format(Locale.US, "%.1f", v)

    private fun fmtMs(ms: Long): String {
        if (ms <= 0L) return "0분"
        val m = ms / 60000L
        if (m <= 0L) return "1분 미만"
        return if (m >= 60L) "${m / 60}시간 ${m % 60}분" else "${m}분"
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains("$packageName/${ReelsBlockerService::class.java.name}")
    }

    /** 값 하나를 −/+ 로 조절하는 줄. */
    private inner class Stepper(
        label: String,
        private val maxV: Int,
        private val wrap: Boolean = false,
        private val suffix: String = "",
        showInfo: Boolean = true
    ) {
        var value = 0
        val infoText: TextView = text("", 12f, color = Palette.MUTED)
        private val valueText: TextView = text("0", 26f, bold = true)
        private val minus = Button(this@MainActivity)
        private val plus = Button(this@MainActivity)
        val view = LinearLayout(this@MainActivity)

        init {
            valueText.gravity = Gravity.CENTER
            valueText.minWidth = dp(64)
            styleButton(minus)
            styleButton(plus)
            minus.minWidth = dp(46)
            plus.minWidth = dp(46)
            minus.text = "−"
            minus.setOnClickListener { change(-1) }
            plus.text = "+"
            plus.setOnClickListener { change(1) }

            val line = LinearLayout(this@MainActivity)
            line.orientation = LinearLayout.HORIZONTAL
            line.gravity = Gravity.CENTER_VERTICAL
            val name = text(label, 16f, bold = true)
            name.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            line.addView(name)
            line.addView(minus)
            line.addView(valueText)
            line.addView(plus)

            view.orientation = LinearLayout.VERTICAL
            view.setPadding(0, dp(8), 0, dp(8))
            view.addView(line)
            if (showInfo) view.addView(infoText)
        }

        private fun change(d: Int) {
            val n = maxV + 1
            value = if (wrap) ((value + d) % n + n) % n else (value + d).coerceIn(0, maxV)
            render()
        }

        fun render() {
            valueText.text = value.toString() + suffix
        }

        fun setControlsEnabled(e: Boolean) {
            setBtn(minus, e)
            setBtn(plus, e)
        }
    }

    /** 손가락으로 옆으로 넘기면 한 페이지씩 딱 맞춰 멈추는 슬라이드. */
    private class SnapPager(context: Context) : HorizontalScrollView(context) {
        var onPageChanged: ((Int) -> Unit)? = null
        private var flung = false
        private var lastPage = -1

        init {
            isHorizontalScrollBarEnabled = false
            overScrollMode = OVER_SCROLL_NEVER
        }

        fun goTo(page: Int) {
            smoothScrollTo(page * width, 0)
        }

        override fun fling(velocityX: Int) {
            val w = width
            if (w <= 0) {
                super.fling(velocityX)
                return
            }
            flung = true
            val cur = scrollX.toFloat() / w
            val target = if (velocityX > 0) ceil(cur) else floor(cur)
            smoothScrollTo((target * w).toInt(), 0)
        }

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) flung = false
            val handled = super.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                if (!flung && width > 0) {
                    val page = (scrollX + width / 2) / width
                    smoothScrollTo(page * width, 0)
                }
            }
            return handled
        }

        override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
            super.onScrollChanged(l, t, oldl, oldt)
            if (width > 0) {
                val page = (l + width / 2) / width
                if (page != lastPage) {
                    lastPage = page
                    onPageChanged?.invoke(page)
                }
            }
        }
    }

    /** 최근 7일 막대 그래프. */
    private class BarChartView(context: Context) : View(context) {
        var values: List<Float> = emptyList()
        var labels: List<String> = emptyList()
        var highlight = -1

        private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()

        init {
            val d = resources.displayMetrics.density
            valuePaint.color = Color.parseColor(Palette.TEXT)
            valuePaint.textSize = 11f * d
            valuePaint.textAlign = Paint.Align.CENTER
            labelPaint.color = Color.parseColor(Palette.MUTED)
            labelPaint.textSize = 12f * d
            labelPaint.textAlign = Paint.Align.CENTER
            basePaint.color = Color.parseColor(Palette.LINE)
        }

        private fun fmt(min: Float): String {
            val m = min.toInt()
            return if (m >= 60) "${m / 60}h${m % 60}m" else "${m}m"
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (values.isEmpty()) return
            val d = resources.displayMetrics.density
            val w = width.toFloat()
            val h = height.toFloat()
            val top = 22f * d
            val bottom = h - 24f * d
            var maxV = 1f
            for (v in values) maxV = max(maxV, v)
            val slot = w / values.size
            val barW = slot * 0.5f
            val radius = 6f * d

            canvas.drawRect(0f, bottom, w, bottom + 1f * d, basePaint)
            for (i in values.indices) {
                val bh = max(values[i] / maxV * (bottom - top), 2f * d)
                val left = i * slot + (slot - barW) / 2f
                barPaint.color = Color.parseColor(if (i == highlight) Palette.GOLD else Palette.BAR)
                rect.set(left, bottom - bh, left + barW, bottom)
                canvas.drawRoundRect(rect, radius, radius, barPaint)
                canvas.drawText(fmt(values[i]), left + barW / 2f, bottom - bh - 5f * d, valuePaint)
                val label = if (i < labels.size) labels[i] else ""
                canvas.drawText(label, i * slot + slot / 2f, h - 6f * d, labelPaint)
            }
        }
    }
}
