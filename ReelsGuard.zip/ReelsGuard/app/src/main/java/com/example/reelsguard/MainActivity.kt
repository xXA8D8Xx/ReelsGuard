package com.example.reelsguard

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.ColorStateList
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var lockInfo: TextView
    private lateinit var confirm: Button
    private lateinit var emergencyInfo: TextView
    private lateinit var emergencyBtn: Button
    private val ticker = android.os.Handler(android.os.Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            renderEmergency()
            if (Prefs.emergencyActive(this@MainActivity)) ticker.postDelayed(this, 1000L)
        }
    }
    private lateinit var soundSwitch: Switch
    private lateinit var noticeSwitch: Switch
    private lateinit var eyeSwitch: Switch
    private lateinit var nightSwitch: Switch
    private lateinit var tabLockSwitch: Switch
    private lateinit var pauseSwitch: Switch
    private var suppressNight = false
    private lateinit var stepNightStart: Stepper
    private lateinit var stepNightEnd: Stepper
    private lateinit var headerEye: AngelEyeView
    private lateinit var stepReels: Stepper
    private lateinit var stepFeed: Stepper
    private lateinit var stepExplore: Stepper
    private lateinit var statsBox: LinearLayout
    private lateinit var quoteList: LinearLayout
    private lateinit var quoteInput: EditText
    private lateinit var phraseList: LinearLayout
    private lateinit var healthText: TextView
    private lateinit var logText: TextView
    private lateinit var backupInfo: TextView
    private lateinit var phraseInput: EditText
    private lateinit var pager: SnapPager
    private val tabLabels = ArrayList<TextView>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor(Palette.BG))

        // ----- 머리글 -----
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(14), dp(20), dp(20), dp(4))
        headerEye = AngelEyeView(this)
        headerEye.layoutParams = LinearLayout.LayoutParams(dp(92), dp(54))
        header.addView(headerEye)
        val titleCol = LinearLayout(this)
        titleCol.orientation = LinearLayout.VERTICAL
        val title = text("ReelsGuard", 24f, bold = true)
        title.letterSpacing = 0.04f
        titleCol.addView(title)
        status = text("", 13f, color = Palette.MUTED)
        titleCol.addView(status)
        header.addView(titleCol)
        root.addView(header)

        // ----- 슬라이드 이름표 -----
        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.setPadding(dp(12), 0, dp(12), dp(4))
        val names = listOf("설정", "통계", "명언", "관리")
        for (i in names.indices) {
            val t = text(names[i], 16f, bold = true)
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(10), 0, dp(10))
            t.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            t.setOnClickListener { pager.goTo(i) }
            tabLabels.add(t)
            tabs.addView(t)
        }
        root.addView(tabs)

        // ----- 가로로 넘기는 슬라이드 -----
        stepReels = Stepper("릴스 스와이프 (회)", Prefs.MAX_LIMIT)
        stepFeed = Stepper("홈 피드 (페이지)", Prefs.MAX_LIMIT)
        stepExplore = Stepper("탐색 탭 (페이지)", Prefs.MAX_LIMIT)
        stepNightStart = Stepper("시작 시각", 23, wrap = true, suffix = "시", showInfo = false)
        stepNightEnd = Stepper("종료 시각", 23, wrap = true, suffix = "시", showInfo = false)

        pager = SnapPager(this)
        val pages = LinearLayout(this)
        pages.orientation = LinearLayout.HORIZONTAL
        val w = resources.displayMetrics.widthPixels
        for (page in listOf(buildSettingsPage(), buildStatsPage(), buildQuotesPage(), buildManagePage())) {
            pages.addView(page, LinearLayout.LayoutParams(w, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        pager.addView(pages)
        pager.onPageChanged = { p ->
            highlightTab(p)
            if (p == 1) renderStats()
            if (p == 3) renderManage()
        }
        root.addView(pager, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
        highlightTab(0)
    }

    override fun onResume() {
        super.onResume()
        loadSettings()
        renderStats()
        renderQuotes()
        renderManage()
        ticker.removeCallbacks(tick)
        ticker.post(tick)
    }

    override fun onPause() {
        ticker.removeCallbacks(tick)
        super.onPause()
    }

    // =====================================================================
    // 슬라이드 1: 설정
    // =====================================================================

    private fun buildSettingsPage(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(8), dp(20), dp(28))

        val open = Button(this)
        styleButton(open)
        open.text = "접근성 설정 열기"
        open.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        col.addView(open)
        val hint = text(
            "접근성 → 설치된 앱 → ReelsGuard 를 켜 주세요.\n" +
                "(안드로이드 13+ 는 앱 정보 → ⋮ → '제한된 설정 허용' 을 먼저 눌러야 합니다.)",
            12f, color = Palette.MUTED
        )
        hint.setPadding(0, dp(6), 0, dp(20))
        col.addView(hint)

        col.addView(section("하루 한도"))
        col.addView(stepReels.view)
        col.addView(stepFeed.view)
        col.addView(stepExplore.view)
        tabLockSwitch = Switch(this)
        tabLockSwitch.text = "릴스 탭 완전 잠금"
        tabLockSwitch.setTextColor(Color.parseColor(Palette.TEXT))
        tabLockSwitch.setPadding(0, dp(14), 0, 0)
        tintSwitch(tabLockSwitch)
        col.addView(tabLockSwitch)
        val tabLockHint = text(
            "켜 두면 릴스 탭은 늘 잠겨 있고, DM 등 다른 곳에서만 볼 수 있어요.\n" +
                "끄면 릴스 스와이프 한도까지는 릴스 탭도 볼 수 있고, 한도를 다 쓰면 탐색 탭처럼 잠겨요. (확정 시 적용)",
            12f, color = Palette.MUTED
        )
        tabLockHint.setPadding(0, dp(4), 0, dp(10))
        col.addView(tabLockHint)
        val pageHint = text(
            "1페이지 = 새 게시물을 화면 한 장 분량 내려가 본 것입니다.\n" +
                "홈 피드가 잠겨도 맨 위의 스토리는 볼 수 있어요.\n" +
                "릴스는 한도를 다 쓴 뒤 다음으로 넘기려 하면 릴스 창에서 바로 나갑니다.",
            12f, color = Palette.MUTED
        )
        pageHint.setPadding(0, dp(4), 0, dp(20))
        col.addView(pageHint)

        col.addView(section("야간 차단"))
        nightSwitch = Switch(this)
        nightSwitch.text = "밤에는 릴스 완전 차단"
        nightSwitch.setTextColor(Color.parseColor(Palette.TEXT))
        tintSwitch(nightSwitch)
        nightSwitch.setOnCheckedChangeListener { _, checked ->
            if (!suppressNight) {
                if (checked) {
                    Prefs.setNightOn(this, true)
                    renderSettings()
                } else {
                    confirmNightOff()
                }
            }
        }
        col.addView(nightSwitch)
        col.addView(stepNightStart.view)
        col.addView(stepNightEnd.view)
        val nightHint = text(
            "이 시간에는 한도와 상관없이 릴스가 열리자마자 닫힙니다.\n" +
                "스위치로 언제든 바로 끌 수 있어요. 시각은 야간이 아닐 때 바꾸고 '확정'을 눌러 주세요.",
            12f, color = Palette.MUTED
        )
        nightHint.setPadding(0, dp(4), 0, 0)
        col.addView(nightHint)

        confirm = Button(this)
        styleButton(confirm, primary = true)
        confirm.text = "이 한도로 확정"
        confirm.setOnClickListener { askConfirm() }
        val cp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        cp.topMargin = dp(12)
        col.addView(confirm, cp)

        lockInfo = text("", 12f, color = Palette.MUTED)
        lockInfo.setPadding(0, dp(6), 0, dp(20))
        col.addView(lockInfo)

        col.addView(section("긴급 해제"))
        emergencyInfo = text("", 12f, color = Palette.MUTED)
        col.addView(emergencyInfo)
        emergencyBtn = Button(this)
        styleButton(emergencyBtn)
        emergencyBtn.setOnClickListener { askEmergency() }
        val ep = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        ep.topMargin = dp(8)
        ep.bottomMargin = dp(20)
        col.addView(emergencyBtn, ep)

        col.addView(section("소리"))
        soundSwitch = Switch(this)
        soundSwitch.text = "경고·종료 종소리 (알림 볼륨)"
        soundSwitch.setTextColor(Color.parseColor(Palette.TEXT))
        tintSwitch(soundSwitch)
        soundSwitch.setOnCheckedChangeListener { _, checked -> Prefs.setSoundOn(this, checked) }
        col.addView(soundSwitch)

        noticeSwitch = Switch(this)
        noticeSwitch.text = "페이지·스와이프 진행 알림"
        noticeSwitch.setTextColor(Color.parseColor(Palette.TEXT))
        noticeSwitch.setPadding(0, dp(10), 0, 0)
        tintSwitch(noticeSwitch)
        noticeSwitch.setOnCheckedChangeListener { _, checked -> Prefs.setNoticeOn(this, checked) }
        col.addView(noticeSwitch)

        eyeSwitch = Switch(this)
        eyeSwitch.text = "눈 움직임 (끄면 멈춰요)"
        eyeSwitch.setTextColor(Color.parseColor(Palette.TEXT))
        eyeSwitch.setPadding(0, dp(10), 0, 0)
        tintSwitch(eyeSwitch)
        eyeSwitch.setOnCheckedChangeListener { _, checked -> Prefs.setEyeMotionOn(this, checked) }
        col.addView(eyeSwitch)

        col.addView(section("열기 전 숨 고르기"))
        pauseSwitch = Switch(this)
        pauseSwitch.text = "자주 열면 숨 고르기 화면"
        pauseSwitch.setTextColor(Color.parseColor(Palette.TEXT))
        tintSwitch(pauseSwitch)
        pauseSwitch.setOnCheckedChangeListener { _, checked -> Prefs.setPauseOn(this, checked) }
        col.addView(pauseSwitch)
        val pauseHint = text(
            "한 시간에 처음 ${Prefs.FREE_OPENS_PER_HOUR}번은 그냥 열리고, ${Prefs.FREE_OPENS_PER_HOUR + 1}번째부터 " +
                "잠깐 멈춰 서서 숨을 고른 뒤에 열려요.",
            12f, color = Palette.MUTED
        )
        pauseHint.setPadding(0, dp(4), 0, 0)
        col.addView(pauseHint)

        val sv = ScrollView(this)
        sv.addView(col)
        return sv
    }

    private fun loadSettings() {
        stepReels.value = Prefs.limit(this)
        stepFeed.value = Prefs.feedLimit(this)
        stepExplore.value = Prefs.exploreLimit(this)
        setNightSwitch(Prefs.nightOn(this))
        tabLockSwitch.isChecked = Prefs.reelsTabLock(this)
        stepNightStart.value = Prefs.nightStart(this)
        stepNightEnd.value = Prefs.nightEnd(this)
        renderSettings()
    }

    private fun renderSettings() {
        status.text = if (isServiceEnabled()) "서비스: 켜짐 ✅" else "서비스: 꺼짐 ❌"

        val locked = Prefs.isLockedToday(this)
        val night = Prefs.isNight(this)
        val editable = !locked && !night
        for (s in listOf(stepReels, stepFeed, stepExplore, stepNightStart, stepNightEnd)) {
            s.render()
            s.setControlsEnabled(editable)
        }
        nightSwitch.isEnabled = true
        tabLockSwitch.isEnabled = editable
        tabLockSwitch.alpha = if (editable) 1f else 0.5f
        headerEye.setFold(Usage.overallFold(this))
        val h = resources.displayMetrics.heightPixels.toFloat()
        stepReels.infoText.text = "오늘 ${Prefs.used(this)} / ${Prefs.limit(this)}회 사용 (DM 릴스 첫 1개는 제외)"
        stepFeed.infoText.text =
            "오늘 ${one(Stats.today(this, Stats.FEED_PX) / h)} / ${Prefs.feedLimit(this)}페이지 내려봄"
        stepExplore.infoText.text =
            "오늘 ${one(Stats.today(this, Stats.EXPLORE_PX) / h)} / ${Prefs.exploreLimit(this)}페이지 내려봄"

        setBtn(confirm, editable)
        lockInfo.text = if (night) {
            "🌙 지금은 야간 차단 시간이라 한도와 시각을 바꿀 수 없어요. ${Prefs.nightEnd(this)}시 이후에 수정하거나, 야간 차단을 끄면 바로 수정할 수 있어요."
        } else if (locked) {
            "🔒 오늘은 한도가 고정되었습니다. 새벽 4시가 지나면 수정할 수 있어요."
        } else {
            "확정하면 새벽 4시까지 수정할 수 없습니다. 확정 전에는 현재 저장된 값이 적용됩니다."
        }
        soundSwitch.isChecked = Prefs.soundOn(this)
        noticeSwitch.isChecked = Prefs.noticeOn(this)
        eyeSwitch.isChecked = Prefs.eyeMotionOn(this)
        pauseSwitch.isChecked = Prefs.pauseOn(this)
        renderEmergency()
    }

    private fun renderEmergency() {
        val left = Prefs.emergencyLeft(this)
        val ms = Prefs.emergencyRemainingMs(this)
        if (ms > 0L) {
            val s = (ms + 999L) / 1000L
            emergencyInfo.text = "긴급 해제 중 · 홈 피드와 탐색 탭의 제한이 없어요."
            emergencyBtn.text = String.format(Locale.US, "남은 시간 %d:%02d", s / 60, s % 60)
            setBtn(emergencyBtn, false)
        } else {
            emergencyInfo.text = "하루 ${Prefs.EMERGENCY_PER_DAY}번, 5분 동안 홈 피드와 탐색 탭의 제한을 없애요. " +
                "팔로우나 검색이 필요할 때 쓰세요. 릴스와 야간 차단은 그대로이고, 쓴 날은 연속 기록에서 빠져요."
            emergencyBtn.text = "긴급 해제 5분  (오늘 ${left}번 남음)"
            setBtn(emergencyBtn, left > 0)
        }
    }

    private fun askEmergency() {
        if (Prefs.emergencyActive(this) || Prefs.emergencyLeft(this) <= 0) return
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(22), dp(8), dp(22), dp(4))
        col.addView(
            text(
                "5분 동안 홈 피드와 탐색 탭의 제한이 사라집니다. 오늘 ${Prefs.emergencyLeft(this)}번 남았고, " +
                    "쓰면 오늘은 연속 기록이 끊겨요.\n\n어떤 일로 쓰시나요?",
                14f, color = Palette.MUTED
            )
        )
        val dlg = AlertDialog.Builder(this, R.style.Theme_ReelsGuard_Dialog)
            .setTitle("긴급 해제")
            .setView(col)
            .setNegativeButton("취소", null)
            .create()
        val reasons = Prefs.EMERGENCY_REASONS
        var i = 0
        while (i < reasons.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in i until minOf(i + 3, reasons.size)) {
                val b = Button(this)
                styleButton(b)
                b.text = reasons[k]
                b.setOnClickListener {
                    dlg.dismiss()
                    if (Prefs.startEmergency(this, k)) {
                        Toast.makeText(this, "5분 동안 해제됩니다 (${reasons[k]})", Toast.LENGTH_SHORT).show()
                    }
                    renderSettings()
                    renderStats()
                    ticker.removeCallbacks(tick)
                    ticker.post(tick)
                }
                val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(dp(3), dp(6), dp(3), 0)
                row.addView(b, lp)
            }
            col.addView(row)
            i += 3
        }
        dlg.show()
    }

    private fun askConfirm() {
        if (Prefs.isLockedToday(this) || Prefs.isNight(this)) return
        val r = stepReels.value
        val f = stepFeed.value
        val e = stepExplore.value
        val nOn = Prefs.nightOn(this)
        val nS = stepNightStart.value
        val nE = stepNightEnd.value
        val tl = tabLockSwitch.isChecked
        val tabLine = if (tl) "릴스 탭 완전 잠금" else "릴스 탭은 한도까지 열림"
        val nightLine = if (nOn) "야간 차단 ${nS}시 ~ ${nE}시" else "야간 차단 꺼짐"
        AlertDialog.Builder(this, R.style.Theme_ReelsGuard_Dialog)
            .setTitle("한도 확정")
            .setMessage(
                "릴스 스와이프 ${r}회\n${tabLine}\n홈 피드 ${f}페이지\n탐색 탭 ${e}페이지\n${nightLine}\n\n" +
                    "이 값으로 확정할까요? 확정하면 오늘은 변경할 수 없고, 새벽 4시가 지나야 다시 바꿀 수 있습니다."
            )
            .setPositiveButton("확정") { _, _ ->
                if (Prefs.confirmLimits(this, r, f, e, nS, nE, tl)) {
                    Toast.makeText(this, "오늘 한도가 확정되었습니다", Toast.LENGTH_SHORT).show()
                }
                renderSettings()
            }
            .setNegativeButton("취소", null)
            .show()
    }

    // =====================================================================
    // 슬라이드 2: 통계
    // =====================================================================

    private fun buildStatsPage(): View {
        statsBox = LinearLayout(this)
        statsBox.orientation = LinearLayout.VERTICAL
        statsBox.setPadding(dp(20), dp(8), dp(20), dp(28))
        val sv = ScrollView(this)
        sv.addView(statsBox)
        return sv
    }

    private fun renderStats() {
        statsBox.removeAllViews()
        val today = Day.today()
        val days = ArrayList<LocalDate>()
        for (i in 6 downTo 0) days.add(today.minusDays(i.toLong()))
        val prevDays = ArrayList<LocalDate>()
        for (i in 13 downTo 7) prevDays.add(today.minusDays(i.toLong()))

        val total = Stats.sum(this, days, Stats.IG_MS)
        val prevTotal = Stats.sum(this, prevDays, Stats.IG_MS)

        val st = Stats.streak(this, Prefs.streakSince(this))
        statsBox.addView(section("연속 기록"))
        statsBox.addView(text("${st.current}일", 32f, bold = true, color = Palette.GOLD))
        val stSub = text(
            "최고 ${st.best}일  ·  한도를 다 쓰지 않고 긴급 해제도 안 쓴 날이 이어져요",
            12f, color = Palette.MUTED
        )
        stSub.setPadding(0, dp(2), 0, dp(10))
        statsBox.addView(stSub)
        val dots = LinearLayout(this)
        dots.orientation = LinearLayout.HORIZONTAL
        for (i in 0 until 7) {
            val d = today.minusDays((6 - i).toLong())
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER
            val state = st.last7[i]
            val dot = text(
                if (state == 1) "●" else if (state == 0) "○" else "·", 20f,
                color = if (state == 1) Palette.GOLD else if (state == 0) Palette.MUTED else Palette.DIM
            )
            dot.gravity = Gravity.CENTER
            val lab = text(
                if (d == today) "오늘" else d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.KOREAN),
                11f, color = Palette.DIM
            )
            lab.gravity = Gravity.CENTER
            cell.addView(dot)
            cell.addView(lab)
            dots.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        statsBox.addView(dots)
        val gap = View(this)
        statsBox.addView(gap, LinearLayout.LayoutParams(1, dp(22)))

        statsBox.addView(section("최근 7일 인스타그램 사용"))
        statsBox.addView(text(fmtMs(total), 32f, bold = true))
        var sub = "하루 평균 ${fmtMs(total / 7)}"
        if (prevTotal > 0L) {
            val pct = ((total - prevTotal) * 100.0 / prevTotal).toInt()
            sub += "  ·  지난주보다 " + (if (pct > 0) "+$pct%" else "$pct%")
        }
        val subView = text(sub, 13f, color = Palette.MUTED)
        subView.setPadding(0, dp(2), 0, dp(14))
        statsBox.addView(subView)

        // 막대 그래프(하루별 사용 분)
        val chart = BarChartView(this)
        val values = ArrayList<Float>()
        val labels = ArrayList<String>()
        for (d in days) {
            values.add(Stats.get(this, d, Stats.IG_MS) / 60000f)
            labels.add(if (d == today) "오늘" else d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.KOREAN))
        }
        chart.values = values
        chart.labels = labels
        chart.highlight = days.size - 1
        statsBox.addView(chart, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(190)))

        // 표
        val h = resources.displayMetrics.heightPixels.toFloat()
        val head = row("항목", "오늘", "7일 합계", header = true)
        head.setPadding(0, dp(20), 0, dp(4))
        statsBox.addView(head)
        statsBox.addView(
            row(
                "인스타그램 사용",
                fmtMs(Stats.today(this, Stats.IG_MS)),
                fmtMs(total)
            )
        )
        statsBox.addView(
            row(
                "릴스 시청",
                fmtMs(Stats.today(this, Stats.REELS_MS)),
                fmtMs(Stats.sum(this, days, Stats.REELS_MS))
            )
        )
        statsBox.addView(
            row(
                "릴스 스와이프",
                "${Stats.today(this, Stats.SWIPES)}회",
                "${Stats.sum(this, days, Stats.SWIPES)}회"
            )
        )
        statsBox.addView(
            row(
                "홈 피드",
                "${one(Stats.today(this, Stats.FEED_PX) / h)}페이지",
                "${one(Stats.sum(this, days, Stats.FEED_PX) / h)}페이지"
            )
        )
        statsBox.addView(
            row(
                "탐색 탭",
                "${one(Stats.today(this, Stats.EXPLORE_PX) / h)}페이지",
                "${one(Stats.sum(this, days, Stats.EXPLORE_PX) / h)}페이지"
            )
        )
        statsBox.addView(
            row(
                "긴급 해제",
                "${Stats.today(this, Stats.EMERGENCY)}회",
                "${Stats.sum(this, days, Stats.EMERGENCY)}회"
            )
        )
        statsBox.addView(
            row(
                "숨 고르기",
                "${Stats.today(this, Stats.PAUSES)}회",
                "${Stats.sum(this, days, Stats.PAUSES)}회"
            )
        )
        statsBox.addView(
            row(
                "차단·경고",
                "${Stats.today(this, Stats.BLOCKS)}회",
                "${Stats.sum(this, days, Stats.BLOCKS)}회"
            )
        )
        // 긴급 해제 이유(7일 합계)
        statsBox.addView(section("긴급 해제 이유"))
        val reasonRows = Prefs.EMERGENCY_REASONS.indices
            .map { it to Stats.sum(this, days, Stats.reasonKey(it)) }
            .filter { it.second > 0L }
        if (reasonRows.isEmpty()) {
            statsBox.addView(text("최근 7일 동안 쓴 적이 없어요", 13f, color = Palette.MUTED))
        } else {
            val maxV = reasonRows.maxOf { it.second }
            for ((idx, n) in reasonRows) {
                statsBox.addView(reasonBar(Prefs.EMERGENCY_REASONS[idx], n, maxV))
            }
        }

        val note = text("사용 시간은 화면 반응을 기준으로 한 추정치입니다.", 11f, color = Palette.DIM)
        note.setPadding(0, dp(14), 0, 0)
        statsBox.addView(note)
    }

    /** 이유 이름 + 가로 막대 + 횟수 한 줄. */
    private fun reasonBar(name: String, n: Long, maxV: Long): View {
        val line = LinearLayout(this)
        line.orientation = LinearLayout.HORIZONTAL
        line.gravity = Gravity.CENTER_VERTICAL
        line.setPadding(0, dp(5), 0, dp(5))
        val label = text(name, 14f)
        line.addView(label, LinearLayout.LayoutParams(dp(78), ViewGroup.LayoutParams.WRAP_CONTENT))
        val track = LinearLayout(this)
        track.orientation = LinearLayout.HORIZONTAL
        val fill = View(this)
        fill.setBackgroundColor(Color.parseColor(Palette.GOLD))
        val w = (n.toFloat() / maxV).coerceIn(0.04f, 1f)
        track.addView(fill, LinearLayout.LayoutParams(0, dp(8), w))
        track.addView(View(this), LinearLayout.LayoutParams(0, dp(8), 1f - w))
        line.addView(track, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val cnt = text("${n}회", 13f, color = Palette.MUTED)
        cnt.gravity = Gravity.END
        line.addView(cnt, LinearLayout.LayoutParams(dp(48), ViewGroup.LayoutParams.WRAP_CONTENT))
        return line
    }

    private fun row(a: String, b: String, c: String, header: Boolean = false): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.setPadding(0, dp(7), 0, dp(7))
        val color = if (header) Palette.MUTED else Palette.TEXT
        val size = if (header) 12f else 14f
        val ta = text(a, size, color = color)
        ta.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.6f)
        val tb = text(b, size, color = color)
        tb.gravity = Gravity.END
        tb.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val tc = text(c, size, color = color)
        tc.gravity = Gravity.END
        tc.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.2f)
        r.addView(ta)
        r.addView(tb)
        r.addView(tc)
        return r
    }

    // =====================================================================
    // 슬라이드 3: 명언
    // =====================================================================

    private fun buildQuotesPage(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(8), dp(20), dp(28))

        col.addView(section("경고창 명언"))
        val addRow = LinearLayout(this)
        addRow.orientation = LinearLayout.HORIZONTAL
        addRow.gravity = Gravity.CENTER_VERTICAL
        quoteInput = EditText(this)
        quoteInput.hint = "새 명언 입력"
        quoteInput.setSingleLine(true)
        quoteInput.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(80))
        quoteInput.setTextColor(Color.parseColor(Palette.TEXT))
        quoteInput.setHintTextColor(Color.parseColor(Palette.DIM))
        quoteInput.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val addBtn = Button(this)
        styleButton(addBtn)
        addBtn.text = "추가"
        addBtn.setOnClickListener { addQuote() }
        addRow.addView(quoteInput)
        addRow.addView(addBtn)
        col.addView(addRow)

        val hint = text("명언마다 종소리가 조금씩 다르게 울립니다.", 12f, color = Palette.MUTED)
        hint.setPadding(0, dp(6), 0, dp(10))
        col.addView(hint)

        quoteList = LinearLayout(this)
        quoteList.orientation = LinearLayout.VERTICAL
        col.addView(quoteList)

        // 숨 고르기 문구
        val sec = section("숨 고르기 문구")
        sec.setPadding(0, dp(26), 0, 0)
        col.addView(sec)
        val addRow2 = LinearLayout(this)
        addRow2.orientation = LinearLayout.HORIZONTAL
        addRow2.gravity = Gravity.CENTER_VERTICAL
        phraseInput = EditText(this)
        phraseInput.hint = "새 문구 입력"
        phraseInput.setSingleLine(true)
        phraseInput.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(80))
        phraseInput.setTextColor(Color.parseColor(Palette.TEXT))
        phraseInput.setHintTextColor(Color.parseColor(Palette.DIM))
        phraseInput.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val addBtn2 = Button(this)
        styleButton(addBtn2)
        addBtn2.text = "추가"
        addBtn2.setOnClickListener { addPhrase() }
        addRow2.addView(phraseInput)
        addRow2.addView(addBtn2)
        col.addView(addRow2)
        val hint2 = text("인스타그램을 자주 열 때 나오는 숨 고르기 화면에 쓰여요.", 12f, color = Palette.MUTED)
        hint2.setPadding(0, dp(6), 0, dp(10))
        col.addView(hint2)
        phraseList = LinearLayout(this)
        phraseList.orientation = LinearLayout.VERTICAL
        col.addView(phraseList)

        val sv = ScrollView(this)
        sv.addView(col)
        return sv
    }

    private fun addQuote() {
        if (Prefs.addQuote(this, quoteInput.text.toString())) {
            quoteInput.setText("")
            renderQuotes()
        } else {
            Toast.makeText(this, "비어 있거나 이미 있는 명언입니다", Toast.LENGTH_SHORT).show()
        }
    }

    private fun addPhrase() {
        if (Prefs.addPausePhrase(this, phraseInput.text.toString())) {
            phraseInput.setText("")
            renderQuotes()
        } else {
            Toast.makeText(this, "비어 있거나 이미 있는 문구입니다", Toast.LENGTH_SHORT).show()
        }
    }

    private fun renderQuotes() {
        fillList(quoteList, Prefs.quotes(this), "명언이 없으면 기본 명언이 표시됩니다.") { Prefs.removeQuote(this, it) }
        fillList(phraseList, Prefs.pausePhrases(this), "문구가 없으면 기본 문구가 표시됩니다.") {
            Prefs.removePausePhrase(this, it)
        }
    }

    /** 문구 목록과 삭제 버튼을 그린다(명언·숨 고르기 문구 공용). */
    private fun fillList(target: LinearLayout, list: List<String>, emptyText: String, onDelete: (Int) -> Unit) {
        target.removeAllViews()
        if (list.isEmpty()) {
            target.addView(text(emptyText, 13f, color = Palette.MUTED))
            return
        }
        for (i in list.indices) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(0, dp(4), 0, dp(4))
            val t = text("• ${list[i]}", 15f)
            t.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            r.addView(t)
            val del = Button(this)
            styleButton(del)
            del.text = "삭제"
            val idx = i
            del.setOnClickListener {
                onDelete(idx)
                renderQuotes()
            }
            r.addView(del)
            target.addView(r)
        }
    }

    // =====================================================================
    // 슬라이드 4: 관리(점검 · 백업)
    // =====================================================================

    private fun buildManagePage(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(8), dp(20), dp(28))

        col.addView(section("점검"))
        healthText = text("", 13f)
        healthText.setLineSpacing(0f, 1.2f)
        col.addView(healthText)

        val hrow = LinearLayout(this)
        hrow.orientation = LinearLayout.HORIZONTAL
        hrow.setPadding(0, dp(10), 0, dp(6))
        hrow.addView(smallBtn("새로고침") { renderManage() }, weightParams())
        hrow.addView(smallBtn("기록 복사") { copyText("ReelsGuard 기록", diagnosticsReport(), "기록을 복사했어요") }, weightParams())
        hrow.addView(smallBtn("기록 공유") { shareText(diagnosticsReport()) }, weightParams())
        col.addView(hrow)

        val logLabel = text("최근 기록 (인스타그램을 쓴 뒤 새로고침)", 12f, color = Palette.MUTED)
        logLabel.setPadding(0, dp(6), 0, dp(4))
        col.addView(logLabel)
        logText = text("", 10.5f, color = Palette.MUTED)
        logText.typeface = Typeface.MONOSPACE
        col.addView(logText)

        val sec = section("백업 · 복원")
        sec.setPadding(0, dp(26), 0, dp(8))
        col.addView(sec)
        backupInfo = text("", 12f, color = Palette.MUTED)
        backupInfo.setLineSpacing(0f, 1.2f)
        col.addView(backupInfo)

        val b1 = LinearLayout(this)
        b1.orientation = LinearLayout.HORIZONTAL
        b1.setPadding(0, dp(10), 0, 0)
        b1.addView(smallBtn("파일로 저장") { exportFile() }, weightParams())
        b1.addView(smallBtn("파일에서 복원") { importFile() }, weightParams())
        col.addView(b1)
        val b2 = LinearLayout(this)
        b2.orientation = LinearLayout.HORIZONTAL
        b2.addView(smallBtn("글자로 복사") { copyBackupText() }, weightParams())
        b2.addView(smallBtn("붙여넣어 복원") { pasteRestore() }, weightParams())
        col.addView(b2)

        val note = text(
            "복원은 '합치기'예요. 통계는 더 큰 값을 남기고, 오늘 확정한 한도와 긴급 해제 횟수는 바뀌지 않아요. " +
                "한도를 확정했거나 야간 차단 중에는 복원할 수 없어요.",
            12f, color = Palette.DIM
        )
        note.setPadding(0, dp(10), 0, 0)
        col.addView(note)

        val sv = ScrollView(this)
        sv.addView(col)
        return sv
    }

    private fun weightParams(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(dp(3), dp(3), dp(3), dp(3))
        return lp
    }

    private fun smallBtn(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        styleButton(b)
        b.text = label
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        b.setPadding(dp(6), 0, dp(6), 0)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun ago(t: Long): String {
        if (t <= 0L) return "아직 없음"
        val s = (System.currentTimeMillis() - t) / 1000L
        return when {
            s < 5 -> "방금"
            s < 60 -> "${s}초 전"
            s < 3600 -> "${s / 60}분 전"
            s < 86400 -> "${s / 3600}시간 전"
            else -> "${s / 86400}일 전"
        }
    }

    private fun versionOf(pkg: String): String = try {
        packageManager.getPackageInfo(pkg, 0).versionName ?: "?"
    } catch (e: Exception) {
        "확인 불가"
    }

    private fun diagnosticsSummary(): String {
        val sb = StringBuilder()
        sb.append("접근성: ").append(if (isServiceEnabled()) "켜짐" else "꺼짐")
        sb.append(" · 서비스: ").append(if (Health.connected) "연결됨" else "연결 안 됨").append('\n')
        sb.append("앱 ").append(versionOf(packageName)).append(" · 인스타그램 ").append(versionOf("com.instagram.android")).append('\n')
        sb.append("마지막 인스타그램 이벤트: ").append(ago(Health.lastIgEvent))
        sb.append(" (이번 실행 ").append(Health.igEvents).append("건)\n")
        sb.append("화면 요소 인식(마지막):\n")
        for (i in Health.ELEMENTS.indices) {
            val t = Health.seenAt[i]
            sb.append("  ").append(if (t > 0L) "✓ " else "– ").append(Health.ELEMENTS[i]).append("  ").append(ago(t)).append('\n')
        }
        sb.append("기기 안드로이드 ").append(android.os.Build.VERSION.RELEASE).append(" (API ").append(android.os.Build.VERSION.SDK_INT).append(")")
        return sb.toString()
    }

    private fun diagnosticsReport(): String =
        "ReelsGuard 점검\n" + diagnosticsSummary() + "\n\n" + DebugLog.text(this)

    private fun renderManage() {
        healthText.text = diagnosticsSummary()
        val log = DebugLog.text(this, 30)
        logText.text = if (log.isEmpty()) "아직 기록이 없어요." else log.trimEnd()
        val kb = Backup.export(this).size / 1024.0
        backupInfo.text = "설정·명언·숨 고르기 문구·통계·연속 기록을 한 덩어리로 저장해요. 현재 약 " +
            String.format(Locale.US, "%.1f", kb) + "KB (압축)."
    }

    private fun copyText(label: String, s: String, done: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, s))
        Toast.makeText(this, done, Toast.LENGTH_SHORT).show()
    }

    private fun shareText(s: String) {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, s)
        startActivity(Intent.createChooser(i, "기록 공유"))
    }

    // ----- 백업 -----

    private val REQ_EXPORT = 4101
    private val REQ_IMPORT = 4102

    private fun exportFile() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/octet-stream"
        i.putExtra(Intent.EXTRA_TITLE, "reelsguard-${Day.today()}.rgb")
        startActivityForResult(i, REQ_EXPORT)
    }

    private fun importFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        startActivityForResult(i, REQ_IMPORT)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        try {
            if (requestCode == REQ_EXPORT) {
                val bytes = Backup.export(this)
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                Toast.makeText(this, "저장했어요 (${bytes.size / 1024 + 1}KB)", Toast.LENGTH_SHORT).show()
            } else if (requestCode == REQ_IMPORT) {
                val raw = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                if (raw == null || raw.size > 1024 * 1024) {
                    Toast.makeText(this, "읽을 수 없는 파일이에요", Toast.LENGTH_SHORT).show()
                    return
                }
                confirmRestore(Backup.decode(raw))
            }
        } catch (e: Exception) {
            Toast.makeText(this, "파일 처리에 실패했어요", Toast.LENGTH_SHORT).show()
        }
    }

    private fun copyBackupText() {
        copyText("ReelsGuard 백업", Backup.exportText(this), "백업을 복사했어요. 메모 앱 등에 붙여 두세요")
    }

    private fun pasteRestore() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val s = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
        confirmRestore(Backup.decodeText(s))
    }

    private fun confirmRestore(plain: String?) {
        val sum = plain?.let { Backup.summarize(it) }
        if (plain == null || sum == null) {
            Toast.makeText(this, "백업 형식이 아니에요", Toast.LENGTH_SHORT).show()
            return
        }
        Backup.blockedReason(this)?.let {
            Toast.makeText(this, it, Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this, R.style.Theme_ReelsGuard_Dialog)
            .setTitle("백업 복원")
            .setMessage("설정 ${sum.settings}개와 통계 ${sum.days}일치를 지금 앱에 합칩니다. 진행할까요?")
            .setPositiveButton("복원") { _, _ ->
                val err = Backup.apply(this, plain)
                Toast.makeText(this, err ?: "복원했어요", Toast.LENGTH_SHORT).show()
                loadSettings()
                renderStats()
                renderQuotes()
                renderManage()
            }
            .setNegativeButton("취소", null)
            .show()
    }

    // =====================================================================
    // 도우미
    // =====================================================================

    private fun setNightSwitch(on: Boolean) {
        suppressNight = true
        nightSwitch.isChecked = on
        suppressNight = false
    }

    /** 야간 차단을 끌 때는 한 번만 확인한다. 취소하면 스위치를 되돌린다. */
    private fun confirmNightOff() {
        AlertDialog.Builder(this, R.style.Theme_ReelsGuard_Dialog)
            .setTitle("야간 차단 끄기")
            .setMessage("밤에도 릴스를 열 수 있게 됩니다. 정말 끌까요?")
            .setPositiveButton("끄기") { _, _ ->
                Prefs.setNightOn(this, false)
                renderSettings()
            }
            .setNegativeButton("취소") { _, _ -> setNightSwitch(true) }
            .setOnCancelListener { setNightSwitch(true) }
            .show()
    }

    /** 금빛 테두리의 깔끔한 버튼. primary 는 금색으로 채운다. */
    private fun styleButton(b: Button, primary: Boolean = false) {
        val bg = GradientDrawable()
        bg.cornerRadius = dp(12).toFloat()
        if (primary) {
            bg.setColor(Color.parseColor(Palette.GOLD))
        } else {
            bg.setColor(Color.TRANSPARENT)
            bg.setStroke(dp(1), Color.parseColor(Palette.GOLD))
        }
        b.background = bg
        b.setTextColor(Color.parseColor(if (primary) Palette.BG else Palette.GOLD))
        b.isAllCaps = false
        b.stateListAnimator = null
        b.minHeight = dp(44)
        b.setPadding(dp(16), 0, dp(16), 0)
    }

    private fun setBtn(b: Button, enabled: Boolean) {
        b.isEnabled = enabled
        b.alpha = if (enabled) 1f else 0.35f
    }

    private fun tintSwitch(s: Switch) {
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        s.thumbTintList = ColorStateList(
            states,
            intArrayOf(Color.parseColor(Palette.GOLD), Color.parseColor(Palette.MUTED))
        )
        s.trackTintList = ColorStateList(
            states,
            intArrayOf(Color.parseColor("#66E6C98A"), Color.parseColor(Palette.LINE))
        )
    }

    private fun highlightTab(page: Int) {
        for (i in tabLabels.indices) {
            tabLabels[i].setTextColor(Color.parseColor(if (i == page) Palette.GOLD else Palette.DIM))
        }
    }

    private fun text(s: String, sizeSp: Float, bold: Boolean = false, color: String = Palette.TEXT): TextView {
        val t = TextView(this)
        t.text = s
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        t.setTextColor(Color.parseColor(color))
        if (bold) t.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        return t
    }

    private fun section(s: String): View {
        val t = text(s, 16f, bold = true, color = Palette.GOLD)
        t.letterSpacing = 0.06f
        t.setPadding(0, dp(4), 0, dp(8))
        return t
    }

    private fun one(v: Float): String = String.format(Locale.US, "%.1f", v)

    private fun fmtMs(ms: Long): String {
        if (ms <= 0L) return "0분"
        val m = ms / 60000L
        if (m <= 0L) return "1분 미만"
        return if (m >= 60L) "${m / 60}시간 ${m % 60}분" else "${m}분"
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains("$packageName/${ReelsBlockerService::class.java.name}")
    }

    /** 값 하나를 −/+ 로 조절하는 줄. */
    private inner class Stepper(
        label: String,
        private val maxV: Int,
        private val wrap: Boolean = false,
        private val suffix: String = "",
        showInfo: Boolean = true
    ) {
        var value = 0
        val infoText: TextView = text("", 12f, color = Palette.MUTED)
        private val valueText: TextView = text("0", 26f, bold = true)
        private val minus = Button(this@MainActivity)
        private val plus = Button(this@MainActivity)
        val view = LinearLayout(this@MainActivity)

        init {
            valueText.gravity = Gravity.CENTER
            valueText.minWidth = dp(64)
            styleButton(minus)
            styleButton(plus)
            minus.minWidth = dp(46)
            plus.minWidth = dp(46)
            minus.text = "−"
            minus.setOnClickListener { change(-1) }
            plus.text = "+"
            plus.setOnClickListener { change(1) }

            val line = LinearLayout(this@MainActivity)
            line.orientation = LinearLayout.HORIZONTAL
            line.gravity = Gravity.CENTER_VERTICAL
            val name = text(label, 16f, bold = true)
            name.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            line.addView(name)
            line.addView(minus)
            line.addView(valueText)
            line.addView(plus)

            view.orientation = LinearLayout.VERTICAL
            view.setPadding(0, dp(8), 0, dp(8))
            view.addView(line)
            if (showInfo) view.addView(infoText)
        }

        private fun change(d: Int) {
            val n = maxV + 1
            value = if (wrap) ((value + d) % n + n) % n else (value + d).coerceIn(0, maxV)
            render()
        }

        fun render() {
            valueText.text = value.toString() + suffix
        }

        fun setControlsEnabled(e: Boolean) {
            setBtn(minus, e)
            setBtn(plus, e)
        }
    }

    /** 손가락으로 옆으로 넘기면 한 페이지씩 딱 맞춰 멈추는 슬라이드. */
    private class SnapPager(context: Context) : HorizontalScrollView(context) {
        var onPageChanged: ((Int) -> Unit)? = null
        private var flung = false
        private var lastPage = -1

        init {
            isHorizontalScrollBarEnabled = false
            overScrollMode = OVER_SCROLL_NEVER
        }

        fun goTo(page: Int) {
            smoothScrollTo(page * width, 0)
        }

        override fun fling(velocityX: Int) {
            val w = width
            if (w <= 0) {
                super.fling(velocityX)
                return
            }
            flung = true
            val cur = scrollX.toFloat() / w
            val target = if (velocityX > 0) ceil(cur) else floor(cur)
            smoothScrollTo((target * w).toInt(), 0)
        }

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) flung = false
            val handled = super.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                if (!flung && width > 0) {
                    val page = (scrollX + width / 2) / width
                    smoothScrollTo(page * width, 0)
                }
            }
            return handled
        }

        override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
            super.onScrollChanged(l, t, oldl, oldt)
            if (width > 0) {
                val page = (l + width / 2) / width
                if (page != lastPage) {
                    lastPage = page
                    onPageChanged?.invoke(page)
                }
            }
        }
    }

    /** 최근 7일 막대 그래프. */
    private class BarChartView(context: Context) : View(context) {
        var values: List<Float> = emptyList()
        var labels: List<String> = emptyList()
        var highlight = -1

        private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()

        init {
            val d = resources.displayMetrics.density
            valuePaint.color = Color.parseColor(Palette.TEXT)
            valuePaint.textSize = 11f * d
            valuePaint.textAlign = Paint.Align.CENTER
            labelPaint.color = Color.parseColor(Palette.MUTED)
            labelPaint.textSize = 12f * d
            labelPaint.textAlign = Paint.Align.CENTER
            basePaint.color = Color.parseColor(Palette.LINE)
        }

        private fun fmt(min: Float): String {
            val m = min.toInt()
            return if (m >= 60) "${m / 60}h${m % 60}m" else "${m}m"
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (values.isEmpty()) return
            val d = resources.displayMetrics.density
            val w = width.toFloat()
            val h = height.toFloat()
            val top = 22f * d
            val bottom = h - 24f * d
            var maxV = 1f
            for (v in values) maxV = max(maxV, v)
            val slot = w / values.size
            val barW = slot * 0.5f
            val radius = 6f * d

            canvas.drawRect(0f, bottom, w, bottom + 1f * d, basePaint)
            for (i in values.indices) {
                val bh = max(values[i] / maxV * (bottom - top), 2f * d)
                val left = i * slot + (slot - barW) / 2f
                barPaint.color = Color.parseColor(if (i == highlight) Palette.GOLD else Palette.BAR)
                rect.set(left, bottom - bh, left + barW, bottom)
                canvas.drawRoundRect(rect, radius, radius, barPaint)
                canvas.drawText(fmt(values[i]), left + barW / 2f, bottom - bh - 5f * d, valuePaint)
                val label = if (i < labels.size) labels[i] else ""
                canvas.drawText(label, i * slot + slot / 2f, h - 6f * d, labelPaint)
            }
        }
    }
}
