package com.example.reelsguard

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var usage: TextView
    private lateinit var limitValue: TextView
    private lateinit var lockInfo: TextView
    private lateinit var minus: Button
    private lateinit var plus: Button
    private lateinit var confirm: Button
    private lateinit var quoteList: LinearLayout
    private lateinit var quoteInput: EditText

    private var pending = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }

        // ----- 제목 / 서비스 상태 -----
        root.addView(text("ReelsGuard", 28f, bold = true))
        status = text("", 16f).also { it.setPadding(0, dp(6), 0, dp(10)) }
        root.addView(status)
        root.addView(Button(this).apply {
            text = "접근성 설정 열기"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(text(
            "접근성 → 설치된 앱 → ReelsGuard 를 켜 주세요.\n" +
                "(안드로이드 13+ 는 앱 정보 → ⋮ → '제한된 설정 허용' 을 먼저 눌러야 합니다.)",
            13f, color = "#9AA0A6"
        ).also { it.setPadding(0, dp(8), 0, dp(24)) })

        // ----- 하루 스크롤 횟수 -----
        root.addView(section("오늘의 릴스 스크롤 횟수"))
        usage = text("", 16f)
        root.addView(usage)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(4))
        }
        minus = Button(this).apply {
            text = "−"
            setOnClickListener { change(-1) }
        }
        limitValue = text("0", 32f, bold = true).apply {
            gravity = Gravity.CENTER
            minWidth = dp(100)
        }
        plus = Button(this).apply {
            text = "+"
            setOnClickListener { change(+1) }
        }
        row.addView(minus)
        row.addView(limitValue)
        row.addView(plus)
        root.addView(row)

        confirm = Button(this).apply {
            text = "이 횟수로 확정"
            setOnClickListener { askConfirm() }
        }
        root.addView(confirm)
        lockInfo = text("", 13f, color = "#9AA0A6").also { it.setPadding(0, dp(6), 0, dp(24)) }
        root.addView(lockInfo)

        // ----- 명언 -----
        root.addView(section("경고창 명언"))
        val addRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        quoteInput = EditText(this).apply {
            hint = "새 명언 입력"
            setSingleLine(true)
            filters = arrayOf(InputFilter.LengthFilter(80))
            setHintTextColor(Color.parseColor("#6B7075"))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val addBtn = Button(this).apply {
            text = "추가"
            setOnClickListener { addQuote() }
        }
        addRow.addView(quoteInput)
        addRow.addView(addBtn)
        root.addView(addRow)

        quoteList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(quoteList)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        pending = Prefs.limit(this)
        refresh()
        renderQuotes()
    }

    // ---------- 횟수 ----------

    private fun change(delta: Int) {
        if (Prefs.isLockedToday(this)) return
        pending = (pending + delta).coerceIn(0, Prefs.MAX_LIMIT)
        refresh()
    }

    private fun askConfirm() {
        if (Prefs.isLockedToday(this)) return
        AlertDialog.Builder(this)
            .setTitle("횟수 확정")
            .setMessage("하루 ${pending}회로 확정할까요?\n\n확정하면 오늘은 변경할 수 없고, 자정이 지나야 다시 바꿀 수 있습니다.")
            .setPositiveButton("확정") { _, _ ->
                if (Prefs.confirmLimit(this, pending)) {
                    Toast.makeText(this, "오늘 ${pending}회로 확정되었습니다", Toast.LENGTH_SHORT).show()
                }
                refresh()
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun refresh() {
        status.text = if (isServiceEnabled()) "서비스: 켜짐 ✅" else "서비스: 꺼짐 ❌"

        val locked = Prefs.isLockedToday(this)
        val shown = if (locked) Prefs.limit(this) else pending
        limitValue.text = shown.toString()

        usage.text = "오늘 사용 ${Prefs.used(this)} / ${Prefs.limit(this)}회  (남은 ${Prefs.remaining(this)}회)"

        minus.isEnabled = !locked
        plus.isEnabled = !locked
        confirm.isEnabled = !locked
        lockInfo.text = if (locked) {
            "🔒 오늘은 ${Prefs.limit(this)}회로 고정되었습니다. 자정이 지나면 수정할 수 있어요."
        } else {
            "아직 오늘 횟수를 확정하지 않았습니다. 확정 전에는 현재 저장된 ${Prefs.limit(this)}회가 적용됩니다.\n" +
                "DM으로 받은 릴스 1개는 자유롭게 보고, 그 다음 스와이프부터 이 횟수가 차감됩니다."
        }
    }

    // ---------- 명언 ----------

    private fun addQuote() {
        val t = quoteInput.text.toString()
        if (Prefs.addQuote(this, t)) {
            quoteInput.setText("")
            renderQuotes()
        } else {
            Toast.makeText(this, "비어 있거나 이미 있는 명언입니다", Toast.LENGTH_SHORT).show()
        }
    }

    private fun renderQuotes() {
        quoteList.removeAllViews()
        val list = Prefs.quotes(this)
        if (list.isEmpty()) {
            quoteList.addView(text("명언이 없으면 기본 명언이 표시됩니다.", 13f, color = "#9AA0A6"))
            return
        }
        list.forEachIndexed { i, q ->
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(4), 0, dp(4))
            }
            r.addView(text("• $q", 15f).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            r.addView(Button(this).apply {
                text = "삭제"
                setOnClickListener {
                    Prefs.removeQuote(this@MainActivity, i)
                    renderQuotes()
                }
            })
            quoteList.addView(r)
        }
    }

    // ---------- 도우미 ----------

    private fun text(s: String, sizeSp: Float, bold: Boolean = false, color: String = "#FFFFFF"): TextView =
        TextView(this).apply {
            text = s
            textSize = sizeSp
            setTextColor(Color.parseColor(color))
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun section(s: String): View =
        text(s, 18f, bold = true, color = "#FF6B8A").also { it.setPadding(0, 0, 0, dp(8)) }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains("$packageName/${ReelsBlockerService::class.java.name}")
    }
}
