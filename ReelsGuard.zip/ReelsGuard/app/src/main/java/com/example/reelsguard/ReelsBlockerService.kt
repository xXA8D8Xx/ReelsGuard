package com.example.reelsguard

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * 인스타그램 릴스·피드 억제 서비스.
 *
 * 1) 하단 '릴스' 탭 위에 #0D1015 덮개를 씌우고, 누르면 명언 경고(+소리)만 띄운다.
 * 2) 그래도 릴스 탭 뷰어가 열리면 홈 탭으로 돌려보내고 명언을 띄운다.
 * 3) DM·홈·탐색 등에서 열린 릴스(하단 탭이 없는 전체화면 뷰어):
 *    - 첫 1개는 자유, 이후 스와이프는 하루 허용 횟수만큼만 허용하며 스와이프할 때마다 진행 알림을 띄운다.
 *    - 한도가 남은 채로 열었다가 다 쓰게 되면, 다음으로 넘기려는 순간 릴스 창에서 바로 나간다.
 *    - 한도가 0인 채로 열었다면(친구가 보낸 릴스 등) 그 릴스는 볼 수 있고 스와이프만 막힌다.
 *    스와이프 차단은 투명한 '방지막'이 맡는다(짧은 탭은 아래 화면에 그대로 전달).
 * 4) 홈·탐색 탭은 하루 허용 '페이지'(새 게시물을 화면 한 장 분량 내려간 것)만큼 보면,
 *    그 뒤로는 피드 영역을 #0D1015 벽으로 가린다. 홈 탭은 맨 위 스토리 줄을 남겨 둔다.
 *    새 페이지를 넘길 때마다 진행 알림을 띄운다.
 * 5) 인스타그램을 닫으면 종료 인사(명언 + 종소리)를 띄운다.
 * 6) 인스타그램 사용 시간·릴스 시간·횟수를 날짜별로 기록한다(통계 슬라이드).
 *
 * 인스타그램 업데이트로 view id 가 바뀌면 아래 상수만 고치면 된다.
 * DEBUG 가 true 이면 `adb logcat -s ReelsGuard` 에서 판단 근거가 보인다.
 */
class ReelsBlockerService : AccessibilityService() {

    private enum class Tab { HOME, EXPLORE, DIRECT, OTHER }

    companion object {
        private const val TAG = "ReelsGuard"
        private const val DEBUG = true

        private const val IG = "com.instagram.android"
        private const val SYSTEM_UI = "com.android.systemui"
        private const val ID_CLIPS_TAB = "$IG:id/clips_tab"
        private const val ID_FEED_TAB = "$IG:id/feed_tab"
        private const val ID_SEARCH_TAB = "$IG:id/search_tab"
        private const val ID_DIRECT_TAB = "$IG:id/direct_tab"
        private const val ID_PROFILE_TAB = "$IG:id/profile_tab"
        private const val ID_VIEWER_PAGER = "$IG:id/clips_viewer_view_pager"
        private const val ID_STORY_TRAY = "$IG:id/reels_tray_container"

        private const val COVER_COLOR = "#0D1015"

        private const val GRACE_MS = 1500L          // 뷰어가 열린 직후 이벤트는 무시
        private const val DEBOUNCE_MS = 900L        // 스와이프 1번이 여러 이벤트로 오는 것을 1회로 묶음
        private const val THROTTLE_MS = 150L        // 화면 변화 이벤트를 이 간격으로만 전체 처리(렉 방지)
        private const val THROTTLE_OTHER_MS = 450L  // 홈·탐색이 아닌 탭(DM 등)에서는 더 느슨하게
        private const val FEED_EXIT_GRACE_MS = 1200L
        private const val COOLDOWN_MS = 1200L       // 홈으로 돌려보낸 직후 재동작 방지
        private const val QUOTE_MS = 4500L          // 명언 경고 표시 시간
        private const val NOTICE_MS = 1700L         // 진행 알림 표시 시간
        private const val SHIELD_FEEDBACK_MS = 2500L
        private const val NIGHT_GRACE_MS = 600L     // 야간에 릴스가 열리고 이 시간이 지나면 나간다

        private const val IDLE_GAP_MS = 60_000L     // 이벤트가 이만큼 끊기면 세션 종료로 본다
        private const val FLUSH_MS = 2000L          // 통계를 저장소에 쓰는 간격
        private const val MIN_SESSION_MS = 20_000L  // 이보다 짧은 사용은 종료 인사를 생략
        private const val FAREWELL_COOLDOWN_MS = 15_000L
        private const val FAREWELL_MS = 7500L
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    // 오버레이들
    private class Cover {
        var view: View? = null
        var fold = 0f
        val rect = Rect()
    }

    private val clipsCover = Cover()    // 릴스 탭 덮개(항상)
    private val searchCover = Cover()   // 탐색 탭 덮개(오늘 한도를 다 썼을 때)

    private var shield: View? = null
    private var shieldLp: WindowManager.LayoutParams? = null

    private var wall: View? = null
    private var wallTab: Tab? = null
    private var wallButton: View? = null
    private val wallRect = Rect()

    private var quoteView: View? = null
    private val hideQuoteRunnable = Runnable { hideQuote() }
    private val nightRunnable = Runnable {
        if (viewerSince != 0L && Prefs.isNight(this)) exitForNight()
    }

    private var noticeView: View? = null
    private var noticeBg: GradientDrawable? = null
    private var noticeText: TextView? = null
    private var noticeEye: AngelEyeView? = null
    private val hideNoticeRunnable = Runnable { hideNotice() }

    private var farewellView: View? = null
    private val hideFarewellRunnable = Runnable { hideFarewell() }

    // 상태
    private var assumedTab: Tab? = null     // 마지막으로 알려진 탭(막 켰을 땐 홈)
    private var lastLoggedActive: Tab? = null
    private var viewerSince = 0L
    private var exitOnSwipe = false     // 한도가 남은 채로 뷰어를 열었는가
    private var lastAction = 0L
    private var lastCounted = 0L
    private var lastShieldFeedback = 0L
    private var lastWallSound = 0L
    private var lastFarewell = 0L

    // 세션/통계
    private var igLast = 0L
    private var igSessionStart = 0L
    private val pending = HashMap<String, Long>()
    private var flushScheduled = false
    private val flushRunnable = Runnable { flushStats() }

    // 피드 깊이 추적(탭별)
    private val pos = HashMap<Tab, Long>()
    private val maxPos = HashMap<Tab, Long>()
    private val listRect = HashMap<Tab, Rect>()
    private val pageShown = HashMap<Tab, Long>()   // 마지막으로 알림을 띄운 페이지 번호

    private val exitCheck = Runnable {
        val active = rootInActiveWindow?.packageName?.toString()
        if (active != null && active != IG && active != SYSTEM_UI) {
            onInstagramClosed(active != packageName)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        Stats.prune(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val pkg = event.packageName?.toString()
        if (pkg != IG) {
            onOtherPackage(event, pkg)
            return
        }

        if (event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) noteTabClick(event.source)

        // 긴급 해제가 (앱에서든 여기서든) 시작됐다가 끝나는 순간을 알린다
        val emergency = Prefs.emergencyActive(this)
        if (emergencyWasActive && !emergency) onEmergencyEnded()
        emergencyWasActive = emergency

        val type = event.eventType

        // 피드 스크롤 거리는 가볍게 계산할 수 있으니, 전체 처리를 건너뛰는 이벤트에서도 놓치지 않는다
        var accounted = false
        if (type == AccessibilityEvent.TYPE_VIEW_SCROLLED && viewerSince == 0L) {
            val t = assumedTab
            if (t == Tab.HOME || t == Tab.EXPLORE) {
                accountFeedScroll(event, t)
                accounted = true
            }
        }

        // 무거운 화면 분석(탭 찾기·댓글 감지 등)은 일정 간격으로만 한다. 릴스 뷰어가 열려 있을 땐 그대로 처리.
        val nowUp = SystemClock.uptimeMillis()
        val gap = if (assumedTab == Tab.DIRECT) THROTTLE_OTHER_MS else THROTTLE_MS
        if (type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            type != AccessibilityEvent.TYPE_VIEW_CLICKED &&
            viewerSince == 0L && nowUp - lastFull < gap
        ) {
            handler.removeCallbacks(trailing)
            handler.postDelayed(trailing, gap + 40L)
            return
        }
        lastFull = nowUp
        handler.removeCallbacks(trailing)
        handleIg(type, event, accounted)
    }

    private var lastFull = 0L
    private val trailing = Runnable {
        if (igLast > 0L) {
            lastFull = SystemClock.uptimeMillis()
            handleIg(AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED, null, false)
        }
    }

    private var lastActiveFeed = false   // 마지막으로 확인된 화면이 홈/탐색 피드였는가
    private var noBarSince = 0L          // 하단 탭이 안 보이기 시작한 시각(0 = 보이는 중)
    private var viewerBlocked = false    // 지금 열린 릴스 뷰어가 피드에서 열려 막는 중인가

    private fun handleIg(type: Int, event: AccessibilityEvent?, accounted: Boolean) {
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != IG) return

        val tabClips = firstVisible(root, ID_CLIPS_TAB)
        val tabFeed = firstVisible(root, ID_FEED_TAB)
        val tabSearch = firstVisible(root, ID_SEARCH_TAB)
        val tabDirect = firstVisible(root, ID_DIRECT_TAB)
        val tabProfile = firstVisible(root, ID_PROFILE_TAB)
        val viewer = root.findAccessibilityNodeInfosByViewId(ID_VIEWER_PAGER)
            .firstOrNull { it.isVisibleToUser && coversScreen(it) }

        trackTime(System.currentTimeMillis(), viewer != null)

        // 하단 탭 막대가 안 보인 지 얼마나 됐는지(릴스가 피드에서 열렸는지 가리는 데 쓴다)
        if (tabFeed != null) noBarSince = 0L
        else if (viewer == null && noBarSince == 0L) noBarSince = System.currentTimeMillis()

        updateCover(clipsCover, tabClips, "릴스는 잠시 쉬어가요", Usage.reelsFold(this))
        updateCover(
            searchCover,
            if (feedExhausted(Tab.EXPLORE)) tabSearch else null,
            "오늘의 탐색은 여기까지예요",
            3f
        )

        // 1) 릴스 탭(화면을 덮는 뷰어 + 하단 탭이 보임)
        if (viewer != null && tabClips != null) {
            removeShield()
            removeWall()
            log("릴스 탭 뷰어 감지 → 홈으로")
            blockReelsTab(root)
            return
        }

        // 2) 다른 곳에서 열린 릴스 뷰어
        if (viewer != null) {
            removeWall()
            hideNoticeIfFeed()
            if (viewerSince == 0L && !viewerBlocked) {
                val now = System.currentTimeMillis()
                viewerBlocked = lastActiveFeed &&
                    (noBarSince == 0L || now - noBarSince < FEED_EXIT_GRACE_MS)
                log("릴스 뷰어 열림: " + if (viewerBlocked) "피드에서 → 차단" else "DM 등 → 허용")
            }
            if (viewerBlocked) {
                removeShield()
                blockFeedReel()
                return
            }
            onViewerVisible(event, viewer)
            return
        }
        viewerSince = 0L
        viewerBlocked = false
        removeShield()

        // 3) 홈/탐색 피드
        val tabNodes = listOfNotNull(tabFeed, tabSearch, tabClips, tabDirect, tabProfile)
        val selected = tabNodes.filter { it.isSelected }
        // 선택 표시가 '정확히 하나'면 그것을 믿고 기억해 둔다.
        // 막 켠 직후처럼 표시가 아직 없거나 애매하면, 마지막으로 알려진 탭(새로 켰을 땐 홈)으로 본다.
        val active: Tab? = when {
            selected.size == 1 -> {
                val tab = when {
                    selected[0] === tabFeed -> Tab.HOME
                    selected[0] === tabSearch -> Tab.EXPLORE
                    selected[0] === tabDirect -> Tab.DIRECT
                    else -> Tab.OTHER
                }
                assumedTab = tab
                tab
            }
            tabFeed != null -> assumedTab
            else -> null
        }
        if (active != lastLoggedActive) {
            lastLoggedActive = active
            log("탭 판정: $active (선택 표시 ${selected.size}개, 가정 $assumedTab)")
        }

        if (active == Tab.HOME || active == Tab.EXPLORE) {
            ensurePageBaseline(active)
            if (!accounted && event != null && type == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
                accountFeedScroll(event, active)
            }
            lastActiveFeed = true
            setCoversSleeping(false)
            updateWall(root, active, tabNodes)
        } else {
            if (tabFeed != null) lastActiveFeed = false   // 다른 탭이 분명히 선택됨
            // DM 탭에서만 눈을 감고 멈춰 렉을 줄인다. 다른 탭(프로필 포함)으로 가면 다시 뜬다.
            setCoversSleeping(active == Tab.DIRECT)
            removeWall()
            hideNotice()
        }
    }

    // ---------- 탭 판정 보강 ----------

    /** 하단 탭을 눌렀다면 어느 탭인지 기억한다(선택 표시가 없는 경우를 위한 보조 수단). */
    private fun noteTabClick(src: AccessibilityNodeInfo?) {
        var n = src
        var depth = 0
        while (n != null && depth < 4) {
            val tab = when (n.viewIdResourceName) {
                ID_FEED_TAB -> Tab.HOME
                ID_SEARCH_TAB -> Tab.EXPLORE
                ID_DIRECT_TAB -> Tab.DIRECT
                ID_CLIPS_TAB, ID_PROFILE_TAB -> Tab.OTHER
                else -> null
            }
            if (tab != null) {
                assumedTab = tab
                log("탭 클릭: $tab")
                return
            }
            n = n.parent
            depth++
        }
    }

    // ---------- 세션 · 통계 ----------

    private fun trackTime(now: Long, inReels: Boolean) {
        if (igLast == 0L || now - igLast > IDLE_GAP_MS) {
            igSessionStart = now
            pos.clear()
            maxPos.clear()
            pageShown.clear()
            assumedTab = Tab.HOME       // 인스타그램은 홈 탭에서 시작한다
        } else {
            val d = now - igLast
            addStat(Stats.IG_MS, d)
            if (inReels) addStat(Stats.REELS_MS, d)
        }
        igLast = now
    }

    private fun addStat(key: String, v: Long) {
        if (v <= 0L) return
        pending[key] = (pending[key] ?: 0L) + v
        if (!flushScheduled) {
            flushScheduled = true
            handler.postDelayed(flushRunnable, FLUSH_MS)
        }
    }

    private fun statNow(key: String): Long = Stats.today(this, key) + (pending[key] ?: 0L)

    private fun flushStats() {
        flushScheduled = false
        handler.removeCallbacks(flushRunnable)
        for ((k, v) in pending) Stats.add(this, k, v)
        pending.clear()
    }

    // ---------- 인스타그램 종료 ----------

    private fun onOtherPackage(event: AccessibilityEvent, pkg: String?) {
        if (pkg == null || pkg == packageName || pkg == SYSTEM_UI) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        // 키보드 등 일시적인 창일 수 있으니, 잠시 뒤 '활성 창'이 정말 인스타가 아닐 때만 종료로 본다
        handler.removeCallbacks(exitCheck)
        handler.postDelayed(exitCheck, 450L)
    }

    private fun onInstagramClosed(allowFarewell: Boolean) {
        val now = System.currentTimeMillis()
        val duration = if (igLast > 0L) igLast - igSessionStart else 0L
        flushStats()
        removeCovers()
        removeShield()
        removeWall()
        hideQuote()
        hideNotice()
        igLast = 0L
        viewerSince = 0L
        assumedTab = null
        lastActiveFeed = false
        noBarSince = 0L
        viewerBlocked = false
        coversSleeping = false
        handler.removeCallbacks(trailing)
        pos.clear()
        maxPos.clear()
        pageShown.clear()

        if (allowFarewell && duration >= MIN_SESSION_MS && now - lastFarewell >= FAREWELL_COOLDOWN_MS) {
            lastFarewell = now
            log("인스타그램 종료 → 종료 인사")
            showFarewell()
        }
    }

    // ---------- 릴스 탭 ----------

    private fun blockReelsTab(root: AccessibilityNodeInfo) {
        val now = System.currentTimeMillis()
        if (now - lastAction < COOLDOWN_MS) return
        lastAction = now

        addStat(Stats.BLOCKS, 1L)
        showQuote("릴스는 잠시 쉬어가요")

        val feed = root.findAccessibilityNodeInfosByViewId(ID_FEED_TAB).firstOrNull()
        // 이미 홈 탭이면 다시 누르지 않는다(홈 새로고침 방지)
        if (feed?.isSelected == true) return
        val clicked = feed?.let { clickNodeOrParent(it) } ?: false
        if (!clicked) performGlobalAction(GLOBAL_ACTION_BACK)
    }

    // ---------- 피드 게시물에서 열린 릴스 ----------

    /** 홈 피드·탐색의 게시물을 눌러 열린 릴스는 보여 주지 않고 되돌린다(긴급 해제 중에도 마찬가지). */
    private fun blockFeedReel() {
        val now = System.currentTimeMillis()
        if (now - lastAction < COOLDOWN_MS) return
        lastAction = now
        log("피드에서 연 릴스 → 뒤로")
        addStat(Stats.BLOCKS, 1L)
        showQuote("피드의 릴스는 쉬어가요", Usage.reelsFold(this))
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    // ---------- 눈 감기(DM 등 다른 탭) ----------

    private var coversSleeping = false

    private fun setCoversSleeping(sleep: Boolean) {
        if (coversSleeping == sleep) return
        coversSleeping = sleep
        (clipsCover.view as? AngelEyeView)?.setSleeping(sleep)
        (searchCover.view as? AngelEyeView)?.setSleeping(sleep)
    }

    // ---------- 릴스 뷰어(탭이 아닌 곳에서 열림) ----------

    private fun onViewerVisible(event: AccessibilityEvent?, viewer: AccessibilityNodeInfo) {
        if (viewerSince == 0L) {
            viewerSince = System.currentTimeMillis()
            // 한도가 남은 채로 열었는지 기억해 둔다(다 쓰면 나가기 / 처음부터 0이면 보기만 허용)
            exitOnSwipe = Prefs.remaining(this) > 0
            // 야간에는 이벤트가 오지 않아도 잠시 뒤 확인하도록 예약해 둔다
            if (Prefs.isNight(this)) {
                handler.removeCallbacks(nightRunnable)
                handler.postDelayed(nightRunnable, NIGHT_GRACE_MS + 100L)
            }
        }

        // 야간 차단 시간대: 한도와 상관없이 릴스 창에서 바로 나간다
        if (Prefs.isNight(this)) {
            removeShield()
            if (System.currentTimeMillis() - viewerSince > NIGHT_GRACE_MS) exitForNight()
            return
        }

        if (Prefs.remaining(this) <= 0) {
            // 횟수 소진: 스와이프를 아예 못 하게 방지막을 씌운다
            val r = Rect()
            viewer.getBoundsInScreen(r)
            ensureShield(clipToScreen(r))

            // 방지막이 없을 때를 대비한 보험(넘겨지면 뒤로 가기)
            if (shield == null &&
                event != null &&
                event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED &&
                isPagerScroll(event) &&
                System.currentTimeMillis() - viewerSince > GRACE_MS
            ) {
                onShieldSwipe()
                performGlobalAction(GLOBAL_ACTION_BACK)
                viewerSince = 0L
            }
            return
        }

        removeShield()
        if (event != null && event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED && isPagerScroll(event)) {
            onReelSwiped()
        }
    }

    private fun onReelSwiped() {
        val now = System.currentTimeMillis()
        if (now - viewerSince < GRACE_MS) return
        if (now - lastCounted < DEBOUNCE_MS) return
        lastCounted = now

        Stats.add(this, Stats.SWIPES, 1L)
        val used = Prefs.used(this)
        val limit = Prefs.limit(this)
        log("스와이프 허용: $used/$limit")
        showNotice("릴스  $used / $limit", used * 10 >= limit * 8, Usage.reelsFold(this))
    }

    /** 방지막 위에서 위/아래로 넘기려 했을 때. */
    private fun onShieldSwipe() {
        val now = System.currentTimeMillis()
        if (now - lastShieldFeedback < SHIELD_FEEDBACK_MS) return
        lastShieldFeedback = now
        addStat(Stats.BLOCKS, 1L)
        Stats.add(this, Stats.OVER, 1L)
        if (exitOnSwipe) {
            exitViewer()
        } else {
            showQuote("오늘 릴스 횟수를 모두 썼어요", 3f)
        }
    }

    /** 야간 차단 시간대에 릴스가 열려 있을 때: 릴스 창에서 나간다. */
    private fun exitForNight() {
        val now = System.currentTimeMillis()
        if (now - lastAction < COOLDOWN_MS) return
        lastAction = now
        log("야간 차단 → 릴스 창에서 나감")
        addStat(Stats.BLOCKS, 1L)
        showQuote("지금은 쉬어갈 시간이에요", 3f)
        viewerSince = 0L
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    /** 한도를 다 쓰고 다음 릴스로 넘기려는 순간: 릴스 창에서 바로 나간다. */
    private fun exitViewer() {
        log("한도 소진 → 릴스 창에서 나감")
        showQuote("오늘 릴스 횟수를 모두 썼어요", 3f)
        viewerSince = 0L
        // 터치 처리 중에 방지막을 지우지 않도록 한 박자 뒤에 정리한다
        handler.post { removeShield() }
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    private fun ensureShield(r: Rect) {
        if (r.width() <= 0 || r.height() <= 0) return
        val existing = shield
        val lp = shieldLp
        if (existing != null && lp != null) {
            if (lp.x != r.left || lp.y != r.top || lp.width != r.width() || lp.height != r.height()) {
                lp.x = r.left
                lp.y = r.top
                lp.width = r.width()
                lp.height = r.height()
                try {
                    wm.updateViewLayout(existing, lp)
                } catch (e: Exception) {
                    log("방지막 갱신 실패: ${e.message}")
                }
            }
            return
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var downT = 0L
        var fired = false

        val v = View(this)
        v.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX
                    downY = ev.rawY
                    downT = ev.eventTime
                    fired = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX
                    val dy = ev.rawY - downY
                    if (!fired && abs(dy) > slop * 2 && abs(dy) > abs(dx)) {
                        fired = true
                        onShieldSwipe()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    val moved = hypot(ev.rawX - downX, ev.rawY - downY)
                    if (!fired && moved < slop && ev.eventTime - downT < 400L) {
                        forwardTap(downX, downY)
                    }
                }
            }
            true
        }

        val params = overlayParams(r, touchable = true)
        try {
            wm.addView(v, params)
            shield = v
            shieldLp = params
            log("방지막 설치")
        } catch (e: Exception) {
            log("방지막 추가 실패: ${e.message}")
        }
    }

    /** 방지막이 삼킨 짧은 탭을 아래 화면(인스타그램)에 다시 전달한다. */
    private fun forwardTap(x: Float, y: Float) {
        setShieldTouchable(false)
        handler.postDelayed({
            val path = Path()
            path.moveTo(x, y)
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0L, 40L))
                .build()
            val ok = try {
                dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        setShieldTouchable(true)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        setShieldTouchable(true)
                    }
                }, null)
            } catch (e: Exception) {
                false
            }
            if (!ok) setShieldTouchable(true)
        }, 40L)
        // 안전장치: 어떤 경우에도 방지막이 계속 투과 상태로 남지 않게 한다
        handler.postDelayed({ setShieldTouchable(true) }, 700L)
    }

    private fun setShieldTouchable(touchable: Boolean) {
        val v = shield ?: return
        val lp = shieldLp ?: return
        lp.flags = if (touchable) {
            lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        try {
            wm.updateViewLayout(v, lp)
        } catch (e: Exception) {
            // 이미 제거됨
        }
    }

    private fun removeShield() {
        val v = shield ?: return
        safeRemove(v)
        shield = null
        shieldLp = null
    }

    // ---------- 홈/탐색 피드 한도 ----------

    private fun feedKey(tab: Tab): String = if (tab == Tab.HOME) Stats.FEED_PX else Stats.EXPLORE_PX

    private fun pageLimit(tab: Tab): Int =
        if (tab == Tab.HOME) Prefs.feedLimit(this) else Prefs.exploreLimit(this)

    /** 오늘 새로 내려가 본 '페이지' 수(화면 한 장 = 1페이지). */
    private fun pageOf(tab: Tab): Long {
        val h = max(1, resources.displayMetrics.heightPixels).toLong()
        return statNow(feedKey(tab)) / h
    }

    private fun ensurePageBaseline(tab: Tab) {
        if (pageShown[tab] == null) pageShown[tab] = pageOf(tab)
    }

    private fun accountFeedScroll(event: AccessibilityEvent, tab: Tab) {
        val src = event.source ?: return
        val r = Rect()
        src.getBoundsInScreen(r)
        val dm = resources.displayMetrics
        // 스토리 줄 같은 작은 가로 스크롤은 제외하고, 화면을 크게 차지하는 목록만 본다
        if (r.width() < dm.widthPixels * 0.8 || r.height() < dm.heightPixels * 0.35) return
        listRect[tab] = Rect(r)

        if (Build.VERSION.SDK_INT < 28) return
        val dy = event.scrollDeltaY
        if (dy == 0 || abs(dy) > dm.heightPixels * 4) return

        val p = max(0L, (pos[tab] ?: 0L) + dy)
        pos[tab] = p
        val m = maxPos[tab] ?: 0L
        if (p > m) {
            // 이미 본 곳을 다시 오르내릴 때는 세지 않고, 새로 내려간 만큼만 센다
            maxPos[tab] = p
            // 긴급 해제 중에 내려간 거리는 오늘 사용량에 넣지 않는다
            if (!Prefs.emergencyActive(this)) {
                addStat(feedKey(tab), p - m)
                announcePage(tab)
            }
        }
    }

    /** 새 페이지를 하나 넘겼다고 판단되면 진행 상황을 알린다. */
    private fun announcePage(tab: Tab) {
        val page = pageOf(tab)
        val prev = pageShown[tab] ?: page
        if (page <= prev) return
        pageShown[tab] = page

        val limit = pageLimit(tab)
        if (page >= limit) return  // 한도에 도달하면 곧바로 가림막이 뜬다
        val name = if (tab == Tab.HOME) "홈 피드" else "탐색"
        val fold = Usage.feedFold(this, tab == Tab.HOME, pending[feedKey(tab)] ?: 0L)
        showNotice("$name  $page / $limit 페이지", page * 10 >= limit * 8L, fold)
    }

    private fun feedExhausted(tab: Tab): Boolean {
        if (Prefs.emergencyActive(this)) return false   // 긴급 해제 중에는 제한 없음
        val dm = resources.displayMetrics
        val used = statNow(feedKey(tab))
        return used >= pageLimit(tab).toLong() * dm.heightPixels
    }

    private fun updateWall(root: AccessibilityNodeInfo, tab: Tab, tabNodes: List<AccessibilityNodeInfo>) {
        if (!feedExhausted(tab)) {
            removeWall()
            return
        }
        val dm = resources.displayMetrics
        val rootRect = Rect()
        root.getBoundsInScreen(rootRect)

        var barTop = dm.heightPixels
        for (n in tabNodes) {
            val r = Rect()
            n.getBoundsInScreen(r)
            if (r.top in 1 until barTop) barTop = r.top
        }
        var top = listRect[tab]?.top ?: (rootRect.top + (100 * dm.density).toInt())

        // 홈 탭: 맨 위 스토리 줄이 보이면 그 아래부터 가린다
        var storiesVisible = false
        if (tab == Tab.HOME) {
            val tb = trayBottom(root, top)
            if (tb != null && tb > top && tb < barTop) {
                top = tb + (4 * dm.density).toInt()
                storiesVisible = true
            }
        }

        val rect = Rect(0, top, dm.widthPixels, barTop)
        if (rect.height() < (120 * dm.density).toInt()) {
            removeWall()
            return
        }
        ensureWall(tab, rect, storiesVisible)
    }

    /** 홈 피드 맨 위 스토리 줄의 아래 끝 y 좌표. 안 보이면 null. */
    private fun trayBottom(root: AccessibilityNodeInfo, listTop: Int): Int? {
        val dm = resources.displayMetrics
        val r = Rect()
        var best = -1

        for (n in root.findAccessibilityNodeInfosByViewId(ID_STORY_TRAY)) {
            if (!n.isVisibleToUser) continue
            n.getBoundsInScreen(r)
            if (r.height() in 1..(300 * dm.density).toInt() && r.bottom > best) best = r.bottom
        }
        if (best > 0) return best

        // 보조 방법: '스토리' 라는 말이 들어 있는 항목이 목록 맨 위쪽에 보이면 스토리 줄로 본다
        val limitTop = listTop + (220 * dm.density).toInt()
        for (kw in arrayOf("스토리", "story", "Story")) {
            for (n in root.findAccessibilityNodeInfosByText(kw)) {
                if (!n.isVisibleToUser) continue
                n.getBoundsInScreen(r)
                if (r.top in listTop..limitTop && r.height() < (260 * dm.density).toInt() && r.bottom > best) {
                    best = r.bottom
                }
            }
        }
        return if (best > 0) best else null
    }

    private fun ensureWall(tab: Tab, r: Rect, storiesVisible: Boolean) {
        val existing = wall
        if (existing != null && wallTab == tab) {
            wallButton?.visibility = if (storiesVisible) View.GONE else View.VISIBLE
            if (r != wallRect) {
                try {
                    wm.updateViewLayout(existing, overlayParams(r, touchable = true))
                    wallRect.set(r)
                } catch (e: Exception) {
                    log("벽 갱신 실패: ${e.message}")
                }
            }
            return
        }
        removeWall()

        val dp = resources.displayMetrics.density
        val quote = Prefs.randomQuote(this)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        box.setBackgroundColor(Color.parseColor(COVER_COLOR))
        val pad = (28 * dp).toInt()
        box.setPadding(pad, pad, pad, pad)
        box.setOnTouchListener { _, _ -> true }

        val eye = AngelEyeView(this)
        eye.layoutParams = LinearLayout.LayoutParams((190 * dp).toInt(), (104 * dp).toInt())
        eye.setFold(3f)
        box.addView(eye)

        val title = TextView(this)
        title.text = if (tab == Tab.HOME) "오늘의 홈 피드는\n여기까지예요" else "오늘의 탐색은\n여기까지예요"
        title.setTextColor(Color.parseColor(Palette.GOLD))
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        title.gravity = Gravity.CENTER
        title.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        box.addView(title)

        val q = TextView(this)
        q.text = "“$quote”"
        q.setTextColor(Color.parseColor(Palette.TEXT))
        q.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
        q.gravity = Gravity.CENTER
        q.typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC)
        q.setPadding(0, (24 * dp).toInt(), 0, (24 * dp).toInt())
        box.addView(q)

        val hint = TextView(this)
        hint.text = if (tab == Tab.HOME) {
            "스토리는 맨 위에서 볼 수 있어요"
        } else {
            "아래 탭에서 다른 화면으로 이동할 수 있어요"
        }
        hint.setTextColor(Color.parseColor(Palette.MUTED))
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        hint.gravity = Gravity.CENTER
        box.addView(hint)

        if (tab == Tab.HOME) {
            // 스토리 줄이 위로 스크롤되어 사라졌을 때만: 맨 위로 가는 버튼 + (작은) 긴급 해제 버튼.
            // 스토리가 보일 때는 둘 다 숨긴다.
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER
            val btn = Button(this)
            btn.text = "↑ 맨 위로 가서 스토리 보기"
            btn.setOnClickListener { scrollHomeToTop() }
            row.addView(btn)
            compactEmergencyButton(dp)?.let { row.addView(it) }
            row.visibility = if (storiesVisible) View.GONE else View.VISIBLE
            box.addView(row)
            wallButton = row
        } else {
            box.addView(emergencyControl(dp))
        }

        try {
            wm.addView(box, overlayParams(r, touchable = true))
            wall = box
            wallTab = tab
            wallRect.set(r)
            box.alpha = 0f
            box.animate().alpha(1f).setDuration(300L).start()
            hideNotice()
            // 홈 탭은 인스타를 켜고 끌 때마다 보이므로 경고음도, 경고 횟수·연속 기록 반영도 하지 않는다
            if (tab != Tab.HOME) {
                addStat(Stats.BLOCKS, 1L)
                Stats.add(this, Stats.OVER, 1L)
                val now = System.currentTimeMillis()
                if (now - lastWallSound > 8000L) {
                    lastWallSound = now
                    Chime.playWarning(this, quote.hashCode())
                }
            }
            log("피드 벽 표시: $tab")
        } catch (e: Exception) {
            wallButton = null
            log("벽 추가 실패: ${e.message}")
        }
    }

    /** 홈 탭을 눌러 피드를 맨 위로 올린다(인스타그램의 '맨 위로' 동작). */
    private fun scrollHomeToTop() {
        val root = rootInActiveWindow ?: return
        val feed = root.findAccessibilityNodeInfosByViewId(ID_FEED_TAB).firstOrNull() ?: return
        clickNodeOrParent(feed)
    }

    private fun removeWall() {
        val v = wall ?: return
        safeRemove(v)
        wall = null
        wallTab = null
        wallButton = null
        wallRect.setEmpty()
    }

    // ---------- 탭 덮개(릴스 탭·탐색 탭) ----------

    private fun updateCover(c: Cover, tab: AccessibilityNodeInfo?, headline: String, fold: Float) {
        c.fold = fold
        (c.view as? AngelEyeView)?.setFold(fold)
        if (tab == null) {
            removeCover(c)
            return
        }
        val r = Rect()
        tab.getBoundsInScreen(r)
        if (r.isEmpty) {
            removeCover(c)
            return
        }
        val existing = c.view
        if (existing == null) {
            val v = AngelEyeView(this)
            v.setBackgroundColor(Color.parseColor(COVER_COLOR))
            v.setFold(fold)
            v.setSleeping(coversSleeping, instant = true)
            v.setOnClickListener {
                addStat(Stats.BLOCKS, 1L)
                showQuote(headline, c.fold, emergency = c === searchCover)
            }
            try {
                wm.addView(v, overlayParams(r, touchable = true))
                c.view = v
                c.rect.set(r)
            } catch (e: Exception) {
                log("덮개 추가 실패: ${e.message}")
            }
        } else if (r != c.rect) {
            try {
                wm.updateViewLayout(existing, overlayParams(r, touchable = true))
                c.rect.set(r)
            } catch (e: Exception) {
                log("덮개 갱신 실패: ${e.message}")
            }
        }
    }

    private fun removeCover(c: Cover) {
        val v = c.view ?: return
        safeRemove(v)
        c.view = null
        c.rect.setEmpty()
    }

    private fun removeCovers() {
        removeCover(clipsCover)
        removeCover(searchCover)
    }

    // ---------- 진행 알림(페이지/스와이프) ----------

    private fun showNotice(text: String, warn: Boolean, fold: Float) {
        if (!Prefs.noticeOn(this)) return
        val dp = resources.displayMetrics.density

        if (noticeView == null) {
            val nb = GradientDrawable()
            nb.cornerRadius = 30 * dp

            val box = LinearLayout(this)
            box.orientation = LinearLayout.HORIZONTAL
            box.gravity = Gravity.CENTER_VERTICAL
            box.background = nb
            box.setPadding((8 * dp).toInt(), (4 * dp).toInt(), (22 * dp).toInt(), (4 * dp).toInt())

            val eye = AngelEyeView(this)
            eye.layoutParams = LinearLayout.LayoutParams((50 * dp).toInt(), (30 * dp).toInt())
            box.addView(eye)

            val t = TextView(this)
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            t.gravity = Gravity.CENTER
            t.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            box.addView(t)

            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            lp.y = (88 * dp).toInt()
            try {
                wm.addView(box, lp)
            } catch (e: Exception) {
                log("알림 표시 실패: ${e.message}")
                return
            }
            box.alpha = 0f
            box.animate().alpha(1f).setDuration(150L).start()
            noticeView = box
            noticeBg = nb
            noticeText = t
            noticeEye = eye
        }

        // 한도에 가까우면 금빛 테두리와 글씨로, 아니면 차분하게
        noticeBg?.setColor(Color.parseColor("#F2171B24"))
        noticeBg?.setStroke(max(1, (1 * dp).toInt()), Color.parseColor(if (warn) Palette.GOLD else Palette.LINE))
        noticeText?.setTextColor(Color.parseColor(if (warn) Palette.GOLD else Palette.TEXT))
        noticeText?.text = text
        noticeEye?.setFold(fold)

        handler.removeCallbacks(hideNoticeRunnable)
        handler.postDelayed(hideNoticeRunnable, NOTICE_MS)
    }

    private fun hideNotice() {
        handler.removeCallbacks(hideNoticeRunnable)
        val v = noticeView ?: return
        noticeView = null
        noticeBg = null
        noticeText = null
        noticeEye = null
        v.animate().alpha(0f).setDuration(200L).withEndAction { safeRemove(v) }.start()
    }

    /** 릴스 뷰어가 떠 있을 땐 피드용 알림을 걷는다(릴스 알림은 그대로 둔다). */
    private fun hideNoticeIfFeed() {
        // 릴스 알림과 피드 알림은 같은 뷰를 쓰므로, 뷰어가 처음 보일 때만 정리한다
        if (viewerSince == 0L) hideNotice()
    }

    // ---------- 긴급 해제 ----------

    private var emergencyWasActive = false

    /** 작은 긴급 해제 버튼. 남은 횟수가 없으면 null. */
    private fun compactEmergencyButton(dp: Float): Button? {
        val left = Prefs.emergencyLeft(this)
        if (left <= 0) return null
        val b = Button(this)
        b.text = "긴급 해제 ($left)"
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        b.setTextColor(Color.parseColor(Palette.MUTED))
        b.isAllCaps = false
        b.minHeight = 0
        b.minimumHeight = 0
        b.setPadding((10 * dp).toInt(), (4 * dp).toInt(), (10 * dp).toInt(), (4 * dp).toInt())
        val bg = GradientDrawable()
        bg.cornerRadius = 10 * dp
        bg.setColor(Color.TRANSPARENT)
        bg.setStroke(dp.toInt().coerceAtLeast(1), Color.parseColor(Palette.LINE))
        b.background = bg
        b.setOnClickListener { startEmergency() }
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.leftMargin = (10 * dp).toInt()
        b.layoutParams = lp
        return b
    }

    /** 탐색 벽·경고창에 붙이는 긴급 해제 줄(작게). 남은 횟수가 없으면 안내 문구. */
    private fun emergencyControl(dp: Float): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.setPadding(0, (14 * dp).toInt(), 0, 0)
        val btn = compactEmergencyButton(dp)
        if (btn != null) {
            btn.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            col.addView(btn)
        } else {
            val t = TextView(this)
            t.text = "오늘 긴급 해제를 모두 썼어요"
            t.setTextColor(Color.parseColor(Palette.DIM))
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            t.gravity = Gravity.CENTER
            col.addView(t)
        }
        return col
    }

    private fun startEmergency() {
        if (!Prefs.startEmergency(this)) return
        log("긴급 해제 시작 (남은 ${Prefs.emergencyLeft(this)}번)")
        removeWall()
        removeCover(searchCover)
        hideQuote()
        emergencyWasActive = true
        showNotice("긴급 해제 5분  ·  오늘 ${Prefs.emergencyLeft(this)}번 남음", false, 0f)
    }

    private fun onEmergencyEnded() {
        log("긴급 해제 종료")
        // 인스타그램을 쓰는 중일 때만 알린다. 벽과 덮개는 다음 화면 이벤트에서 다시 올라온다.
        if (igLast > 0L) showNotice("긴급 해제가 끝났어요", true, 3f)
    }

    // ---------- 명언 경고 ----------

    private fun showQuote(headline: String, fold: Float = Usage.reelsFold(this), emergency: Boolean = false) {
        if (quoteView != null) return

        val dp = resources.displayMetrics.density
        val quote = Prefs.randomQuote(this)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        box.setBackgroundColor(Color.parseColor("#F00D1015"))
        val pad = (32 * dp).toInt()
        box.setPadding(pad, pad, pad, pad)
        box.setOnClickListener { hideQuote() }

        val orn = AngelEyeView(this)
        orn.layoutParams = LinearLayout.LayoutParams((210 * dp).toInt(), (114 * dp).toInt())
        orn.setFold(fold)
        box.addView(orn)

        val head = TextView(this)
        head.text = headline
        head.setTextColor(Color.parseColor(Palette.GOLD))
        head.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        head.gravity = Gravity.CENTER
        head.letterSpacing = 0.08f
        head.setPadding(0, (10 * dp).toInt(), 0, 0)
        box.addView(head)

        val q = TextView(this)
        q.text = "“$quote”"
        q.setTextColor(Color.parseColor(Palette.TEXT))
        q.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
        q.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)
        q.gravity = Gravity.CENTER
        q.setPadding(0, (20 * dp).toInt(), 0, 0)
        box.addView(q)

        if (emergency) {
            val ctl = emergencyControl(dp)
            ctl.setPadding(0, (28 * dp).toInt(), 0, 0)
            box.addView(ctl)
        }

        try {
            wm.addView(box, fullScreenParams())
            quoteView = box
            hideNotice()
            box.alpha = 0f
            box.animate().alpha(1f).setDuration(220L).start()
            handler.removeCallbacks(hideQuoteRunnable)
            handler.postDelayed(hideQuoteRunnable, QUOTE_MS)
            Chime.playWarning(this, quote.hashCode())
        } catch (e: Exception) {
            log("명언 표시 실패: ${e.message}")
        }
    }

    private fun hideQuote() {
        handler.removeCallbacks(hideQuoteRunnable)
        val v = quoteView ?: return
        quoteView = null
        v.animate().alpha(0f).setDuration(250L).withEndAction { safeRemove(v) }.start()
    }

    // ---------- 종료 인사 ----------

    private fun showFarewell() {
        if (farewellView != null) return

        val dp = resources.displayMetrics.density
        val quote = Prefs.randomQuote(this)
        val minutes = Stats.today(this, Stats.IG_MS) / 60000L

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        val pad = (36 * dp).toInt()
        box.setPadding(pad, pad, pad, pad)
        box.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(
                Color.parseColor("#F21B2230"),
                Color.parseColor("#F20D1015"),
                Color.parseColor("#F2000000")
            )
        )
        box.setOnClickListener { hideFarewell() }

        // 앱 아이콘과 같은 세라핌(한쪽 9장씩): 눈이 떠지며 날개가 차례로 펼쳐진다
        val orn = SeraphView(this, 350L)
        orn.layoutParams = LinearLayout.LayoutParams((270 * dp).toInt(), (230 * dp).toInt())
        orn.alpha = 0f
        orn.scaleX = 0.88f
        orn.scaleY = 0.88f
        box.addView(orn)

        val title = TextView(this)
        title.text = "오늘도 수고했어요"
        title.setTextColor(Color.parseColor(Palette.GOLD))
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        title.letterSpacing = 0.2f
        title.gravity = Gravity.CENTER
        title.setPadding(0, (14 * dp).toInt(), 0, 0)
        title.alpha = 0f
        box.addView(title)

        val q = TextView(this)
        q.text = "“$quote”"
        q.setTextColor(Color.parseColor(Palette.TEXT))
        q.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30f)
        q.typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC)
        q.gravity = Gravity.CENTER
        q.setLineSpacing(0f, 1.25f)
        q.setPadding(0, (26 * dp).toInt(), 0, (26 * dp).toInt())
        q.alpha = 0f
        q.translationY = 28 * dp
        box.addView(q)

        val line = View(this)
        line.setBackgroundColor(Color.parseColor(Palette.GOLD))
        line.layoutParams = LinearLayout.LayoutParams((48 * dp).toInt(), (2 * dp).toInt())
        line.alpha = 0f
        box.addView(line)

        val info = TextView(this)
        val streak = Stats.streak(this, Prefs.streakSince(this)).current
        info.text = "오늘 인스타그램 ${minutes}분" + (if (streak >= 2) "  ·  연속 ${streak}일째" else "")
        info.setTextColor(Color.parseColor(Palette.MUTED))
        info.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        info.gravity = Gravity.CENTER
        info.setPadding(0, (22 * dp).toInt(), 0, 0)
        info.alpha = 0f
        box.addView(info)

        try {
            wm.addView(box, fullScreenParams())
            farewellView = box
        } catch (e: Exception) {
            log("종료 인사 표시 실패: ${e.message}")
            return
        }

        box.alpha = 0f
        box.animate().alpha(1f).setDuration(700L).start()
        orn.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(900L)
            .setInterpolator(OvershootInterpolator()).start()
        title.animate().alpha(1f).setStartDelay(250L).setDuration(600L).start()
        q.animate().alpha(1f).translationY(0f).setStartDelay(500L).setDuration(900L)
            .setInterpolator(DecelerateInterpolator()).start()
        line.animate().alpha(1f).setStartDelay(1100L).setDuration(500L).start()
        info.animate().alpha(1f).setStartDelay(1400L).setDuration(600L).start()

        handler.removeCallbacks(hideFarewellRunnable)
        handler.postDelayed(hideFarewellRunnable, FAREWELL_MS)
        Chime.playFarewell(this, quote.hashCode())
    }

    private fun hideFarewell() {
        handler.removeCallbacks(hideFarewellRunnable)
        val v = farewellView ?: return
        farewellView = null
        v.animate().alpha(0f).setDuration(500L).withEndAction { safeRemove(v) }.start()
    }

    // ---------- 도우미 ----------

    private fun firstVisible(root: AccessibilityNodeInfo, id: String): AccessibilityNodeInfo? =
        root.findAccessibilityNodeInfosByViewId(id).firstOrNull { it.isVisibleToUser }

    private fun coversScreen(n: AccessibilityNodeInfo): Boolean {
        val r = Rect()
        n.getBoundsInScreen(r)
        val dm = resources.displayMetrics
        return r.width() >= dm.widthPixels * 0.8 && r.height() >= dm.heightPixels * 0.5
    }

    private fun isPagerScroll(event: AccessibilityEvent): Boolean {
        val src = event.source ?: return false
        if (src.viewIdResourceName == ID_VIEWER_PAGER) return true
        // id 가 바뀐 경우를 대비: 화면 대부분을 덮는 스크롤 뷰
        val r = Rect()
        src.getBoundsInScreen(r)
        val dm = resources.displayMetrics
        return r.width() >= dm.widthPixels * 0.8 && r.height() >= dm.heightPixels * 0.8
    }

    private fun clipToScreen(r: Rect): Rect {
        val dm = resources.displayMetrics
        return Rect(
            max(r.left, 0),
            max(r.top, 0),
            min(r.right, dm.widthPixels),
            min(r.bottom, dm.heightPixels)
        )
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = node
        while (cur != null) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
        }
        return false
    }

    private fun overlayParams(r: Rect, touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val lp = WindowManager.LayoutParams(
            r.width(),
            r.height(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = r.left
        lp.y = r.top
        return lp
    }

    private fun fullScreenParams(): WindowManager.LayoutParams {
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
    }

    private fun safeRemove(v: View?) {
        if (v == null) return
        try {
            wm.removeView(v)
        } catch (e: Exception) {
            // 이미 제거됨
        }
    }

    private fun log(msg: String) {
        if (DEBUG) Log.d(TAG, msg)
    }

    override fun onInterrupt() {
        flushStats()
        removeCovers()
        removeShield()
        removeWall()
        hideQuote()
        hideNotice()
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        flushStats()
        removeCovers()
        removeShield()
        removeWall()
        hideQuote()
        hideNotice()
        hideFarewell()
        return super.onUnbind(intent)
    }
}
