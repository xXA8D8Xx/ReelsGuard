package com.example.reelsguard

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * 인스타그램 릴스 차단 서비스.
 *
 * 규칙
 * 1) 하단 탭의 '릴스' 탭으로 들어가면 즉시 홈 탭으로 돌려보낸다.
 * 2) DM 등에서 열린 릴스(하단 탭이 없는 전체화면 뷰어)는 1개만 볼 수 있고,
 *    위/아래로 넘기려 하면 뒤로 가기를 실행한다.
 *
 * 인스타그램 업데이트로 view id 가 바뀌면 아래 상수만 고치면 된다.
 * DEBUG 를 true 로 두고 `adb logcat -s ReelsGuard` 로 실제 id 를 확인할 수 있다.
 */
class ReelsBlockerService : AccessibilityService() {

    companion object {
        private const val TAG = "ReelsGuard"
        private const val DEBUG = true

        private const val IG = "com.instagram.android"
        private const val ID_CLIPS_TAB = "$IG:id/clips_tab"
        private const val ID_FEED_TAB = "$IG:id/feed_tab"
        private const val ID_VIEWER_PAGER = "$IG:id/clips_viewer_view_pager"

        // 릴스 뷰어가 열린 직후 이 시간 동안의 스크롤 이벤트는 무시(초기 로딩/재생 이벤트)
        private const val GRACE_MS = 1500L
        private const val COOLDOWN_MS = 800L
    }

    private var viewerSince = 0L
    private var lastAction = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.packageName?.toString() != IG) {
            viewerSince = 0L
            return
        }

        val root = rootInActiveWindow ?: return
        try {
            val hasViewer = root.findAccessibilityNodeInfosByViewId(ID_VIEWER_PAGER).isNotEmpty()
            val tabNodes = root.findAccessibilityNodeInfosByViewId(ID_CLIPS_TAB)
            val hasTabBar = tabNodes.isNotEmpty()

            if (!hasViewer) {
                viewerSince = 0L
                // 뷰어 id 가 바뀐 경우를 대비해 '릴스 탭이 선택됨' 상태도 직접 확인
                if (tabNodes.any { it.isSelected }) {
                    log("릴스 탭 선택 감지 → 홈으로")
                    goHome(root)
                }
                return
            }

            if (viewerSince == 0L) viewerSince = System.currentTimeMillis()

            if (hasTabBar) {
                // 하단 탭이 보이는 릴스 뷰어 = 릴스 탭
                log("릴스 탭 뷰어 감지 → 홈으로")
                goHome(root)
                return
            }

            // 하단 탭이 없는 뷰어 = DM 등에서 열린 단일 릴스
            if (event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED &&
                System.currentTimeMillis() - viewerSince > GRACE_MS
            ) {
                log("릴스 넘기기 감지 → 뒤로 가기")
                back()
            }
        } finally {
            @Suppress("DEPRECATION")
            root.recycle()
        }
    }

    private fun goHome(root: AccessibilityNodeInfo) {
        if (!cooldownPassed()) return
        val home = root.findAccessibilityNodeInfosByViewId(ID_FEED_TAB).firstOrNull()
        val clicked = home?.let { clickNodeOrParent(it) } ?: false
        if (!clicked) performGlobalAction(GLOBAL_ACTION_BACK)
    }

    private fun back() {
        if (!cooldownPassed()) return
        performGlobalAction(GLOBAL_ACTION_BACK)
        viewerSince = 0L
    }

    private fun cooldownPassed(): Boolean {
        val now = System.currentTimeMillis()
        if (now - lastAction < COOLDOWN_MS) return false
        lastAction = now
        return true
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = node
        while (cur != null) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
        }
        return false
    }

    private fun log(msg: String) {
        if (DEBUG) Log.d(TAG, msg)
    }

    override fun onInterrupt() {}
}
