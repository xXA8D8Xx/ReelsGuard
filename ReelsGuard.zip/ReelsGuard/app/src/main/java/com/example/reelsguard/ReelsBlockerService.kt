package com.example.reelsguard

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.LinearLayout
import android.widget.TextView

/**
 * 인스타그램 릴스 차단 서비스.
 *
 * 1) 하단 '릴스' 탭 위에 검은 덮개를 씌우고, 누르면 명언 경고만 띄운다(릴스는 열리지 않음).
 * 2) 그래도 릴스 탭 뷰어가 열리면(딥링크 등) 홈 탭으로 돌려보내고 명언을 띄운다.
 * 3) DM 등으로 열린 릴스(하단 탭이 없는 전체화면 뷰어)는 첫 1개는 자유,
 *    다음 스와이프부터는 하루 허용 횟수만큼만 허용하고 초과하면 뒤로 간다.
 *
 * [수정된 버그] 이전 버전은 '뷰어 view 가 트리에 존재'하기만 하면 릴스로 판단했다.
 * 인스타그램은 한 번 열었던 릴스 화면을 메모리에 남겨 두기 때문에, 릴스를 한 번 보고 나면
 * 다른 탭에서도 계속 홈으로 튕겼다. 이제는 '화면에 실제로 보이고(isVisibleToUser)
 * 화면 대부분을 덮는' 뷰어만 인정하고, 이미 홈 탭이면 홈 탭을 다시 누르지 않는다(새로고침 방지).
 *
 * 인스타그램 업데이트로 view id 가 바뀌면 아래 상수만 고치면 된다.
 * DEBUG 가 true 이면 `adb logcat -s ReelsGuard` 에서 판단 근거가 보인다.
 */
class ReelsBlockerService : AccessibilityService() {

    companion object {
        private const val TAG = "ReelsGuard"
        private const val DEBUG = true

        private const val IG = "com.instagram.android"
        private const val ID_CLIPS_TAB = "$IG:id/clips_tab"
        private const val ID_FEED_TAB = "$IG:id/feed_tab"
        private const val ID_VIEWER_PAGER = "$IG:id/clips_viewer_view_pager"

        private const val GRACE_MS = 1500L      // 뷰어가 열린 직후 이벤트는 무시
        private const val DEBOUNCE_MS = 900L    // 스와이프 1번이 여러 이벤트로 오는 것을 1회로 묶음
        private const val COOLDOWN_MS = 1200L   // 홈으로 돌려보낸 직후 재동작 방지
        private const val QUOTE_MS = 2800L
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var cover: View? = null
    private val coverRect = Rect()

    private var quoteView: View? = null
    private val hideQuoteRunnable = Runnable { hideQuote() }

    private var viewerSince = 0L
    private var lastAction = 0L
    private var lastCounted = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val pkg = event.packageName?.toString()

        if (pkg != IG) {
            // 우리 앱 오버레이나 시스템 UI 이벤트는 무시. 다른 앱으로 '창 전환'이 일어났을 때만 덮개를 치운다.
            if (pkg != null && pkg != packageName && pkg != "com.android.systemui" &&
                event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            ) {
                removeCover()
                hideQuote()
                viewerSince = 0L
            }
            return
        }

        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != IG) return

        val tab = root.findAccessibilityNodeInfosByViewId(ID_CLIPS_TAB)
            .firstOrNull { it.isVisibleToUser }
        val viewer = root.findAccessibilityNodeInfosByViewId(ID_VIEWER_PAGER)
            .firstOrNull { it.isVisibleToUser && coversScreen(it) }

        updateCover(tab)

        if (viewer == null) {
            viewerSince = 0L
            return
        }
        if (viewerSince == 0L) viewerSince = System.currentTimeMillis()

        if (tab != null) {
            // 화면을 덮는 뷰어 + 하단 탭이 보임 = 릴스 탭
            log("릴스 탭 뷰어 감지 → 홈으로")
            blockReelsTab(root)
            return
        }

        // 하단 탭이 없는 뷰어 = DM 등에서 열린 릴스
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED && isPagerScroll(event)) {
            onReelSwiped()
        }
    }

    // ---------- 판단 ----------

    private fun onReelSwiped() {
        val now = System.currentTimeMillis()
        if (now - viewerSince < GRACE_MS) return
        if (now - lastCounted < DEBOUNCE_MS) return
        lastCounted = now

        if (Prefs.remaining(this) > 0) {
            Prefs.addUsed(this)
            log("스와이프 허용: ${Prefs.used(this)}/${Prefs.limit(this)}")
        } else {
            log("오늘 횟수 초과 → 뒤로 가기")
            showQuote("오늘 릴스 횟수를 모두 썼어요")
            performGlobalAction(GLOBAL_ACTION_BACK)
            viewerSince = 0L
        }
    }

    private fun blockReelsTab(root: AccessibilityNodeInfo) {
        val now = System.currentTimeMillis()
        if (now - lastAction < COOLDOWN_MS) return
        lastAction = now

        showQuote("릴스는 잠시 쉬어가요")

        val feed = root.findAccessibilityNodeInfosByViewId(ID_FEED_TAB).firstOrNull()
        // 이미 홈 탭이면 다시 누르지 않는다(홈 새로고침 방지)
        if (feed?.isSelected == true) return
        val clicked = feed?.let { clickNodeOrParent(it) } ?: false
        if (!clicked) performGlobalAction(GLOBAL_ACTION_BACK)
    }

    private fun isPagerScroll(event: AccessibilityEvent): Boolean {
        val src = event.source ?: return false
        if (src.viewIdResourceName == ID_VIEWER_PAGER) return true
        // id 가 바뀐 경우를 대비: 화면 대부분을 덮는 스크롤 뷰
        val r = Rect()
        src.getBoundsInScreen(r)
        val dm = resources.displayMetrics
        return r.width() >= dm.widthPixels * 0.8 && r.height() >= dm.heightPixels * 0.8
    }

    private fun coversScreen(n: AccessibilityNodeInfo): Boolean {
        val r = Rect()
        n.getBoundsInScreen(r)
        val dm = resources.displayMetrics
        return r.width() >= dm.widthPixels * 0.8 && r.height() >= dm.heightPixels * 0.5
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = node
        while (cur != null) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
        }
        return false
    }

    // ---------- 릴스 탭 가림 ----------

    private fun updateCover(tab: AccessibilityNodeInfo?) {
        if (tab == null) {
            removeCover()
            return
        }
        val r = Rect()
        tab.getBoundsInScreen(r)
        if (r.isEmpty) {
            removeCover()
            return
        }
        val existing = cover
        if (existing == null) {
            val v = View(this).apply {
                setBackgroundColor(Color.BLACK)
                setOnClickListener { showQuote("릴스는 잠시 쉬어가요") }
            }
            try {
                wm.addView(v, coverParams(r))
                cover = v
                coverRect.set(r)
            } catch (e: Exception) {
                log("덮개 추가 실패: ${e.message}")
            }
        } else if (r != coverRect) {
            try {
                wm.updateViewLayout(existing, coverParams(r))
                coverRect.set(r)
            } catch (e: Exception) {
                log("덮개 갱신 실패: ${e.message}")
            }
        }
    }

    private fun coverParams(r: Rect) = WindowManager.LayoutParams(
        r.width(),
        r.height(),
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = r.left
        y = r.top
    }

    private fun removeCover() {
        val v = cover ?: return
        try {
            wm.removeView(v)
        } catch (e: Exception) {
            // 이미 제거됨
        }
        cover = null
        coverRect.setEmpty()
    }

    // ---------- 명언 경고 ----------

    private fun showQuote(headline: String) {
        if (quoteView != null) return

        val dp = resources.displayMetrics.density
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#EE0B0B14"))
            val pad = (32 * dp).toInt()
            setPadding(pad, pad, pad, pad)
            setOnClickListener { hideQuote() }
        }
        box.addView(TextView(this).apply {
            text = headline
            setTextColor(Color.parseColor("#FF6B8A"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            gravity = Gravity.CENTER
            letterSpacing = 0.08f
        })
        box.addView(TextView(this).apply {
            text = "“${Prefs.randomQuote(this@ReelsBlockerService)}”"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, (20 * dp).toInt(), 0, 0)
        })

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(box, lp)
            quoteView = box
            handler.postDelayed(hideQuoteRunnable, QUOTE_MS)
        } catch (e: Exception) {
            log("명언 표시 실패: ${e.message}")
        }
    }

    private fun hideQuote() {
        handler.removeCallbacks(hideQuoteRunnable)
        val v = quoteView ?: return
        try {
            wm.removeView(v)
        } catch (e: Exception) {
            // 이미 제거됨
        }
        quoteView = null
    }

    // ---------- 기타 ----------

    private fun log(msg: String) {
        if (DEBUG) Log.d(TAG, msg)
    }

    override fun onInterrupt() {
        removeCover()
        hideQuote()
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        removeCover()
        hideQuote()
        return super.onUnbind(intent)
    }
}
