package com.example.reelsguard

import java.time.LocalDate
import java.time.LocalDateTime

/**
 * '하루'의 기준. 새벽 4시에 하루가 바뀐다.
 * 늦게까지 보는 날에도 자정에 한도가 갑자기 초기화되지 않게 하려는 것.
 */
object Day {
    const val START_HOUR = 4

    /** 지금이 속한 '하루'의 날짜. 00:00~03:59 는 전날로 센다. */
    fun today(): LocalDate = of(LocalDateTime.now())

    fun of(t: LocalDateTime): LocalDate = t.minusHours(START_HOUR.toLong()).toLocalDate()
}
